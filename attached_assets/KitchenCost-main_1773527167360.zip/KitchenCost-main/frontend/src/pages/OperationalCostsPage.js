import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { 
  getOperationalCosts, 
  updateOperationalCosts,
  recalculateAllRecipes,
  formatCurrency,
  getCurrencySymbol
} from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { useToast } from '../hooks/use-toast';
import { 
  Loader2, 
  Save, 
  Calculator,
  Home,
  Zap,
  Droplets,
  Wifi,
  Users,
  FileText,
  Receipt,
  MoreHorizontal,
  RefreshCw
} from 'lucide-react';

const OperationalCostsPage = () => {
  const { currency } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [recalculating, setRecalculating] = useState(false);
  const [costs, setCosts] = useState(null);
  const [formData, setFormData] = useState({
    rent: '',
    electricity: '',
    water: '',
    internet: '',
    salaries: '',
    accounting: '',
    taxes: '',
    other_costs: '',
    average_dishes_sold_per_month: ''
  });

  useEffect(() => {
    loadCosts();
  }, []);

  const loadCosts = async () => {
    try {
      const response = await getOperationalCosts();
      setCosts(response.data);
      setFormData({
        rent: response.data.rent?.toString() || '0',
        electricity: response.data.electricity?.toString() || '0',
        water: response.data.water?.toString() || '0',
        internet: response.data.internet?.toString() || '0',
        salaries: response.data.salaries?.toString() || '0',
        accounting: response.data.accounting?.toString() || '0',
        taxes: response.data.taxes?.toString() || '0',
        other_costs: response.data.other_costs?.toString() || '0',
        average_dishes_sold_per_month: response.data.average_dishes_sold_per_month?.toString() || '1'
      });
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao carregar custos operacionais',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    try {
      const data = {
        rent: parseFloat(formData.rent) || 0,
        electricity: parseFloat(formData.electricity) || 0,
        water: parseFloat(formData.water) || 0,
        internet: parseFloat(formData.internet) || 0,
        salaries: parseFloat(formData.salaries) || 0,
        accounting: parseFloat(formData.accounting) || 0,
        taxes: parseFloat(formData.taxes) || 0,
        other_costs: parseFloat(formData.other_costs) || 0,
        average_dishes_sold_per_month: parseFloat(formData.average_dishes_sold_per_month) || 1
      };
      
      await updateOperationalCosts(data);
      await loadCosts();
      toast({ title: 'Custos operacionais salvos!' });
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao salvar',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleRecalculate = async () => {
    setRecalculating(true);
    try {
      const response = await recalculateAllRecipes();
      toast({ title: response.data.message });
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao recalcular',
        variant: 'destructive'
      });
    } finally {
      setRecalculating(false);
    }
  };

  // Calculate totals dynamically
  const totalMonthly = 
    (parseFloat(formData.rent) || 0) +
    (parseFloat(formData.electricity) || 0) +
    (parseFloat(formData.water) || 0) +
    (parseFloat(formData.internet) || 0) +
    (parseFloat(formData.salaries) || 0) +
    (parseFloat(formData.accounting) || 0) +
    (parseFloat(formData.taxes) || 0) +
    (parseFloat(formData.other_costs) || 0);

  const avgDishes = parseFloat(formData.average_dishes_sold_per_month) || 1;
  const fixedCostPerDish = totalMonthly / avgDishes;

  const costFields = [
    { key: 'rent', label: 'Aluguel', icon: Home },
    { key: 'electricity', label: 'Energia Elétrica', icon: Zap },
    { key: 'water', label: 'Água', icon: Droplets },
    { key: 'internet', label: 'Internet', icon: Wifi },
    { key: 'salaries', label: 'Salários', icon: Users },
    { key: 'accounting', label: 'Contabilidade', icon: FileText },
    { key: 'taxes', label: 'Impostos', icon: Receipt },
    { key: 'other_costs', label: 'Outros Custos', icon: MoreHorizontal },
  ];

  if (loading) {
    return (
      <Layout title="Custos Operacionais">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Custos Operacionais">
      <div className="max-w-4xl">
        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-5 mb-8">
          <div className="stat-card">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 rounded-lg bg-blue-50">
                <Calculator className="w-5 h-5 text-blue-600" />
              </div>
              <span className="text-muted-foreground">Custo Mensal Total</span>
            </div>
            <div className="metric-value text-2xl">
              {formatCurrency(totalMonthly, currency)}
            </div>
          </div>

          <div className="stat-card">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 rounded-lg bg-green-50">
                <Receipt className="w-5 h-5 text-green-600" />
              </div>
              <span className="text-muted-foreground">Custo Fixo por Prato</span>
            </div>
            <div className="metric-value text-2xl">
              {formatCurrency(fixedCostPerDish, currency)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Baseado em {avgDishes.toLocaleString()} pratos/mês
            </p>
          </div>
        </div>

        {/* Form */}
        <div className="chart-container">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-lg">Custos Fixos Mensais</h3>
            <Button
              variant="outline"
              onClick={handleRecalculate}
              disabled={recalculating}
              data-testid="recalculate-btn"
            >
              {recalculating ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Recalcular Receitas
            </Button>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-2 gap-6 mb-6">
              {costFields.map((field) => (
                <div key={field.key}>
                  <Label htmlFor={field.key} className="flex items-center gap-2 mb-2">
                    <field.icon className="w-4 h-4 text-muted-foreground" />
                    {field.label}
                  </Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                      {getCurrencySymbol(currency)}
                    </span>
                    <Input
                      id={field.key}
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData[field.key]}
                      onChange={(e) => setFormData({...formData, [field.key]: e.target.value})}
                      className="pl-10"
                      data-testid={`cost-${field.key}`}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Average dishes */}
            <div className="border-t pt-6 mb-6">
              <Label htmlFor="average_dishes" className="flex items-center gap-2 mb-2">
                <Calculator className="w-4 h-4 text-muted-foreground" />
                Média de Pratos Vendidos por Mês
              </Label>
              <Input
                id="average_dishes"
                type="number"
                step="1"
                min="1"
                value={formData.average_dishes_sold_per_month}
                onChange={(e) => setFormData({...formData, average_dishes_sold_per_month: e.target.value})}
                className="max-w-xs"
                data-testid="cost-average-dishes"
              />
              <p className="text-sm text-muted-foreground mt-2">
                Este valor é usado para calcular o custo fixo por prato em cada receita.
              </p>
            </div>

            <div className="flex justify-end">
              <Button type="submit" disabled={saving} data-testid="save-costs-btn">
                {saving ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                Salvar Custos
              </Button>
            </div>
          </form>
        </div>

        {/* Info box */}
        <div className="mt-6 p-4 bg-blue-50 border border-blue-100 rounded-lg">
          <h4 className="font-medium text-blue-800 mb-2">Como funciona</h4>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• O custo fixo por prato é calculado dividindo o custo mensal total pela média de pratos vendidos.</li>
            <li>• Este valor é automaticamente adicionado ao custo de cada receita.</li>
            <li>• Ao salvar, você pode clicar em "Recalcular Receitas" para atualizar todas as fichas técnicas.</li>
          </ul>
        </div>
      </div>
    </Layout>
  );
};

export default OperationalCostsPage;
