import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { 
  getSales,
  createSale,
  deleteSale,
  getMenu,
  getSalesSummary,
  formatCurrency,
  formatNumber,
  formatDateTime,
  getCurrencySymbol
} from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import { useToast } from '../hooks/use-toast';
import { 
  Plus, 
  Loader2, 
  Trash2, 
  ShoppingCart,
  DollarSign,
  TrendingUp,
  Calendar,
  BookOpen,
  Wine
} from 'lucide-react';

const SALES_CHANNELS = ['Balcão', 'Delivery', 'iFood', 'Rappi', 'Uber Eats', 'WhatsApp', 'Telefone', 'Outro'];

const SalesPage = () => {
  const { currency } = useAuth();
  const [sales, setSales] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    item_type: '',
    item_id: '',
    quantity_sold: '1',
    sale_price: '',
    sales_channel: '',
    notes: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [salesRes, menuRes, summaryRes] = await Promise.all([
        getSales(),
        getMenu(),
        getSalesSummary('today')
      ]);
      setSales(salesRes.data);
      setMenuItems(menuRes.data);
      setSummary(summaryRes.data);
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao carregar vendas',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const openModal = () => {
    setFormData({
      item_type: '',
      item_id: '',
      quantity_sold: '1',
      sale_price: '',
      sales_channel: '',
      notes: ''
    });
    setModalOpen(true);
  };

  const handleItemSelect = (itemId) => {
    const item = menuItems.find(m => m.item_id === itemId);
    if (item) {
      setFormData({
        ...formData,
        item_type: item.item_type,
        item_id: itemId,
        sale_price: item.sale_price.toString()
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.item_id || !formData.quantity_sold) {
      toast({
        title: 'Erro',
        description: 'Item e quantidade são obrigatórios',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      const data = {
        item_type: formData.item_type,
        item_id: formData.item_id,
        quantity_sold: parseFloat(formData.quantity_sold),
        sale_price: formData.sale_price ? parseFloat(formData.sale_price) : null,
        sales_channel: formData.sales_channel || null,
        notes: formData.notes || null
      };

      const response = await createSale(data);
      toast({ 
        title: 'Venda registrada!',
        description: `Lucro: ${formatCurrency(response.data.profit, currency)}`
      });
      
      setModalOpen(false);
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao registrar venda',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (item) => {
    if (!window.confirm(`Excluir venda de "${item.item_name}"? O estoque NÃO será restaurado.`)) return;
    
    try {
      await deleteSale(item.sale_id);
      toast({ title: 'Venda excluída!' });
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao excluir',
        variant: 'destructive'
      });
    }
  };

  // Get selected item info
  const selectedItem = menuItems.find(m => m.item_id === formData.item_id);

  // Calculate preview
  const calculatePreview = () => {
    if (!selectedItem || !formData.quantity_sold) return null;
    const qty = parseFloat(formData.quantity_sold) || 0;
    const price = parseFloat(formData.sale_price) || selectedItem.sale_price;
    const revenue = price * qty;
    const cost = selectedItem.cost * qty;
    const profit = revenue - cost;
    return { revenue, cost, profit };
  };

  const preview = calculatePreview();

  return (
    <Layout 
      title="Vendas"
      actions={
        <Button onClick={openModal} data-testid="add-sale-btn">
          <Plus className="w-4 h-4 mr-2" />
          Registrar Venda
        </Button>
      }
    >
      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="metric-value">{formatCurrency(summary?.total_revenue || 0, currency)}</div>
              <div className="metric-label">Receita Hoje</div>
            </div>
            <div className="p-2.5 rounded-lg bg-green-50">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </div>
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="metric-value">{formatCurrency(summary?.total_cost || 0, currency)}</div>
              <div className="metric-label">Custo Hoje</div>
            </div>
            <div className="p-2.5 rounded-lg bg-red-50">
              <DollarSign className="w-5 h-5 text-red-600" />
            </div>
          </div>
        </div>
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="metric-value text-green-600">{formatCurrency(summary?.total_profit || 0, currency)}</div>
              <div className="metric-label">Lucro Hoje</div>
            </div>
            <div className="p-2.5 rounded-lg bg-emerald-50">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
            </div>
          </div>
        </div>
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="metric-value">{summary?.items_sold || 0}</div>
              <div className="metric-label">Itens Vendidos</div>
            </div>
            <div className="p-2.5 rounded-lg bg-blue-50">
              <ShoppingCart className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Sales Table */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : sales.length === 0 ? (
        <div className="empty-state">
          <ShoppingCart className="empty-state-icon" />
          <h3 className="font-semibold text-lg mb-1">Nenhuma venda registrada</h3>
          <p className="text-muted-foreground mb-4">Registre as vendas para acompanhar receitas e lucros</p>
          <Button onClick={openModal}>
            <Plus className="w-4 h-4 mr-2" />
            Registrar Venda
          </Button>
        </div>
      ) : (
        <div className="table-container" data-testid="sales-table">
          <table className="data-table">
            <thead>
              <tr>
                <th>Data/Hora</th>
                <th>Item</th>
                <th>Tipo</th>
                <th>Qtd</th>
                <th>Receita</th>
                <th>Custo</th>
                <th>Lucro</th>
                <th>Canal</th>
                <th className="text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {sales.map(item => (
                <tr key={item.sale_id} data-testid={`row-${item.sale_id}`}>
                  <td>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      {formatDateTime(item.date)}
                    </div>
                  </td>
                  <td className="font-medium">{item.item_name}</td>
                  <td>
                    <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${
                      item.item_type === 'recipe_item' 
                        ? 'bg-blue-100 text-blue-700' 
                        : 'bg-purple-100 text-purple-700'
                    }`}>
                      {item.item_type === 'recipe_item' 
                        ? <><BookOpen className="w-3 h-3" /> Receita</>
                        : <><Wine className="w-3 h-3" /> Revenda</>
                      }
                    </span>
                  </td>
                  <td>{formatNumber(item.quantity_sold, 0)}</td>
                  <td className="font-medium">{formatCurrency(item.total_revenue, currency)}</td>
                  <td className="text-muted-foreground">{formatCurrency(item.total_cost, currency)}</td>
                  <td className={`font-semibold ${item.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {formatCurrency(item.profit, currency)}
                  </td>
                  <td className="text-muted-foreground">{item.sales_channel || '-'}</td>
                  <td>
                    <div className="flex justify-end">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        onClick={() => handleDelete(item)}
                        data-testid={`delete-${item.sale_id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Registrar Venda</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="item">Item Vendido *</Label>
              <Select 
                value={formData.item_id || "none"} 
                onValueChange={(v) => v !== "none" && handleItemSelect(v)}
              >
                <SelectTrigger data-testid="sale-item">
                  <SelectValue placeholder="Selecione o item" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Selecione</SelectItem>
                  {menuItems.map(item => (
                    <SelectItem key={item.item_id} value={item.item_id}>
                      <span className="flex items-center gap-2">
                        {item.item_type === 'recipe_item' 
                          ? <BookOpen className="w-3 h-3" />
                          : <Wine className="w-3 h-3" />
                        }
                        {item.name} - {formatCurrency(item.sale_price, currency)}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedItem && (
              <div className="bg-muted/50 rounded-lg p-3 text-sm space-y-1">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Custo unitário:</span>
                  <span className="font-medium">{formatCurrency(selectedItem.cost, currency)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Preço padrão:</span>
                  <span className="font-medium">{formatCurrency(selectedItem.sale_price, currency)}</span>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="quantity_sold">Quantidade *</Label>
                <Input
                  id="quantity_sold"
                  type="number"
                  step="1"
                  min="1"
                  value={formData.quantity_sold}
                  onChange={(e) => setFormData({...formData, quantity_sold: e.target.value})}
                  placeholder="1"
                  data-testid="sale-quantity"
                />
              </div>
              <div>
                <Label htmlFor="sale_price">Preço de Venda ({getCurrencySymbol(currency)})</Label>
                <Input
                  id="sale_price"
                  type="number"
                  step="0.01"
                  value={formData.sale_price}
                  onChange={(e) => setFormData({...formData, sale_price: e.target.value})}
                  placeholder={selectedItem ? selectedItem.sale_price.toString() : '0.00'}
                  data-testid="sale-price"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Deixe vazio para usar o preço padrão
                </p>
              </div>
            </div>

            {/* Preview */}
            {preview && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-green-700">Receita:</span>
                  <span className="font-medium text-green-700">{formatCurrency(preview.revenue, currency)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-green-700">Custo:</span>
                  <span className="font-medium text-green-700">- {formatCurrency(preview.cost, currency)}</span>
                </div>
                <div className="flex justify-between border-t border-green-200 pt-2">
                  <span className="font-medium text-green-700">Lucro:</span>
                  <span className="text-lg font-bold text-green-700">{formatCurrency(preview.profit, currency)}</span>
                </div>
              </div>
            )}

            <div>
              <Label htmlFor="sales_channel">Canal de Venda</Label>
              <Select 
                value={formData.sales_channel || "none"} 
                onValueChange={(v) => setFormData({...formData, sales_channel: v === "none" ? "" : v})}
              >
                <SelectTrigger data-testid="sale-channel">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Não especificado</SelectItem>
                  {SALES_CHANNELS.map(channel => (
                    <SelectItem key={channel} value={channel}>{channel}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="notes">Observações</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                placeholder="Observações opcionais..."
                rows={2}
                data-testid="sale-notes"
              />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={saving} data-testid="save-sale-btn">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Registrar
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default SalesPage;
