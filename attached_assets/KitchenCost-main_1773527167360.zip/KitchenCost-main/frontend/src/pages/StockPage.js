import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { 
  getIngredients, 
  getStockMovements,
  createStockEntry,
  createStockExit,
  getInventoryValue,
  formatCurrency,
  formatNumber,
  formatDateTime,
  getCurrencySymbol
} from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '../components/ui/tabs';
import { useToast } from '../hooks/use-toast';
import { 
  Plus, 
  Loader2, 
  Package,
  ArrowUpCircle,
  ArrowDownCircle,
  AlertTriangle,
  TrendingUp,
  DollarSign
} from 'lucide-react';

const StockPage = () => {
  const { currency } = useAuth();
  const [ingredients, setIngredients] = useState([]);
  const [movements, setMovements] = useState([]);
  const [inventoryValue, setInventoryValue] = useState(null);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState('entry'); // 'entry' or 'exit'
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    ingredient_id: '',
    quantity: '',
    unit_cost: '',
    reason: 'compra'
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [ingredientsRes, movementsRes, inventoryRes] = await Promise.all([
        getIngredients(),
        getStockMovements(),
        getInventoryValue()
      ]);
      setIngredients(ingredientsRes.data);
      setMovements(movementsRes.data);
      setInventoryValue(inventoryRes.data);
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao carregar dados de estoque',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const openModal = (type) => {
    setModalType(type);
    setFormData({
      ingredient_id: '',
      quantity: '',
      unit_cost: '',
      reason: type === 'entry' ? 'compra' : 'producao'
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.ingredient_id || !formData.quantity) {
      toast({
        title: 'Erro',
        description: 'Preencha os campos obrigatórios',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      if (modalType === 'entry') {
        await createStockEntry({
          ingredient_id: formData.ingredient_id,
          quantity: parseFloat(formData.quantity),
          unit_cost: formData.unit_cost ? parseFloat(formData.unit_cost) : null,
          reason: formData.reason
        });
        toast({ title: 'Entrada registrada!' });
      } else {
        await createStockExit({
          ingredient_id: formData.ingredient_id,
          quantity: parseFloat(formData.quantity),
          reason: formData.reason
        });
        toast({ title: 'Saída registrada!' });
      }
      
      setModalOpen(false);
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao registrar movimentação',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const getStockStatus = (item) => {
    if (item.current_stock <= 0) {
      return { status: 'critical', label: 'Crítico', color: 'bg-red-100 text-red-700' };
    }
    if (item.current_stock <= item.min_stock) {
      return { status: 'critical', label: 'Crítico', color: 'bg-red-100 text-red-700' };
    }
    if (item.current_stock <= item.min_stock * 1.5) {
      return { status: 'attention', label: 'Atenção', color: 'bg-yellow-100 text-yellow-700' };
    }
    return { status: 'healthy', label: 'Saudável', color: 'bg-green-100 text-green-700' };
  };

  const lowStockItems = ingredients.filter(i => i.current_stock <= i.min_stock);

  return (
    <Layout 
      title="Estoque"
      actions={
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => openModal('exit')} data-testid="stock-exit-btn">
            <ArrowDownCircle className="w-4 h-4 mr-2" />
            Saída
          </Button>
          <Button onClick={() => openModal('entry')} data-testid="stock-entry-btn">
            <ArrowUpCircle className="w-4 h-4 mr-2" />
            Entrada
          </Button>
        </div>
      }
    >
      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-5 mb-6" data-testid="stock-summary">
        <div className="stat-card">
          <div className="flex items-start justify-between">
            <div>
              <div className="metric-value text-2xl">
                {formatCurrency(inventoryValue?.total_value || 0, currency)}
              </div>
              <div className="metric-label">Valor do Inventário</div>
            </div>
            <div className="p-2.5 rounded-lg bg-emerald-50">
              <DollarSign className="w-5 h-5 text-emerald-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-start justify-between">
            <div>
              <div className="metric-value text-2xl">{inventoryValue?.items_count || 0}</div>
              <div className="metric-label">Itens em Estoque</div>
            </div>
            <div className="p-2.5 rounded-lg bg-blue-50">
              <Package className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-start justify-between">
            <div>
              <div className={`metric-value text-2xl ${inventoryValue?.low_stock_count > 0 ? 'text-red-600' : ''}`}>
                {inventoryValue?.low_stock_count || 0}
              </div>
              <div className="metric-label">Alertas de Estoque</div>
            </div>
            <div className={`p-2.5 rounded-lg ${inventoryValue?.low_stock_count > 0 ? 'bg-red-50' : 'bg-gray-50'}`}>
              <AlertTriangle className={`w-5 h-5 ${inventoryValue?.low_stock_count > 0 ? 'text-red-600' : 'text-gray-400'}`} />
            </div>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <Tabs defaultValue="inventory" className="space-y-4">
          <TabsList>
            <TabsTrigger value="inventory" data-testid="tab-inventory">Inventário</TabsTrigger>
            <TabsTrigger value="movements" data-testid="tab-movements">Movimentações</TabsTrigger>
            <TabsTrigger value="alerts" data-testid="tab-alerts">
              Alertas {lowStockItems.length > 0 && `(${lowStockItems.length})`}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="inventory">
            <div className="bg-white rounded-xl border overflow-hidden">
              <table className="data-table" data-testid="inventory-table">
                <thead className="bg-muted/30">
                  <tr>
                    <th>Ingrediente</th>
                    <th>Categoria</th>
                    <th className="text-right">Custo/Unidade</th>
                    <th className="text-right">Estoque Atual</th>
                    <th className="text-right">Estoque Mínimo</th>
                    <th className="text-right">Valor em Estoque</th>
                    <th className="text-center">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {ingredients.map(item => {
                    const stockStatus = getStockStatus(item);
                    const stockValue = item.current_stock * item.cost_per_unit;
                    return (
                      <tr key={item.ingredient_id}>
                        <td className="font-medium">{item.name}</td>
                        <td className="text-muted-foreground">{item.category || '-'}</td>
                        <td className="text-right font-mono">
                          {formatCurrency(item.cost_per_unit, currency)}/{item.unit}
                        </td>
                        <td className="text-right font-mono">
                          {formatNumber(item.current_stock)} {item.unit}
                        </td>
                        <td className="text-right font-mono">
                          {formatNumber(item.min_stock)} {item.unit}
                        </td>
                        <td className="text-right font-mono font-medium">
                          {formatCurrency(stockValue, currency)}
                        </td>
                        <td className="text-center">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${stockStatus.color}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${
                              stockStatus.status === 'critical' ? 'bg-red-500' :
                              stockStatus.status === 'attention' ? 'bg-yellow-500' : 'bg-green-500'
                            }`}></span>
                            {stockStatus.label}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </TabsContent>

          <TabsContent value="movements">
            <div className="bg-white rounded-xl border overflow-hidden">
              <table className="data-table" data-testid="movements-table">
                <thead className="bg-muted/30">
                  <tr>
                    <th>Data/Hora</th>
                    <th>Ingrediente</th>
                    <th className="text-center">Tipo</th>
                    <th className="text-right">Quantidade</th>
                    <th className="text-right">Custo Unit.</th>
                    <th className="text-right">Total</th>
                    <th>Motivo</th>
                  </tr>
                </thead>
                <tbody>
                  {movements.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-8 text-muted-foreground">
                        Nenhuma movimentação registrada
                      </td>
                    </tr>
                  ) : (
                    movements.map(mov => (
                      <tr key={mov.movement_id}>
                        <td className="text-muted-foreground text-sm">
                          {formatDateTime(mov.created_at)}
                        </td>
                        <td className="font-medium">{mov.ingredient_name}</td>
                        <td className="text-center">
                          {mov.movement_type === 'entrada' ? (
                            <span className="badge-success flex items-center gap-1 justify-center">
                              <ArrowUpCircle className="w-3 h-3" />
                              Entrada
                            </span>
                          ) : (
                            <span className="badge-danger flex items-center gap-1 justify-center">
                              <ArrowDownCircle className="w-3 h-3" />
                              Saída
                            </span>
                          )}
                        </td>
                        <td className="text-right font-mono">{formatNumber(mov.quantity)}</td>
                        <td className="text-right font-mono">
                          {mov.unit_cost ? formatCurrency(mov.unit_cost, currency) : '-'}
                        </td>
                        <td className="text-right font-mono">
                          {mov.total_cost ? formatCurrency(mov.total_cost, currency) : '-'}
                        </td>
                        <td className="text-muted-foreground capitalize">{mov.reason}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </TabsContent>

          <TabsContent value="alerts">
            {lowStockItems.length === 0 ? (
              <div className="empty-state">
                <Package className="empty-state-icon" />
                <h3 className="font-semibold text-lg mb-1">Tudo em ordem!</h3>
                <p className="text-muted-foreground">Nenhum item com estoque baixo</p>
              </div>
            ) : (
              <div className="bg-white rounded-xl border overflow-hidden">
                <table className="data-table" data-testid="alerts-table">
                  <thead className="bg-muted/30">
                    <tr>
                      <th>Ingrediente</th>
                      <th>Categoria</th>
                      <th className="text-right">Estoque Atual</th>
                      <th className="text-right">Estoque Mínimo</th>
                      <th className="text-right">Repor</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {lowStockItems.map(item => (
                      <tr key={item.ingredient_id} className="bg-red-50/50">
                        <td className="font-medium">{item.name}</td>
                        <td className="text-muted-foreground">{item.category || '-'}</td>
                        <td className="text-right font-mono text-red-600 font-medium">
                          {formatNumber(item.current_stock)} {item.unit}
                        </td>
                        <td className="text-right font-mono">
                          {formatNumber(item.min_stock)} {item.unit}
                        </td>
                        <td className="text-right font-mono">
                          {formatNumber(Math.max(0, item.min_stock - item.current_stock))} {item.unit}
                        </td>
                        <td>
                          <Button
                            size="sm"
                            onClick={() => {
                              setFormData({
                                ingredient_id: item.ingredient_id,
                                quantity: Math.max(0, item.min_stock - item.current_stock).toString(),
                                unit_cost: item.cost_per_unit.toString(),
                                reason: 'compra'
                              });
                              setModalType('entry');
                              setModalOpen(true);
                            }}
                          >
                            Repor
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}

      {/* Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {modalType === 'entry' ? 'Entrada de Estoque' : 'Saída de Estoque'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="ingredient">Ingrediente *</Label>
              <Select 
                value={formData.ingredient_id} 
                onValueChange={(v) => setFormData({...formData, ingredient_id: v})}
              >
                <SelectTrigger data-testid="stock-ingredient">
                  <SelectValue placeholder="Selecione o ingrediente" />
                </SelectTrigger>
                <SelectContent>
                  {ingredients.map(ing => (
                    <SelectItem key={ing.ingredient_id} value={ing.ingredient_id}>
                      {ing.name} ({ing.current_stock} {ing.unit} em estoque)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="form-grid">
              <div>
                <Label htmlFor="quantity">Quantidade *</Label>
                <Input
                  id="quantity"
                  type="number"
                  step="0.01"
                  value={formData.quantity}
                  onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                  placeholder="0.00"
                  data-testid="stock-quantity"
                />
              </div>
              {modalType === 'entry' && (
                <div>
                  <Label htmlFor="cost">Custo Unitário ({getCurrencySymbol(currency)})</Label>
                  <Input
                    id="cost"
                    type="number"
                    step="0.01"
                    value={formData.unit_cost}
                    onChange={(e) => setFormData({...formData, unit_cost: e.target.value})}
                    placeholder="Manter atual"
                    data-testid="stock-cost"
                  />
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="reason">Motivo</Label>
              <Select 
                value={formData.reason} 
                onValueChange={(v) => setFormData({...formData, reason: v})}
              >
                <SelectTrigger data-testid="stock-reason">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {modalType === 'entry' ? (
                    <>
                      <SelectItem value="compra">Compra</SelectItem>
                      <SelectItem value="ajuste">Ajuste de Inventário</SelectItem>
                      <SelectItem value="devolucao">Devolução</SelectItem>
                    </>
                  ) : (
                    <>
                      <SelectItem value="producao">Produção</SelectItem>
                      <SelectItem value="perda">Perda/Vencimento</SelectItem>
                      <SelectItem value="ajuste">Ajuste de Inventário</SelectItem>
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={saving} data-testid="save-stock-btn">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Registrar
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default StockPage;
