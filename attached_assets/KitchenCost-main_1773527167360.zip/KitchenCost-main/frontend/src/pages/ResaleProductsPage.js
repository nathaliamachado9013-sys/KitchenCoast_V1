import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { 
  getResaleProducts, 
  createResaleProduct, 
  updateResaleProduct, 
  deleteResaleProduct,
  getSuppliers,
  formatCurrency,
  formatNumber,
  getCurrencySymbol
} from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import { useToast } from '../hooks/use-toast';
import { 
  Plus, 
  Search, 
  Loader2, 
  Pencil, 
  Trash2, 
  Wine,
  TrendingUp
} from 'lucide-react';

const CATEGORIES = ['Refrigerantes', 'Águas', 'Sucos', 'Cervejas', 'Vinhos', 'Destilados', 'Energéticos', 'Outros'];
const UNITS = ['unidade', 'garrafa', 'lata', 'caixa', 'pacote', 'litro'];

const ResaleProductsPage = () => {
  const { currency } = useAuth();
  const [products, setProducts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    category: '',
    purchase_cost: '',
    sale_price: '',
    supplier_id: '',
    stock_quantity: '0',
    unit: 'unidade'
  });

  useEffect(() => {
    loadData();
  }, [search, categoryFilter]);

  const loadData = async () => {
    try {
      const [productsRes, suppliersRes] = await Promise.all([
        getResaleProducts({ search, category: categoryFilter || undefined }),
        getSuppliers()
      ]);
      setProducts(productsRes.data);
      setSuppliers(suppliersRes.data);
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao carregar produtos',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const openModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        name: item.name,
        category: item.category || '',
        purchase_cost: item.purchase_cost.toString(),
        sale_price: item.sale_price.toString(),
        supplier_id: item.supplier_id || '',
        stock_quantity: item.stock_quantity.toString(),
        unit: item.unit || 'unidade'
      });
    } else {
      setEditingItem(null);
      setFormData({
        name: '',
        category: '',
        purchase_cost: '',
        sale_price: '',
        supplier_id: '',
        stock_quantity: '0',
        unit: 'unidade'
      });
    }
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.purchase_cost || !formData.sale_price) {
      toast({
        title: 'Erro',
        description: 'Nome, custo e preço de venda são obrigatórios',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      const data = {
        name: formData.name,
        category: formData.category || null,
        purchase_cost: parseFloat(formData.purchase_cost),
        sale_price: parseFloat(formData.sale_price),
        supplier_id: formData.supplier_id || null,
        stock_quantity: parseFloat(formData.stock_quantity) || 0,
        unit: formData.unit
      };

      if (editingItem) {
        await updateResaleProduct(editingItem.product_id, data);
        toast({ title: 'Produto atualizado!' });
      } else {
        await createResaleProduct(data);
        toast({ title: 'Produto criado!' });
      }
      
      setModalOpen(false);
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao salvar',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (item) => {
    if (!window.confirm(`Excluir "${item.name}"?`)) return;
    
    try {
      await deleteResaleProduct(item.product_id);
      toast({ title: 'Produto excluído!' });
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao excluir',
        variant: 'destructive'
      });
    }
  };

  // Calculate margin preview
  const calculateMargin = () => {
    const cost = parseFloat(formData.purchase_cost) || 0;
    const price = parseFloat(formData.sale_price) || 0;
    if (price > 0) {
      return ((price - cost) / price) * 100;
    }
    return 0;
  };

  return (
    <Layout 
      title="Produtos de Revenda"
      actions={
        <Button onClick={() => openModal()} data-testid="add-resale-btn">
          <Plus className="w-4 h-4 mr-2" />
          Novo Produto
        </Button>
      }
    >
      {/* Filters */}
      <div className="flex gap-4 mb-6">
        <div className="flex-1 search-input">
          <Search className="w-4 h-4" />
          <Input
            placeholder="Buscar produtos..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
            data-testid="search-input"
          />
        </div>
        <Select value={categoryFilter || "all"} onValueChange={(v) => setCategoryFilter(v === "all" ? "" : v)}>
          <SelectTrigger className="w-48" data-testid="category-filter">
            <SelectValue placeholder="Todas categorias" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas categorias</SelectItem>
            {CATEGORIES.map(cat => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : products.length === 0 ? (
        <div className="empty-state">
          <Wine className="empty-state-icon" />
          <h3 className="font-semibold text-lg mb-1">Nenhum produto cadastrado</h3>
          <p className="text-muted-foreground mb-4">Cadastre bebidas e produtos de revenda</p>
          <Button onClick={() => openModal()}>
            <Plus className="w-4 h-4 mr-2" />
            Novo Produto
          </Button>
        </div>
      ) : (
        <div className="table-container" data-testid="products-table">
          <table className="data-table">
            <thead>
              <tr>
                <th>Nome</th>
                <th>Categoria</th>
                <th>Custo</th>
                <th>Preço Venda</th>
                <th>Margem</th>
                <th>Estoque</th>
                <th>Fornecedor</th>
                <th className="text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {products.map(item => (
                <tr key={item.product_id} data-testid={`row-${item.product_id}`}>
                  <td className="font-medium">{item.name}</td>
                  <td>
                    {item.category && (
                      <span className="text-xs bg-muted px-2 py-0.5 rounded-full">
                        {item.category}
                      </span>
                    )}
                  </td>
                  <td>{formatCurrency(item.purchase_cost, currency)}</td>
                  <td className="font-medium">{formatCurrency(item.sale_price, currency)}</td>
                  <td>
                    <span className={`font-medium ${item.margin >= 50 ? 'text-green-600' : item.margin >= 30 ? 'text-yellow-600' : 'text-red-600'}`}>
                      {formatNumber(item.margin, 1)}%
                    </span>
                  </td>
                  <td>
                    <span className={item.stock_quantity <= 5 ? 'text-red-600 font-medium' : ''}>
                      {item.stock_quantity} {item.unit}
                    </span>
                  </td>
                  <td className="text-muted-foreground">{item.supplier_name || '-'}</td>
                  <td>
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openModal(item)}
                        data-testid={`edit-${item.product_id}`}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        onClick={() => handleDelete(item)}
                        data-testid={`delete-${item.product_id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? 'Editar Produto' : 'Novo Produto de Revenda'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Nome do Produto *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Ex: Coca-Cola Lata 350ml"
                data-testid="product-name"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">Categoria</Label>
                <Select 
                  value={formData.category || "none"} 
                  onValueChange={(v) => setFormData({...formData, category: v === "none" ? "" : v})}
                >
                  <SelectTrigger data-testid="product-category">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Selecione</SelectItem>
                    {CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="supplier">Fornecedor</Label>
                <Select 
                  value={formData.supplier_id || "none"} 
                  onValueChange={(v) => setFormData({...formData, supplier_id: v === "none" ? "" : v})}
                >
                  <SelectTrigger data-testid="product-supplier">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Sem fornecedor</SelectItem>
                    {suppliers.map(sup => (
                      <SelectItem key={sup.supplier_id} value={sup.supplier_id}>{sup.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="purchase_cost">Custo de Compra ({getCurrencySymbol(currency)}) *</Label>
                <Input
                  id="purchase_cost"
                  type="number"
                  step="0.01"
                  value={formData.purchase_cost}
                  onChange={(e) => setFormData({...formData, purchase_cost: e.target.value})}
                  placeholder="0.00"
                  data-testid="product-cost"
                />
              </div>
              <div>
                <Label htmlFor="sale_price">Preço de Venda ({getCurrencySymbol(currency)}) *</Label>
                <Input
                  id="sale_price"
                  type="number"
                  step="0.01"
                  value={formData.sale_price}
                  onChange={(e) => setFormData({...formData, sale_price: e.target.value})}
                  placeholder="0.00"
                  data-testid="product-price"
                />
              </div>
            </div>

            {/* Margin Preview */}
            {formData.purchase_cost && formData.sale_price && (
              <div className="bg-muted/50 rounded-lg p-3 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  <TrendingUp className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Margem calculada:</span>
                </div>
                <span className={`font-semibold ${calculateMargin() >= 50 ? 'text-green-600' : calculateMargin() >= 30 ? 'text-yellow-600' : 'text-red-600'}`}>
                  {formatNumber(calculateMargin(), 1)}%
                </span>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="stock_quantity">Quantidade em Estoque</Label>
                <Input
                  id="stock_quantity"
                  type="number"
                  step="1"
                  value={formData.stock_quantity}
                  onChange={(e) => setFormData({...formData, stock_quantity: e.target.value})}
                  placeholder="0"
                  data-testid="product-stock"
                />
              </div>
              <div>
                <Label htmlFor="unit">Unidade</Label>
                <Select 
                  value={formData.unit} 
                  onValueChange={(v) => setFormData({...formData, unit: v})}
                >
                  <SelectTrigger data-testid="product-unit">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {UNITS.map(unit => (
                      <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={saving} data-testid="save-product-btn">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                {editingItem ? 'Salvar' : 'Criar'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default ResaleProductsPage;
