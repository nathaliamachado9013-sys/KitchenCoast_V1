import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { createRestaurant } from '../lib/api';
import { ChefHat, Loader2 } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { useToast } from '../hooks/use-toast';

const OnboardingPage = () => {
  const { restaurant, updateRestaurant } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    phone: ''
  });

  useEffect(() => {
    // If already has restaurant, redirect to dashboard
    if (restaurant) {
      navigate('/dashboard', { replace: true });
    }
  }, [restaurant, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast({
        title: 'Erro',
        description: 'Nome do restaurante é obrigatório',
        variant: 'destructive'
      });
      return;
    }

    setLoading(true);
    try {
      const response = await createRestaurant(formData);
      updateRestaurant(response.data);
      toast({
        title: 'Sucesso!',
        description: 'Restaurante criado com sucesso',
      });
      navigate('/dashboard', { replace: true });
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao criar restaurante',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-6">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="logo justify-center mb-4">
            <div className="logo-icon">
              <ChefHat className="w-5 h-5" />
            </div>
            <span>KitchenCost</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Configure seu restaurante</h1>
          <p className="text-muted-foreground mt-2">
            Informe os dados do seu estabelecimento para começar
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <Label htmlFor="name">Nome do Restaurante *</Label>
            <Input
              id="name"
              placeholder="Ex: Restaurante Sabor & Arte"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              data-testid="restaurant-name-input"
            />
          </div>

          <div>
            <Label htmlFor="address">Endereço</Label>
            <Input
              id="address"
              placeholder="Ex: Rua das Flores, 123"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              data-testid="restaurant-address-input"
            />
          </div>

          <div>
            <Label htmlFor="phone">Telefone</Label>
            <Input
              id="phone"
              placeholder="Ex: (11) 99999-9999"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              data-testid="restaurant-phone-input"
            />
          </div>

          <Button 
            type="submit" 
            className="w-full"
            disabled={loading}
            data-testid="create-restaurant-btn"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                Criando...
              </>
            ) : (
              'Criar Restaurante'
            )}
          </Button>
        </form>
      </div>
    </div>
  );
};

export default OnboardingPage;
