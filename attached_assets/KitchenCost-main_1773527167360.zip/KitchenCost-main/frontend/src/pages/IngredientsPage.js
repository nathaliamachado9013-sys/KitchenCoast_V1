import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { 
  getIngredients, 
  createIngredient, 
  updateIngredient, 
  deleteIngredient,
  getSuppliers,
  formatCurrency,
  formatNumber,
  getCurrencySymbol,
  exportIngredientsExcel
} from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import { useToast } from '../hooks/use-toast';
import { 
  Plus, 
  Search, 
  Loader2, 
  Pencil, 
  Trash2, 
  AlertTriangle,
  ShoppingBasket,
  Download,
  History
} from 'lucide-react';
import ImportIngredients from '../components/ImportIngredients';
import PriceHistoryModal from '../components/PriceHistoryModal';

const UNITS = ['kg', 'g', 'l', 'ml', 'unidade', 'dúzia', 'pacote', 'caixa'];
const CATEGORIES = ['Carnes', 'Vegetais', 'Frutas', 'Laticínios', 'Grãos', 'Temperos', 'Bebidas', 'Outros'];

const IngredientsPage = () => {
  const { currency } = useAuth();
  const [ingredients, setIngredients] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [lowStockFilter, setLowStockFilter] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [priceHistoryOpen, setPriceHistoryOpen] = useState(false);
  const [selectedIngredient, setSelectedIngredient] = useState(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    unit: 'kg',
    purchase_unit: '',
    cost_per_unit: '',
    supplier_id: '',
    current_stock: '0',
    min_stock: '0',
    category: ''
  });

  useEffect(() => {
    loadData();
  }, [search, categoryFilter, lowStockFilter]);

  const loadData = async () => {
    try {
      const [ingredientsRes, suppliersRes] = await Promise.all([
        getIngredients({ search, category: categoryFilter || undefined, low_stock: lowStockFilter }),
        getSuppliers()
      ]);
      setIngredients(ingredientsRes.data);
      setSuppliers(suppliersRes.data);
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao carregar ingredientes',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const openModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        name: item.name,
        unit: item.unit,
        purchase_unit: item.purchase_unit || '',
        cost_per_unit: item.cost_per_unit.toString(),
        supplier_id: item.supplier_id || '',
        current_stock: item.current_stock.toString(),
        min_stock: item.min_stock.toString(),
        category: item.category || ''
      });
    } else {
      setEditingItem(null);
      setFormData({
        name: '',
        unit: 'kg',
        purchase_unit: '',
        cost_per_unit: '',
        supplier_id: '',
        current_stock: '0',
        min_stock: '0',
        category: ''
      });
    }
    setModalOpen(true);
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      const response = await exportIngredientsExcel();
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'ingredientes.xlsx');
      document.body.appendChild(link);
      link.click();
      link.remove();
      toast({ title: 'Exportação concluída!' });
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao exportar',
        variant: 'destructive'
      });
    } finally {
      setExporting(false);
    }
  };

  const openPriceHistory = (item) => {
    setSelectedIngredient(item);
    setPriceHistoryOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.cost_per_unit) {
      toast({
        title: 'Erro',
        description: 'Preencha os campos obrigatórios',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      const data = {
        ...formData,
        cost_per_unit: parseFloat(formData.cost_per_unit),
        current_stock: parseFloat(formData.current_stock || 0),
        min_stock: parseFloat(formData.min_stock || 0),
        supplier_id: formData.supplier_id || null,
        category: formData.category || null,
        purchase_unit: formData.purchase_unit || null
      };

      if (editingItem) {
        await updateIngredient(editingItem.ingredient_id, data);
        toast({ title: 'Ingrediente atualizado!' });
      } else {
        await createIngredient(data);
        toast({ title: 'Ingrediente criado!' });
      }
      
      setModalOpen(false);
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao salvar',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (item) => {
    if (!window.confirm(`Excluir "${item.name}"?`)) return;
    
    try {
      await deleteIngredient(item.ingredient_id);
      toast({ title: 'Ingrediente excluído!' });
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao excluir',
        variant: 'destructive'
      });
    }
  };

  const getStockStatus = (item) => {
    if (item.current_stock <= 0) return 'critical';
    if (item.current_stock <= item.min_stock) return 'low';
    return 'ok';
  };

  return (
    <Layout 
      title="Ingredientes"
      actions={
        <div className="flex gap-2">
          <ImportIngredients onSuccess={loadData} />
          <Button 
            variant="outline" 
            onClick={handleExport}
            disabled={exporting}
            data-testid="export-ingredients-btn"
          >
            {exporting ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Download className="w-4 h-4 mr-2" />
            )}
            Exportar
          </Button>
          <Button onClick={() => openModal()} data-testid="add-ingredient-btn">
            <Plus className="w-4 h-4 mr-2" />
            Novo Ingrediente
          </Button>
        </div>
      }
    >
      {/* Filters */}
      <div className="flex gap-4 mb-6">
        <div className="flex-1 search-input">
          <Search className="w-4 h-4" />
          <Input
            placeholder="Buscar ingredientes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
            data-testid="search-input"
          />
        </div>
        <Select value={categoryFilter || "all"} onValueChange={(v) => setCategoryFilter(v === "all" ? "" : v)}>
          <SelectTrigger className="w-48" data-testid="category-filter">
            <SelectValue placeholder="Todas categorias" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas categorias</SelectItem>
            {CATEGORIES.map(cat => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          variant={lowStockFilter ? "default" : "outline"}
          onClick={() => setLowStockFilter(!lowStockFilter)}
          data-testid="low-stock-filter"
        >
          <AlertTriangle className="w-4 h-4 mr-2" />
          Estoque Baixo
        </Button>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : ingredients.length === 0 ? (
        <div className="empty-state">
          <ShoppingBasket className="empty-state-icon" />
          <h3 className="font-semibold text-lg mb-1">Nenhum ingrediente</h3>
          <p className="text-muted-foreground mb-4">Comece cadastrando seus ingredientes</p>
          <Button onClick={() => openModal()}>
            <Plus className="w-4 h-4 mr-2" />
            Novo Ingrediente
          </Button>
        </div>
      ) : (
        <div className="bg-white rounded-xl border overflow-hidden">
          <table className="data-table" data-testid="ingredients-table">
            <thead className="bg-muted/30">
              <tr>
                <th>Nome</th>
                <th>Categoria</th>
                <th>Fornecedor</th>
                <th className="text-right">Custo/Unidade</th>
                <th className="text-right">Estoque</th>
                <th className="text-center">Status</th>
                <th className="text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {ingredients.map(item => {
                const status = getStockStatus(item);
                return (
                  <tr key={item.ingredient_id} data-testid={`ingredient-row-${item.ingredient_id}`}>
                    <td className="font-medium">{item.name}</td>
                    <td className="text-muted-foreground">{item.category || '-'}</td>
                    <td className="text-muted-foreground">{item.supplier_name || '-'}</td>
                    <td className="text-right font-mono">
                      {formatCurrency(item.cost_per_unit, currency)}/{item.unit}
                    </td>
                    <td className="text-right font-mono">
                      {formatNumber(item.current_stock)} {item.unit}
                    </td>
                    <td className="text-center">
                      <span className={`stock-indicator stock-${status}`}>
                        <span className="stock-dot"></span>
                        {status === 'ok' ? 'OK' : status === 'low' ? 'Baixo' : 'Crítico'}
                      </span>
                    </td>
                    <td>
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openPriceHistory(item)}
                          title="Histórico de preços"
                          data-testid={`history-${item.ingredient_id}`}
                        >
                          <History className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openModal(item)}
                          data-testid={`edit-${item.ingredient_id}`}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          onClick={() => handleDelete(item)}
                          data-testid={`delete-${item.ingredient_id}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingItem ? 'Editar Ingrediente' : 'Novo Ingrediente'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="form-grid">
              <div>
                <Label htmlFor="name">Nome *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Ex: Filé Mignon"
                  data-testid="ingredient-name"
                />
              </div>
              <div>
                <Label htmlFor="category">Categoria</Label>
                <Select 
                  value={formData.category} 
                  onValueChange={(v) => setFormData({...formData, category: v})}
                >
                  <SelectTrigger data-testid="ingredient-category">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="form-grid">
              <div>
                <Label htmlFor="unit">Unidade *</Label>
                <Select 
                  value={formData.unit} 
                  onValueChange={(v) => setFormData({...formData, unit: v})}
                >
                  <SelectTrigger data-testid="ingredient-unit">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {UNITS.map(unit => (
                      <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="cost">Custo por Unidade ({getCurrencySymbol(currency)}) *</Label>
                <Input
                  id="cost"
                  type="number"
                  step="0.01"
                  value={formData.cost_per_unit}
                  onChange={(e) => setFormData({...formData, cost_per_unit: e.target.value})}
                  placeholder="0.00"
                  data-testid="ingredient-cost"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="supplier">Fornecedor</Label>
              <Select 
                value={formData.supplier_id || "none"} 
                onValueChange={(v) => setFormData({...formData, supplier_id: v === "none" ? "" : v})}
              >
                <SelectTrigger data-testid="ingredient-supplier">
                  <SelectValue placeholder="Selecione um fornecedor" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Nenhum</SelectItem>
                  {suppliers.map(sup => (
                    <SelectItem key={sup.supplier_id} value={sup.supplier_id}>
                      {sup.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="form-grid">
              <div>
                <Label htmlFor="stock">Estoque Atual</Label>
                <Input
                  id="stock"
                  type="number"
                  step="0.01"
                  value={formData.current_stock}
                  onChange={(e) => setFormData({...formData, current_stock: e.target.value})}
                  data-testid="ingredient-stock"
                />
              </div>
              <div>
                <Label htmlFor="min_stock">Estoque Mínimo</Label>
                <Input
                  id="min_stock"
                  type="number"
                  step="0.01"
                  value={formData.min_stock}
                  onChange={(e) => setFormData({...formData, min_stock: e.target.value})}
                  data-testid="ingredient-min-stock"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={saving} data-testid="save-ingredient-btn">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                {editingItem ? 'Salvar' : 'Criar'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Price History Modal */}
      <PriceHistoryModal
        ingredientId={selectedIngredient?.ingredient_id}
        ingredientName={selectedIngredient?.name}
        isOpen={priceHistoryOpen}
        onClose={() => setPriceHistoryOpen(false)}
      />
    </Layout>
  );
};

export default IngredientsPage;
