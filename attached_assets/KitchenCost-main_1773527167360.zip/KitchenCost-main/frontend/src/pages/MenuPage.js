import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { 
  getMenuCategories,
  getMenuProfitability,
  getRecipes,
  getResaleProducts,
  createMenuItem,
  deleteMenuItem,
  formatCurrency,
  formatNumber,
  getCurrencySymbol
} from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '../components/ui/tooltip';
import { useToast } from '../hooks/use-toast';
import { 
  Search, 
  Loader2, 
  UtensilsCrossed,
  BookOpen,
  Wine,
  TrendingUp,
  Package,
  Plus,
  Layers,
  X,
  Trash2,
  DollarSign,
  Star,
  Target,
  Puzzle,
  AlertCircle,
  Calendar
} from 'lucide-react';

const ITEM_TYPES = [
  { value: 'recipe', label: 'Receita', icon: BookOpen },
  { value: 'resale_product', label: 'Produto de Revenda', icon: Wine },
  { value: 'composite_dish', label: 'Prato Composto', icon: Layers }
];

const PERIODS = [
  { value: 'today', label: 'Hoje' },
  { value: 'week', label: 'Semana' },
  { value: 'month', label: 'Mês' },
  { value: 'year', label: 'Ano' },
];

const CLASSIFICATION_CONFIG = {
  STAR: { 
    label: 'Estrela', 
    color: 'bg-green-100 text-green-700 border-green-200', 
    icon: Star, 
    description: 'Excelente retorno',
    tooltip: 'Vende bem e gera bom lucro. É um dos melhores itens do cardápio.'
  },
  PLOWHORSE: { 
    label: 'Cavalo de Carga', 
    color: 'bg-yellow-100 text-yellow-700 border-yellow-200', 
    icon: Target, 
    description: 'Vende bem, lucro baixo',
    tooltip: 'Vende bem, mas gera pouco lucro. Pode precisar de ajuste de preço ou custo.'
  },
  PUZZLE: { 
    label: 'Enigma', 
    color: 'bg-blue-100 text-blue-700 border-blue-200', 
    icon: Puzzle, 
    description: 'Boa margem, baixa saída',
    tooltip: 'Gera bom lucro, mas vende pouco. Pode precisar de mais destaque ou melhor apresentação.'
  },
  DOG: { 
    label: 'Fraco', 
    color: 'bg-red-100 text-red-700 border-red-200', 
    icon: AlertCircle, 
    description: 'Precisa revisar',
    tooltip: 'Vende pouco e gera pouco lucro. Pode valer revisar ou retirar do cardápio.'
  },
  UNCLASSIFIED: { 
    label: 'Sem dados', 
    color: 'bg-gray-100 text-gray-500 border-gray-200', 
    icon: null, 
    description: 'Sem preço ou vendas',
    tooltip: 'Item sem dados suficientes para classificação.'
  }
};

const MenuPage = () => {
  const { currency } = useAuth();
  const navigate = useNavigate();
  const [menuItems, setMenuItems] = useState([]);
  const [profitSummary, setProfitSummary] = useState(null);
  const [classificationCounts, setClassificationCounts] = useState({});
  const [categories, setCategories] = useState([]);
  const [recipes, setRecipes] = useState([]);
  const [resaleProducts, setResaleProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [period, setPeriod] = useState('month');
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    category: '',
    item_type: '',
    recipe_id: '',
    product_id: '',
    components: [],
    desired_margin: '',
    sale_price: ''
  });

  useEffect(() => {
    loadData();
  }, [period]);

  useEffect(() => {
    // Apply client-side filters
  }, [search, typeFilter, categoryFilter]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [profitRes, catRes, recipesRes, productsRes] = await Promise.all([
        getMenuProfitability(period),
        getMenuCategories(),
        getRecipes(),
        getResaleProducts()
      ]);
      
      let items = profitRes.data.items || [];
      
      // Apply client-side filters
      if (search) {
        items = items.filter(i => i.name.toLowerCase().includes(search.toLowerCase()));
      }
      if (typeFilter) {
        if (typeFilter === 'composite_dish') {
          items = items.filter(i => i.item_type === 'composite_dish');
        } else if (typeFilter === 'recipe_item') {
          items = items.filter(i => i.item_type === 'recipe_item' || i.item_type === 'recipe');
        } else {
          items = items.filter(i => i.item_type === typeFilter);
        }
      }
      if (categoryFilter) {
        items = items.filter(i => i.category === categoryFilter);
      }
      
      setMenuItems(items);
      setProfitSummary(profitRes.data.summary);
      setClassificationCounts(profitRes.data.classification_counts || {});
      setCategories(catRes.data);
      setRecipes(recipesRes.data);
      setResaleProducts(productsRes.data);
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao carregar cardápio',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const openModal = () => {
    setFormData({
      name: '',
      category: '',
      item_type: '',
      recipe_id: '',
      product_id: '',
      components: [],
      desired_margin: '',
      sale_price: ''
    });
    setModalOpen(true);
  };

  const handleItemClick = (item) => {
    if (item.item_type === 'recipe_item') {
      navigate('/recipes');
    } else if (item.item_type === 'resale_product') {
      navigate('/resale-products');
    }
  };

  const handleDelete = async (item) => {
    if (!item.menu_item_id) return;
    if (!window.confirm(`Remover "${item.name}" do cardápio?`)) return;
    
    try {
      await deleteMenuItem(item.menu_item_id);
      toast({ title: 'Item removido do cardápio!' });
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao remover',
        variant: 'destructive'
      });
    }
  };

  const addComponent = () => {
    setFormData({
      ...formData,
      components: [...formData.components, { component_type: '', component_id: '', quantity: '1' }]
    });
  };

  const updateComponent = (index, field, value) => {
    const updated = [...formData.components];
    updated[index][field] = value;
    setFormData({ ...formData, components: updated });
  };

  const removeComponent = (index) => {
    const updated = formData.components.filter((_, i) => i !== index);
    setFormData({ ...formData, components: updated });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.item_type) {
      toast({
        title: 'Erro',
        description: 'Nome e tipo são obrigatórios',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      const data = {
        name: formData.name,
        category: formData.category || null,
        item_type: formData.item_type,
        recipe_id: formData.item_type === 'recipe' ? formData.recipe_id : null,
        product_id: formData.item_type === 'resale_product' ? formData.product_id : null,
        components: formData.item_type === 'composite_dish' 
          ? formData.components.filter(c => c.component_type && c.component_id).map(c => ({
              component_type: c.component_type,
              component_id: c.component_id,
              quantity: parseFloat(c.quantity) || 1
            }))
          : [],
        desired_margin: formData.desired_margin ? parseFloat(formData.desired_margin) / 100 : 0,
        sale_price: parseFloat(formData.sale_price) || 0
      };

      await createMenuItem(data);
      toast({ title: 'Item adicionado ao cardápio!' });
      setModalOpen(false);
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao criar item',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  // Calculate cost preview for composite dish
  const calculatePreviewCost = () => {
    if (formData.item_type === 'recipe' && formData.recipe_id) {
      const recipe = recipes.find(r => r.recipe_id === formData.recipe_id);
      return recipe?.cost_per_portion || 0;
    }
    if (formData.item_type === 'resale_product' && formData.product_id) {
      const product = resaleProducts.find(p => p.product_id === formData.product_id);
      return product?.purchase_cost || 0;
    }
    if (formData.item_type === 'composite_dish') {
      return formData.components.reduce((sum, comp) => {
        const qty = parseFloat(comp.quantity) || 1;
        if (comp.component_type === 'recipe') {
          const recipe = recipes.find(r => r.recipe_id === comp.component_id);
          return sum + (recipe?.cost_per_portion || 0) * qty;
        }
        if (comp.component_type === 'resale_product') {
          const product = resaleProducts.find(p => p.product_id === comp.component_id);
          return sum + (product?.purchase_cost || 0) * qty;
        }
        return sum;
      }, 0);
    }
    return 0;
  };

  const previewCost = calculatePreviewCost();
  const desiredMarginDecimal = parseFloat(formData.desired_margin) / 100 || 0;
  const suggestedPrice = previewCost > 0 && desiredMarginDecimal > 0 && desiredMarginDecimal < 1
    ? previewCost / (1 - desiredMarginDecimal)
    : 0;

  const getMarginColor = (margin) => {
    if (margin >= 60) return 'text-green-600';
    if (margin >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getMarginBg = (margin) => {
    if (margin >= 60) return 'bg-green-50';
    if (margin >= 40) return 'bg-yellow-50';
    return 'bg-red-50';
  };

  const getItemTypeBadge = (itemType) => {
    switch (itemType) {
      case 'recipe':
      case 'recipe_item':
        return { bg: 'bg-blue-100 text-blue-700', label: 'Receita', icon: BookOpen };
      case 'resale_product':
        return { bg: 'bg-purple-100 text-purple-700', label: 'Revenda', icon: Wine };
      case 'composite_dish':
        return { bg: 'bg-amber-100 text-amber-700', label: 'Composto', icon: Layers };
      default:
        return { bg: 'bg-gray-100 text-gray-700', label: itemType, icon: UtensilsCrossed };
    }
  };

  return (
    <Layout 
      title="Cardápio"
      actions={
        <div className="flex gap-2">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-32" data-testid="period-select">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PERIODS.map(p => (
                <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={openModal} data-testid="add-menu-item-btn">
            <Plus className="w-4 h-4 mr-2" />
            Adicionar Item
          </Button>
        </div>
      }
    >
      {/* Filters */}
      <div className="flex gap-4 mb-6">
        <div className="flex-1 search-input">
          <Search className="w-4 h-4" />
          <Input
            placeholder="Buscar no cardápio..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); loadData(); }}
            className="pl-10"
            data-testid="search-input"
          />
        </div>
        <Select value={typeFilter || "all"} onValueChange={(v) => { setTypeFilter(v === "all" ? "" : v); loadData(); }}>
          <SelectTrigger className="w-40" data-testid="type-filter">
            <SelectValue placeholder="Tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="recipe_item">Receitas</SelectItem>
            <SelectItem value="resale_product">Revenda</SelectItem>
            <SelectItem value="composite_dish">Compostos</SelectItem>
          </SelectContent>
        </Select>
        <Select value={categoryFilter || "all"} onValueChange={(v) => { setCategoryFilter(v === "all" ? "" : v); loadData(); }}>
          <SelectTrigger className="w-48" data-testid="category-filter">
            <SelectValue placeholder="Categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas categorias</SelectItem>
            {categories.map(cat => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Profit Summary Cards */}
      <div className="grid grid-cols-5 gap-4 mb-6">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="metric-value text-green-600">{formatCurrency(profitSummary?.total_profit_period || 0, currency)}</div>
              <div className="metric-label">Lucro no Período</div>
            </div>
            <div className="p-2.5 rounded-lg bg-green-50">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </div>
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="metric-value">{profitSummary?.total_items_sold || 0}</div>
              <div className="metric-label">Itens Vendidos</div>
            </div>
            <div className="p-2.5 rounded-lg bg-blue-50">
              <Package className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="stat-card border-l-4 border-l-green-500 cursor-help">
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-green-600" />
                  <span className="font-medium">Estrelas</span>
                  <span className="ml-auto text-xl font-bold">{classificationCounts.STAR || 0}</span>
                </div>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>{CLASSIFICATION_CONFIG.STAR.tooltip}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="stat-card border-l-4 border-l-blue-500 cursor-help">
                <div className="flex items-center gap-2">
                  <Puzzle className="w-4 h-4 text-blue-600" />
                  <span className="font-medium">Enigmas</span>
                  <span className="ml-auto text-xl font-bold">{classificationCounts.PUZZLE || 0}</span>
                </div>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>{CLASSIFICATION_CONFIG.PUZZLE.tooltip}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="stat-card border-l-4 border-l-yellow-500 cursor-help">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-yellow-600" />
                  <span className="font-medium">Cavalo de Carga</span>
                  <span className="ml-auto text-xl font-bold">{classificationCounts.PLOWHORSE || 0}</span>
                </div>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>{CLASSIFICATION_CONFIG.PLOWHORSE.tooltip}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : menuItems.length === 0 ? (
        <div className="empty-state">
          <UtensilsCrossed className="empty-state-icon" />
          <h3 className="font-semibold text-lg mb-1">Cardápio vazio</h3>
          <p className="text-muted-foreground mb-4">Adicione itens ao cardápio</p>
          <Button onClick={openModal}>
            <Plus className="w-4 h-4 mr-2" />
            Adicionar Item
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" data-testid="menu-grid">
          {menuItems.map(item => {
            const badge = getItemTypeBadge(item.item_type);
            const BadgeIcon = badge.icon;
            const profit = item.profit_per_unit || (item.sale_price - item.cost);
            
            return (
              <div 
                key={item.menu_item_id || `${item.item_type}-${item.item_id}`}
                className="recipe-card relative group"
                data-testid={`menu-item-${item.item_id || item.menu_item_id}`}
              >
                {item.is_custom && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-red-600 hover:bg-red-50"
                    onClick={(e) => { e.stopPropagation(); handleDelete(item); }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
                
                <div 
                  className={`${!item.is_custom ? 'cursor-pointer' : ''}`}
                  onClick={() => !item.is_custom && handleItemClick(item)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1 pr-8">
                      <h3 className="font-semibold text-lg leading-tight">{item.name}</h3>
                      <div className="flex flex-wrap items-center gap-2 mt-1.5">
                        {item.category && (
                          <span className="text-xs bg-muted px-2 py-0.5 rounded-full">
                            {item.category}
                          </span>
                        )}
                        <span className={`text-xs px-2 py-0.5 rounded-full inline-flex items-center gap-1 ${badge.bg}`}>
                          <BadgeIcon className="w-3 h-3" />
                          {badge.label}
                        </span>
                      </div>
                    </div>
                    {/* Classification Badge with Tooltip */}
                    {item.classification && CLASSIFICATION_CONFIG[item.classification] && (
                      (() => {
                        const config = CLASSIFICATION_CONFIG[item.classification];
                        const Icon = config.icon;
                        return (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className={`px-2 py-1 rounded-md text-xs font-semibold border cursor-help ${config.color}`}>
                                  {Icon && <Icon className="w-3 h-3 inline mr-1" />}
                                  {config.label}
                                </div>
                              </TooltipTrigger>
                              <TooltipContent side="left" className="max-w-xs">
                                <p className="font-semibold mb-1">{config.description}</p>
                                <p className="text-xs">{config.tooltip}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        );
                      })()
                    )}
                  </div>

                  {/* Cost Breakdown */}
                  <div className="space-y-1.5 text-sm mb-3">
                    <div className="flex justify-between text-muted-foreground">
                      <span>Custo:</span>
                      <span className="font-medium text-foreground">{formatCurrency(item.cost, currency)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Preço:</span>
                      <span className="font-semibold text-foreground">{formatCurrency(item.sale_price, currency)}</span>
                    </div>
                    <div className="flex justify-between text-green-600">
                      <span>Lucro/un:</span>
                      <span className="font-semibold">{formatCurrency(item.profit_per_unit || profit, currency)}</span>
                    </div>
                  </div>

                  {/* Sales Period Data */}
                  {(item.units_sold_period > 0 || item.total_profit_period > 0) && (
                    <div className="bg-muted/50 rounded-lg p-2.5 mb-3 space-y-1.5 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Vendidos:</span>
                        <span className="font-medium">{item.units_sold_period || 0} un</span>
                      </div>
                      <div className="flex justify-between text-green-600">
                        <span>Lucro período:</span>
                        <span className="font-bold">{formatCurrency(item.total_profit_period || 0, currency)}</span>
                      </div>
                    </div>
                  )}

                  {/* Margin */}
                  <div className={`rounded-lg p-3 ${getMarginBg(item.margin)}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <TrendingUp className={`w-4 h-4 ${getMarginColor(item.margin)}`} />
                        <span className="text-sm font-medium">Margem</span>
                      </div>
                      <span className={`text-lg font-bold ${getMarginColor(item.margin)}`}>
                        {formatNumber(item.margin, 1)}%
                      </span>
                    </div>
                  </div>

                  {/* Stock for resale products */}
                  {item.item_type === 'resale_product' && item.stock_quantity !== undefined && (
                    <div className="mt-3 pt-3 border-t flex items-center justify-between text-sm">
                      <div className="flex items-center gap-1.5 text-muted-foreground">
                        <Package className="w-4 h-4" />
                        <span>Estoque:</span>
                      </div>
                      <span className={`font-medium ${item.stock_quantity <= 5 ? 'text-red-600' : 'text-foreground'}`}>
                        {item.stock_quantity} {item.unit}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Adicionar Item ao Cardápio</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nome do Item *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Ex: Prato do Chef"
                  data-testid="menu-item-name"
                />
              </div>
              <div>
                <Label htmlFor="category">Categoria</Label>
                <Select 
                  value={formData.category || "none"} 
                  onValueChange={(v) => setFormData({...formData, category: v === "none" ? "" : v})}
                >
                  <SelectTrigger data-testid="menu-item-category">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Selecione</SelectItem>
                    {categories.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Tipo de Item *</Label>
              <div className="grid grid-cols-3 gap-3 mt-2">
                {ITEM_TYPES.map(type => {
                  const Icon = type.icon;
                  return (
                    <button
                      key={type.value}
                      type="button"
                      onClick={() => setFormData({...formData, item_type: type.value, recipe_id: '', product_id: '', components: []})}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        formData.item_type === type.value 
                          ? 'border-primary bg-primary/5' 
                          : 'border-border hover:border-muted-foreground/50'
                      }`}
                      data-testid={`item-type-${type.value}`}
                    >
                      <Icon className={`w-6 h-6 mx-auto mb-2 ${formData.item_type === type.value ? 'text-primary' : 'text-muted-foreground'}`} />
                      <span className={`text-sm font-medium ${formData.item_type === type.value ? 'text-primary' : ''}`}>
                        {type.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Recipe Selection */}
            {formData.item_type === 'recipe' && (
              <div>
                <Label>Selecione a Receita *</Label>
                <Select 
                  value={formData.recipe_id || "none"} 
                  onValueChange={(v) => setFormData({...formData, recipe_id: v === "none" ? "" : v})}
                >
                  <SelectTrigger data-testid="select-recipe">
                    <SelectValue placeholder="Selecione uma receita" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Selecione</SelectItem>
                    {recipes.map(recipe => (
                      <SelectItem key={recipe.recipe_id} value={recipe.recipe_id}>
                        {recipe.name} - {formatCurrency(recipe.cost_per_portion, currency)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Resale Product Selection */}
            {formData.item_type === 'resale_product' && (
              <div>
                <Label>Selecione o Produto *</Label>
                <Select 
                  value={formData.product_id || "none"} 
                  onValueChange={(v) => setFormData({...formData, product_id: v === "none" ? "" : v})}
                >
                  <SelectTrigger data-testid="select-product">
                    <SelectValue placeholder="Selecione um produto" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Selecione</SelectItem>
                    {resaleProducts.map(product => (
                      <SelectItem key={product.product_id} value={product.product_id}>
                        {product.name} - {formatCurrency(product.purchase_cost, currency)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Composite Dish Components */}
            {formData.item_type === 'composite_dish' && (
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <Label className="flex items-center gap-2">
                    <Layers className="w-4 h-4" />
                    Componentes do Prato
                  </Label>
                  <Button type="button" variant="outline" size="sm" onClick={addComponent}>
                    <Plus className="w-4 h-4 mr-1" />
                    Adicionar
                  </Button>
                </div>
                <div className="space-y-3 max-h-48 overflow-y-auto">
                  {formData.components.map((comp, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <Select 
                        value={comp.component_type || "none"} 
                        onValueChange={(v) => updateComponent(idx, 'component_type', v === "none" ? "" : v)}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue placeholder="Tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Tipo</SelectItem>
                          <SelectItem value="recipe">Receita</SelectItem>
                          <SelectItem value="resale_product">Revenda</SelectItem>
                        </SelectContent>
                      </Select>
                      <Select 
                        value={comp.component_id || "none"} 
                        onValueChange={(v) => updateComponent(idx, 'component_id', v === "none" ? "" : v)}
                      >
                        <SelectTrigger className="flex-1">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Selecione</SelectItem>
                          {comp.component_type === 'recipe' && recipes.map(r => (
                            <SelectItem key={r.recipe_id} value={r.recipe_id}>{r.name}</SelectItem>
                          ))}
                          {comp.component_type === 'resale_product' && resaleProducts.map(p => (
                            <SelectItem key={p.product_id} value={p.product_id}>{p.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Input
                        type="number"
                        step="0.1"
                        min="0.1"
                        value={comp.quantity}
                        onChange={(e) => updateComponent(idx, 'quantity', e.target.value)}
                        className="w-20"
                        placeholder="Qtd"
                      />
                      <Button type="button" variant="ghost" size="sm" onClick={() => removeComponent(idx)} className="text-red-600">
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  {formData.components.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      Adicione componentes ao prato
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Pricing Section */}
            {formData.item_type && (
              <div className="border rounded-lg p-4 bg-muted/30">
                <Label className="flex items-center gap-2 mb-3">
                  <DollarSign className="w-4 h-4" />
                  Precificação
                </Label>
                
                {/* Cost Preview */}
                <div className="bg-background rounded-lg p-3 mb-4 border">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Custo calculado:</span>
                    <span className="font-semibold text-primary">{formatCurrency(previewCost, currency)}</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="margin" className="text-sm">Margem Desejada (%)</Label>
                    <Input
                      id="margin"
                      type="number"
                      step="1"
                      min="0"
                      max="99"
                      value={formData.desired_margin}
                      onChange={(e) => setFormData({...formData, desired_margin: e.target.value})}
                      placeholder="70"
                      data-testid="menu-item-margin"
                    />
                  </div>
                  <div>
                    <Label className="text-sm">Preço Sugerido</Label>
                    <div className="h-10 px-3 rounded-md border bg-muted flex items-center font-semibold text-primary">
                      {suggestedPrice > 0 ? formatCurrency(suggestedPrice, currency) : '-'}
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="sale_price" className="text-sm">Preço de Venda ({getCurrencySymbol(currency)})</Label>
                    <Input
                      id="sale_price"
                      type="number"
                      step="0.01"
                      value={formData.sale_price}
                      onChange={(e) => setFormData({...formData, sale_price: e.target.value})}
                      placeholder={suggestedPrice > 0 ? suggestedPrice.toFixed(2) : '0.00'}
                      data-testid="menu-item-price"
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={saving} data-testid="save-menu-item-btn">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Adicionar ao Cardápio
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default MenuPage;
