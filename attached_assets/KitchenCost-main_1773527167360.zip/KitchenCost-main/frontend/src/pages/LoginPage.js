import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { ChefHat, ArrowRight, BarChart3, BookOpen, Package, TrendingUp } from 'lucide-react';
import { Button } from '../components/ui/button';

const LoginPage = () => {
  const { login } = useAuth();

  const features = [
    { icon: BookOpen, title: 'Fichas Técnicas', desc: 'Calcule custos automaticamente' },
    { icon: Package, title: 'Controle de Estoque', desc: 'Alertas de reposição inteligentes' },
    { icon: BarChart3, title: 'Relatórios', desc: 'Analise por período' },
    { icon: TrendingUp, title: 'Margens', desc: 'Maximize seus lucros' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      {/* Header */}
      <header className="p-6">
        <div className="logo">
          <div className="logo-icon">
            <ChefHat className="w-5 h-5" />
          </div>
          <span>KitchenCost</span>
        </div>
      </header>

      {/* Hero */}
      <main className="max-w-6xl mx-auto px-6 py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left - Text */}
          <div>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight mb-6">
              Controle de custos{' '}
              <span className="text-primary">simplificado</span> para sua cozinha
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              Gerencie ingredientes, fichas técnicas e estoque em um só lugar. 
              Saiba exatamente quanto custa cada prato e maximize suas margens.
            </p>
            
            <Button 
              onClick={login}
              size="lg"
              className="gap-2"
              data-testid="login-btn"
            >
              Começar agora
              <ArrowRight className="w-5 h-5" />
            </Button>

            <p className="text-sm text-muted-foreground mt-4">
              Acesso gratuito • Login com Google
            </p>
          </div>

          {/* Right - Features */}
          <div className="grid grid-cols-2 gap-4">
            {features.map((feature, idx) => (
              <div 
                key={idx}
                className="bg-white p-5 rounded-xl border shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mb-3">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">{feature.title}</h3>
                <p className="text-sm text-gray-500">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-3 gap-8 text-center">
          <div>
            <div className="text-3xl font-bold text-primary">100%</div>
            <div className="text-sm text-gray-500 mt-1">Gratuito para começar</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-primary">Multi-tenant</div>
            <div className="text-sm text-gray-500 mt-1">Cada restaurante isolado</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-primary">Tempo real</div>
            <div className="text-sm text-gray-500 mt-1">Cálculos automáticos</div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default LoginPage;
