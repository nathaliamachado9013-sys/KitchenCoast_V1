import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { 
  getCostReport, 
  getMarginReport,
  getMenuProfitability,
  getAnalyticsMonthlyProfit,
  formatCurrency,
  formatNumber
} from '../lib/api';
import { Button } from '../components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '../components/ui/tabs';
import {
  Tooltip as UITooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '../components/ui/tooltip';
import { 
  Loader2, 
  BarChart3,
  TrendingUp,
  DollarSign,
  Calendar,
  Star,
  Target,
  Puzzle,
  AlertCircle,
  ArrowUpDown
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

const PERIODS = [
  { value: 'today', label: 'Hoje' },
  { value: 'week', label: 'Última Semana' },
  { value: 'month', label: 'Este Mês' },
  { value: 'year', label: 'Este Ano' },
];

const MARGIN_COLORS = {
  negative: '#ef4444',
  low: '#f59e0b',
  medium: '#3b82f6',
  good: '#22c55e',
  excellent: '#10b981'
};

const MARGIN_LABELS = {
  negative: 'Negativa (<0%)',
  low: 'Baixa (0-20%)',
  medium: 'Média (20-40%)',
  good: 'Boa (40-60%)',
  excellent: 'Excelente (>60%)'
};

const CLASSIFICATION_CONFIG = {
  STAR: { 
    label: 'Estrela', 
    color: 'bg-green-100 text-green-700', 
    icon: Star,
    tooltip: 'Vende bem e gera bom lucro. É um dos melhores itens do cardápio.'
  },
  PLOWHORSE: { 
    label: 'Cavalo de Carga', 
    color: 'bg-yellow-100 text-yellow-700', 
    icon: Target,
    tooltip: 'Vende bem, mas gera pouco lucro. Pode precisar de ajuste de preço ou custo.'
  },
  PUZZLE: { 
    label: 'Enigma', 
    color: 'bg-blue-100 text-blue-700', 
    icon: Puzzle,
    tooltip: 'Gera bom lucro, mas vende pouco. Pode precisar de mais destaque ou melhor apresentação.'
  },
  DOG: { 
    label: 'Fraco', 
    color: 'bg-red-100 text-red-700', 
    icon: AlertCircle,
    tooltip: 'Vende pouco e gera pouco lucro. Pode valer revisar ou retirar do cardápio.'
  },
  UNCLASSIFIED: { 
    label: 'Sem dados', 
    color: 'bg-gray-100 text-gray-500', 
    icon: null,
    tooltip: 'Item sem dados suficientes para classificação.'
  }
};

const ReportsPage = () => {
  const { currency } = useAuth();
  const [period, setPeriod] = useState('month');
  const [costReport, setCostReport] = useState(null);
  const [marginReport, setMarginReport] = useState(null);
  const [profitability, setProfitability] = useState(null);
  const [sortField, setSortField] = useState('total_profit_period');
  const [sortDir, setSortDir] = useState('desc');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [period]);

  const loadData = async () => {
    setLoading(true);
    try {
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;
      
      const [costRes, marginRes, profitRes] = await Promise.all([
        getCostReport({ period }),
        getMarginReport(),
        // Try to use analytics summary first, fallback to live calculation
        getAnalyticsMonthlyProfit(year, month).catch(() => getMenuProfitability(period))
      ]);
      setCostReport(costRes.data);
      setMarginReport(marginRes.data);
      setProfitability(profitRes.data);
    } catch (error) {
      console.error('Error loading reports:', error);
    } finally {
      setLoading(false);
    }
  };

  const sortedItems = profitability?.items ? [...profitability.items].sort((a, b) => {
    const aVal = a[sortField] || 0;
    const bVal = b[sortField] || 0;
    return sortDir === 'desc' ? bVal - aVal : aVal - bVal;
  }) : [];

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDir(sortDir === 'desc' ? 'asc' : 'desc');
    } else {
      setSortField(field);
      setSortDir('desc');
    }
  };

  const pieData = marginReport ? Object.entries(marginReport.margin_distribution)
    .filter(([_, count]) => count > 0)
    .map(([key, count]) => ({
      name: MARGIN_LABELS[key],
      value: count,
      color: MARGIN_COLORS[key]
    })) : [];

  return (
    <Layout 
      title="Relatórios"
      actions={
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-48" data-testid="period-select">
            <Calendar className="w-4 h-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {PERIODS.map(p => (
              <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      }
    >
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <Tabs defaultValue="costs" className="space-y-6">
          <TabsList>
            <TabsTrigger value="costs" data-testid="tab-costs">Custos</TabsTrigger>
            <TabsTrigger value="margins" data-testid="tab-margins">Margens</TabsTrigger>
            <TabsTrigger value="profitability" data-testid="tab-profitability">Rentabilidade do Cardápio</TabsTrigger>
          </TabsList>

          <TabsContent value="costs">
            {/* Cost Summary Cards */}
            <div className="grid grid-cols-3 gap-5 mb-6" data-testid="cost-summary">
              <div className="stat-card">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="metric-value text-2xl">
                      {formatCurrency(costReport?.total_purchases || 0, currency)}
                    </div>
                    <div className="metric-label">Total em Compras</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-blue-50">
                    <DollarSign className="w-5 h-5 text-blue-600" />
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="metric-value text-2xl">
                      {formatCurrency(costReport?.total_production_cost || 0, currency)}
                    </div>
                    <div className="metric-label">Custo de Produção</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-amber-50">
                    <BarChart3 className="w-5 h-5 text-amber-600" />
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="metric-value text-2xl">
                      {costReport?.productions_count || 0}
                    </div>
                    <div className="metric-label">Produções Registradas</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-green-50">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                  </div>
                </div>
              </div>
            </div>

            {/* Daily Cost Chart */}
            <div className="chart-container">
              <h3 className="font-semibold mb-4">Custos de Produção por Dia</h3>
              {costReport?.daily_breakdown?.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={costReport.daily_breakdown}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis 
                      dataKey="date" 
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value) => {
                        const date = new Date(value);
                        return `${date.getDate()}/${date.getMonth() + 1}`;
                      }}
                    />
                    <YAxis 
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value) => `R$ ${value}`}
                    />
                    <Tooltip 
                      formatter={(value) => [formatCurrency(value, currency), 'Custo']}
                      labelFormatter={(label) => new Date(label).toLocaleDateString('pt-BR')}
                    />
                    <Bar dataKey="cost" fill="hsl(152, 60%, 40%)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-64 text-muted-foreground">
                  Nenhuma produção registrada no período
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="margins">
            {/* Margin Summary Cards */}
            <div className="grid grid-cols-2 gap-5 mb-6" data-testid="margin-summary">
              <div className="stat-card">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="metric-value text-2xl">
                      {formatNumber(marginReport?.average_margin || 0, 1)}%
                    </div>
                    <div className="metric-label">Margem Média</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-green-50">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="metric-value text-2xl">
                      {marginReport?.total_recipes || 0}
                    </div>
                    <div className="metric-label">Receitas com Preço de Venda</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-blue-50">
                    <BarChart3 className="w-5 h-5 text-blue-600" />
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {/* Margin Distribution Chart */}
              <div className="chart-container">
                <h3 className="font-semibold mb-4">Distribuição de Margens</h3>
                {pieData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-64 text-muted-foreground">
                    Nenhuma receita com preço definido
                  </div>
                )}
                {/* Legend */}
                <div className="flex flex-wrap justify-center gap-3 mt-4">
                  {pieData.map((entry, index) => (
                    <div key={index} className="flex items-center gap-1.5 text-sm">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: entry.color }}
                      />
                      <span>{entry.name}: {entry.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recipes by Margin */}
              <div className="chart-container">
                <h3 className="font-semibold mb-4">Receitas por Faixa de Margem</h3>
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {Object.entries(marginReport?.recipes_by_margin || {}).map(([key, recipes]) => (
                    recipes.length > 0 && (
                      <div key={key} className="mb-4">
                        <div className="flex items-center gap-2 mb-2">
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ backgroundColor: MARGIN_COLORS[key] }}
                          />
                          <span className="font-medium text-sm">{MARGIN_LABELS[key]}</span>
                        </div>
                        <div className="space-y-1 pl-5">
                          {recipes.map((recipe, idx) => (
                            <div 
                              key={idx}
                              className="flex items-center justify-between text-sm py-1.5 border-b border-border/50 last:border-0"
                            >
                              <span>{recipe.name}</span>
                              <div className="flex items-center gap-3">
                                <span className="text-muted-foreground">
                                  Custo: {formatCurrency(recipe.cost_per_portion, currency)}
                                </span>
                                <span className="font-medium">
                                  {formatNumber(recipe.margin_percentage, 1)}%
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="profitability">
            {/* Profitability Summary */}
            <div className="grid grid-cols-4 gap-5 mb-6" data-testid="profitability-summary">
              <div className="stat-card">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="metric-value text-2xl text-green-600">
                      {formatCurrency(profitability?.summary?.total_profit_period || profitability?.summary?.total_profit || 0, currency)}
                    </div>
                    <div className="metric-label">Lucro Total</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-green-50">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="metric-value text-2xl">
                      {profitability?.summary?.total_items_sold || profitability?.summary?.total_units_sold || 0}
                    </div>
                    <div className="metric-label">Itens Vendidos</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-blue-50">
                    <BarChart3 className="w-5 h-5 text-blue-600" />
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="metric-value text-2xl">
                      {formatCurrency(profitability?.summary?.avg_profit_per_unit || 0, currency)}
                    </div>
                    <div className="metric-label">Lucro Médio/Item</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-amber-50">
                    <DollarSign className="w-5 h-5 text-amber-600" />
                  </div>
                </div>
              </div>

              <div className="stat-card">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="metric-value text-2xl">
                      {profitability?.summary?.total_items || 0}
                    </div>
                    <div className="metric-label">Itens no Cardápio</div>
                  </div>
                  <div className="p-2.5 rounded-lg bg-purple-50">
                    <Star className="w-5 h-5 text-purple-600" />
                  </div>
                </div>
              </div>
            </div>

            {/* Classification Summary */}
            <div className="grid grid-cols-4 gap-4 mb-6">
              {['STAR', 'PUZZLE', 'PLOWHORSE', 'DOG'].map(cls => {
                const config = CLASSIFICATION_CONFIG[cls];
                const Icon = config.icon;
                const count = profitability?.classification_counts?.[cls] || 0;
                return (
                  <TooltipProvider key={cls}>
                    <UITooltip>
                      <TooltipTrigger asChild>
                        <div className={`rounded-lg p-4 ${config.color} cursor-help`}>
                          <div className="flex items-center gap-2">
                            {Icon && <Icon className="w-5 h-5" />}
                            <span className="font-semibold">{config.label}</span>
                            <span className="ml-auto text-2xl font-bold">{count}</span>
                          </div>
                        </div>
                      </TooltipTrigger>
                      <TooltipContent side="bottom" className="max-w-xs">
                        <p>{config.tooltip}</p>
                      </TooltipContent>
                    </UITooltip>
                  </TooltipProvider>
                );
              })}
            </div>

            {/* Profitability Table */}
            <div className="chart-container">
              <h3 className="font-semibold mb-4">Rentabilidade por Item</h3>
              <div className="table-container max-h-96 overflow-y-auto">
                <table className="data-table">
                  <thead className="sticky top-0 bg-background">
                    <tr>
                      <th>Item</th>
                      <th>
                        <button onClick={() => handleSort('cost')} className="flex items-center gap-1 hover:text-primary">
                          Custo <ArrowUpDown className="w-3 h-3" />
                        </button>
                      </th>
                      <th>
                        <button onClick={() => handleSort('sale_price')} className="flex items-center gap-1 hover:text-primary">
                          Preço <ArrowUpDown className="w-3 h-3" />
                        </button>
                      </th>
                      <th>
                        <button onClick={() => handleSort('profit_per_unit')} className="flex items-center gap-1 hover:text-primary">
                          Lucro/Un <ArrowUpDown className="w-3 h-3" />
                        </button>
                      </th>
                      <th>
                        <button onClick={() => handleSort('units_sold_period')} className="flex items-center gap-1 hover:text-primary">
                          Vendidos <ArrowUpDown className="w-3 h-3" />
                        </button>
                      </th>
                      <th>
                        <button onClick={() => handleSort('total_profit_period')} className="flex items-center gap-1 hover:text-primary">
                          Lucro Total <ArrowUpDown className="w-3 h-3" />
                        </button>
                      </th>
                      <th>Classificação</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sortedItems.map((item, idx) => {
                      const cls = CLASSIFICATION_CONFIG[item.classification] || CLASSIFICATION_CONFIG.UNCLASSIFIED;
                      const ClsIcon = cls.icon;
                      // Support both old field names and new analytics summary field names
                      const itemName = item.name || item.item_name;
                      const costValue = item.cost || item.cost_total;
                      const salePrice = item.sale_price || item.revenue_total / (item.units_sold || 1);
                      const unitsSold = item.units_sold_period || item.units_sold || 0;
                      const totalProfit = item.total_profit_period || item.profit_total || 0;
                      return (
                        <tr key={idx}>
                          <td className="font-medium">{itemName}</td>
                          <td>{formatCurrency(costValue, currency)}</td>
                          <td>{formatCurrency(salePrice, currency)}</td>
                          <td className="text-green-600 font-medium">{formatCurrency(item.profit_per_unit, currency)}</td>
                          <td>{unitsSold}</td>
                          <td className="font-semibold text-green-600">{formatCurrency(totalProfit, currency)}</td>
                          <td>
                            <TooltipProvider>
                              <UITooltip>
                                <TooltipTrigger asChild>
                                  <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium cursor-help ${cls.color}`}>
                                    {ClsIcon && <ClsIcon className="w-3 h-3" />}
                                    {cls.label}
                                  </span>
                                </TooltipTrigger>
                                <TooltipContent side="left" className="max-w-xs">
                                  <p>{cls.tooltip}</p>
                                </TooltipContent>
                              </UITooltip>
                            </TooltipProvider>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      )}
    </Layout>
  );
};

export default ReportsPage;
