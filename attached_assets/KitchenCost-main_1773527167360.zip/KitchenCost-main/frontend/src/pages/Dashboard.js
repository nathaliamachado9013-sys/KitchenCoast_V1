import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { 
  getDashboardSummary, 
  getLowStockAlerts,
  getMenuProfitability,
  formatCurrency 
} from '../lib/api';
import { 
  ShoppingBasket, 
  BookOpen, 
  Truck, 
  AlertTriangle, 
  DollarSign, 
  TrendingUp,
  Loader2,
  Package,
  Star
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const { currency } = useAuth();
  const [summary, setSummary] = useState(null);
  const [lowStock, setLowStock] = useState([]);
  const [topProfitable, setTopProfitable] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [summaryRes, alertsRes, profitRes] = await Promise.all([
        getDashboardSummary(),
        getLowStockAlerts(),
        getMenuProfitability('month')
      ]);
      setSummary(summaryRes.data);
      setLowStock(alertsRes.data);
      setTopProfitable(profitRes.data.top_profitable || []);
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Layout title="Dashboard">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  const stats = [
    { 
      label: 'Ingredientes', 
      value: summary?.ingredients_count || 0, 
      icon: ShoppingBasket,
      color: 'text-blue-600',
      bg: 'bg-blue-50',
      onClick: () => navigate('/ingredients')
    },
    { 
      label: 'Fichas Técnicas', 
      value: summary?.recipes_count || 0, 
      icon: BookOpen,
      color: 'text-green-600',
      bg: 'bg-green-50',
      onClick: () => navigate('/recipes')
    },
    { 
      label: 'Fornecedores', 
      value: summary?.suppliers_count || 0, 
      icon: Truck,
      color: 'text-purple-600',
      bg: 'bg-purple-50',
      onClick: () => navigate('/suppliers')
    },
    { 
      label: 'Alertas Estoque', 
      value: summary?.low_stock_alerts || 0, 
      icon: AlertTriangle,
      color: summary?.low_stock_alerts > 0 ? 'text-red-600' : 'text-gray-400',
      bg: summary?.low_stock_alerts > 0 ? 'bg-red-50' : 'bg-gray-50',
      onClick: () => navigate('/stock')
    },
  ];

  const financialStats = [
    {
      label: 'Valor do Inventário',
      value: formatCurrency(summary?.inventory_value || 0, currency),
      icon: Package,
      color: 'text-emerald-600',
      bg: 'bg-emerald-50'
    },
    {
      label: 'Custo Produção Hoje',
      value: formatCurrency(summary?.today_production_cost || 0, currency),
      icon: DollarSign,
      color: 'text-amber-600',
      bg: 'bg-amber-50'
    },
    {
      label: 'Margem Média',
      value: `${summary?.average_margin || 0}%`,
      icon: TrendingUp,
      color: 'text-blue-600',
      bg: 'bg-blue-50'
    },
  ];

  return (
    <Layout title="Dashboard">
      {/* Low stock alert banner */}
      {lowStock.length > 0 && (
        <div className="alert-banner mb-6" data-testid="low-stock-alert">
          <AlertTriangle className="w-5 h-5" />
          <span>
            <strong>{lowStock.length} ingrediente(s)</strong> com estoque baixo precisam de reposição
          </span>
          <button 
            onClick={() => navigate('/stock')}
            className="ml-auto text-sm font-medium underline"
          >
            Ver detalhes
          </button>
        </div>
      )}

      {/* Main stats */}
      <div className="dashboard-grid mb-6" data-testid="stats-grid">
        {stats.map((stat, idx) => (
          <div 
            key={idx}
            className="stat-card cursor-pointer"
            onClick={stat.onClick}
            data-testid={`stat-${stat.label.toLowerCase().replace(/\s/g, '-')}`}
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="metric-value">{stat.value}</div>
                <div className="metric-label">{stat.label}</div>
              </div>
              <div className={`p-2.5 rounded-lg ${stat.bg}`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Financial stats */}
      <div className="grid grid-cols-3 gap-5 mb-6" data-testid="financial-stats">
        {financialStats.map((stat, idx) => (
          <div key={idx} className="stat-card">
            <div className="flex items-start justify-between">
              <div>
                <div className="metric-value text-2xl">{stat.value}</div>
                <div className="metric-label">{stat.label}</div>
              </div>
              <div className={`p-2.5 rounded-lg ${stat.bg}`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Top recipes by cost */}
      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="chart-container">
          <h3 className="font-semibold mb-4">Receitas com Maior Custo</h3>
          {summary?.top_recipes?.length > 0 ? (
            <div className="space-y-3">
              {summary.top_recipes.map((recipe, idx) => (
                <div 
                  key={idx}
                  className="flex items-center justify-between py-2 border-b border-border/50 last:border-0"
                >
                  <span className="font-medium">{recipe.name}</span>
                  <div className="flex items-center gap-4">
                    <span className="text-muted-foreground text-sm">
                      Margem: {recipe.margin_percentage?.toFixed(1) || 0}%
                    </span>
                    <span className="font-semibold">
                      {formatCurrency(recipe.total_cost, currency)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-sm">Nenhuma receita cadastrada</p>
          )}
        </div>

        <div className="chart-container">
          <div className="flex items-center gap-2 mb-4">
            <Star className="w-5 h-5 text-amber-500" />
            <h3 className="font-semibold">Top Itens Mais Lucrativos</h3>
            <span className="text-xs text-muted-foreground ml-auto">Este mês</span>
          </div>
          {topProfitable.length > 0 ? (
            <div className="space-y-3">
              {topProfitable.map((item, idx) => (
                <div 
                  key={idx}
                  className="flex items-center justify-between py-2 border-b border-border/50 last:border-0"
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-6 h-6 flex items-center justify-center rounded-full text-xs font-bold ${
                      idx === 0 ? 'bg-amber-100 text-amber-700' : 
                      idx === 1 ? 'bg-gray-100 text-gray-600' : 
                      'bg-orange-50 text-orange-600'
                    }`}>
                      {idx + 1}
                    </span>
                    <span className="font-medium">{item.name}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-muted-foreground text-sm">
                      {item.units_sold_period || 0} vendidos
                    </span>
                    <span className="font-semibold text-green-600">
                      {formatCurrency(item.total_profit_period || 0, currency)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-sm">Nenhuma venda registrada</p>
          )}
        </div>
      </div>

      <div className="chart-container">
        <h3 className="font-semibold mb-4">Ingredientes com Estoque Baixo</h3>
          {lowStock.length > 0 ? (
            <div className="space-y-3">
              {lowStock.slice(0, 5).map((item, idx) => (
                <div 
                  key={idx}
                  className="flex items-center justify-between py-2 border-b border-border/50 last:border-0"
                >
                  <span className="font-medium">{item.name}</span>
                  <div className="flex items-center gap-4">
                    <span className="text-red-600 text-sm font-medium">
                      {item.current_stock} {item.unit}
                    </span>
                    <span className="text-muted-foreground text-xs">
                      min: {item.min_stock} {item.unit}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-sm">Todos os itens com estoque adequado</p>
          )}
        </div>
    </Layout>
  );
};

export default Dashboard;
