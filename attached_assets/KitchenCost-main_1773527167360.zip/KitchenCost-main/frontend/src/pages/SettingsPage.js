import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { 
  updateRestaurant, 
  getSupportedCurrencies,
  getAllMenuCategories,
  createMenuCategory,
  updateMenuCategory,
  deleteMenuCategory,
  reorderMenuCategories
} from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../components/ui/dialog';
import { useToast } from '../hooks/use-toast';
import { 
  Loader2, 
  Building, 
  User, 
  Save, 
  Coins,
  Calculator,
  ChevronRight,
  Tag,
  Plus,
  Pencil,
  Trash2,
  GripVertical,
  Check,
  X
} from 'lucide-react';

const SettingsPage = () => {
  const navigate = useNavigate();
  const { user, restaurant, currency, updateRestaurant: updateRestaurantContext } = useAuth();
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [currencies, setCurrencies] = useState([]);
  const [currencySymbols, setCurrencySymbols] = useState({});
  const [categories, setCategories] = useState([]);
  const [categoryModalOpen, setCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [savingCategory, setSavingCategory] = useState(false);
  const [formData, setFormData] = useState({
    name: restaurant?.name || '',
    address: restaurant?.address || '',
    phone: restaurant?.phone || '',
    currency: restaurant?.currency || 'EUR'
  });

  useEffect(() => {
    loadCurrencies();
    loadCategories();
  }, []);

  useEffect(() => {
    if (restaurant) {
      setFormData({
        name: restaurant.name || '',
        address: restaurant.address || '',
        phone: restaurant.phone || '',
        currency: restaurant.currency || 'EUR'
      });
    }
  }, [restaurant]);

  const loadCurrencies = async () => {
    try {
      const response = await getSupportedCurrencies();
      setCurrencies(response.data.currencies);
      setCurrencySymbols(response.data.symbols);
    } catch (error) {
      // Use defaults
      setCurrencies(['EUR', 'USD', 'BRL', 'GBP']);
      setCurrencySymbols({ EUR: '€', USD: '$', BRL: 'R$', GBP: '£' });
    }
  };

  const loadCategories = async () => {
    try {
      const response = await getAllMenuCategories();
      setCategories(response.data);
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  };

  const openCategoryModal = (category = null) => {
    setEditingCategory(category);
    setNewCategoryName(category?.name || '');
    setCategoryModalOpen(true);
  };

  const handleSaveCategory = async () => {
    if (!newCategoryName.trim()) {
      toast({ title: 'Erro', description: 'Nome é obrigatório', variant: 'destructive' });
      return;
    }
    setSavingCategory(true);
    try {
      if (editingCategory) {
        await updateMenuCategory(editingCategory.category_id, { name: newCategoryName });
        toast({ title: 'Categoria atualizada!' });
      } else {
        await createMenuCategory({ name: newCategoryName });
        toast({ title: 'Categoria criada!' });
      }
      setCategoryModalOpen(false);
      loadCategories();
    } catch (error) {
      toast({ title: 'Erro', description: error.response?.data?.detail || 'Erro ao salvar', variant: 'destructive' });
    } finally {
      setSavingCategory(false);
    }
  };

  const handleDeleteCategory = async (category) => {
    if (!window.confirm(`Excluir categoria "${category.name}"?`)) return;
    try {
      await deleteMenuCategory(category.category_id, false);
      toast({ title: 'Categoria excluída!' });
      loadCategories();
    } catch (error) {
      if (error.response?.status === 400 && window.confirm(`Categoria em uso. Desativar?`)) {
        try {
          await deleteMenuCategory(category.category_id, true);
          toast({ title: 'Categoria desativada!' });
          loadCategories();
        } catch (e) {
          toast({ title: 'Erro', variant: 'destructive' });
        }
      }
    }
  };

  const handleToggleActive = async (category) => {
    try {
      await updateMenuCategory(category.category_id, { is_active: !category.is_active });
      toast({ title: category.is_active ? 'Desativada!' : 'Ativada!' });
      loadCategories();
    } catch (error) {
      toast({ title: 'Erro', variant: 'destructive' });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name) {
      toast({
        title: 'Erro',
        description: 'Nome é obrigatório',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      await updateRestaurant(formData);
      updateRestaurantContext({ ...restaurant, ...formData });
      toast({ title: 'Configurações salvas!' });
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao salvar',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Layout title="Configurações">
      <div className="max-w-2xl space-y-8">
        {/* User Info */}
        <div className="chart-container">
          <div className="flex items-center gap-3 mb-4">
            <User className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Informações do Usuário</h3>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-muted-foreground text-sm">Nome</Label>
              <p className="font-medium">{user?.name}</p>
            </div>
            <div>
              <Label className="text-muted-foreground text-sm">E-mail</Label>
              <p className="font-medium">{user?.email}</p>
            </div>
          </div>
        </div>

        {/* Restaurant Info */}
        <div className="chart-container">
          <div className="flex items-center gap-3 mb-4">
            <Building className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Dados do Restaurante</h3>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Nome do Restaurante *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Nome do estabelecimento"
                data-testid="settings-name"
              />
            </div>

            <div>
              <Label htmlFor="address">Endereço</Label>
              <Input
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                placeholder="Endereço completo"
                data-testid="settings-address"
              />
            </div>

            <div>
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                placeholder="(00) 00000-0000"
                data-testid="settings-phone"
              />
            </div>

            <div className="pt-4">
              <Button type="submit" disabled={saving} data-testid="save-settings-btn">
                {saving ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                Salvar Alterações
              </Button>
            </div>
          </form>
        </div>

        {/* Currency Settings */}
        <div className="chart-container">
          <div className="flex items-center gap-3 mb-4">
            <Coins className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Moeda</h3>
          </div>
          <div className="space-y-4">
            <div>
              <Label htmlFor="currency">Moeda do Sistema</Label>
              <Select 
                value={formData.currency} 
                onValueChange={(v) => {
                  setFormData({...formData, currency: v});
                }}
              >
                <SelectTrigger className="w-64" data-testid="settings-currency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map(curr => (
                    <SelectItem key={curr} value={curr}>
                      {currencySymbols[curr]} - {curr}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground mt-2">
                Todos os valores de preços, custos e relatórios serão exibidos nesta moeda.
              </p>
            </div>
          </div>
        </div>

        {/* Menu Categories */}
        <div className="chart-container">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Tag className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">Categorias do Cardápio</h3>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => openCategoryModal()}
              data-testid="add-category-btn"
            >
              <Plus className="w-4 h-4 mr-1" />
              Nova Categoria
            </Button>
          </div>
          
          {categories.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              Nenhuma categoria cadastrada. Clique em "Nova Categoria" para começar.
            </p>
          ) : (
            <div className="space-y-2">
              {categories
                .sort((a, b) => a.display_order - b.display_order)
                .map((category, index) => (
                <div 
                  key={category.category_id} 
                  className={`flex items-center justify-between p-3 rounded-lg border ${
                    category.is_active ? 'bg-background' : 'bg-muted/50 opacity-60'
                  }`}
                  data-testid={`category-item-${category.category_id}`}
                >
                  <div className="flex items-center gap-3">
                    <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />
                    <span className={`px-2 py-0.5 rounded bg-muted text-xs font-medium`}>
                      {index + 1}
                    </span>
                    <span className={`font-medium ${!category.is_active ? 'line-through text-muted-foreground' : ''}`}>
                      {category.name}
                    </span>
                    {!category.is_active && (
                      <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded">
                        Inativa
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleToggleActive(category)}
                      title={category.is_active ? 'Desativar' : 'Ativar'}
                      data-testid={`toggle-category-${category.category_id}`}
                    >
                      {category.is_active ? (
                        <X className="w-4 h-4 text-yellow-600" />
                      ) : (
                        <Check className="w-4 h-4 text-green-600" />
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openCategoryModal(category)}
                      data-testid={`edit-category-${category.category_id}`}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteCategory(category)}
                      className="text-red-600 hover:bg-red-50"
                      data-testid={`delete-category-${category.category_id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
          <p className="text-xs text-muted-foreground mt-3">
            Categorias são usadas para organizar os itens no Cardápio. Categorias inativas não aparecem ao adicionar novos itens.
          </p>
        </div>

        {/* Operational Costs Link */}
        <div 
          className="chart-container cursor-pointer hover:border-primary/30 transition-colors"
          onClick={() => navigate('/operational-costs')}
          data-testid="operational-costs-link"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Calculator className="w-5 h-5 text-primary" />
              <div>
                <h3 className="font-semibold">Custos Operacionais</h3>
                <p className="text-sm text-muted-foreground">
                  Configure aluguel, salários, contas e outros custos fixos mensais
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </div>
        </div>
      </div>

      {/* Category Modal */}
      <Dialog open={categoryModalOpen} onOpenChange={setCategoryModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingCategory ? 'Editar Categoria' : 'Nova Categoria'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div>
              <Label htmlFor="categoryName">Nome da Categoria *</Label>
              <Input
                id="categoryName"
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                placeholder="Ex: Pratos Principais"
                data-testid="category-name-input"
              />
            </div>
            <div className="flex justify-end gap-3 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setCategoryModalOpen(false)}
              >
                Cancelar
              </Button>
              <Button 
                onClick={handleSaveCategory} 
                disabled={savingCategory}
                data-testid="save-category-btn"
              >
                {savingCategory ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : null}
                {editingCategory ? 'Salvar' : 'Criar'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default SettingsPage;
