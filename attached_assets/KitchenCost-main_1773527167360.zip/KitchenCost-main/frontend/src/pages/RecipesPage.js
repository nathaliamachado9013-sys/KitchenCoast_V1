import React, { useState, useEffect, useCallback } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { 
  getRecipes, 
  createRecipe, 
  updateRecipe, 
  deleteRecipe,
  getIngredients,
  getMarginRecommendations,
  formatCurrency,
  formatNumber,
  getCurrencySymbol,
  exportRecipesExcel,
  exportRecipePdf,
  duplicateRecipe
} from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import { useToast } from '../hooks/use-toast';
import { 
  Plus, 
  Search, 
  Loader2, 
  Pencil, 
  Trash2, 
  BookOpen,
  DollarSign,
  TrendingUp,
  Clock,
  X,
  AlertTriangle,
  Package,
  Calculator,
  Target,
  Info,
  Download,
  FileText,
  Copy
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '../components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu';

const CATEGORIES = ['Entrada', 'Prato Principal', 'Acompanhamento', 'Sobremesa', 'Bebida', 'Pizza', 'Massa', 'Outros'];

const VARIABLE_COST_SUGGESTIONS = [
  'Embalagem',
  'Taxa de entrega',
  'Taxa de cartão',
  'Taxa marketplace',
  'Desperdício (%)',
  'Descartáveis'
];

const RecipesPage = () => {
  const { currency } = useAuth();
  const [recipes, setRecipes] = useState([]);
  const [ingredients, setIngredients] = useState([]);
  const [marginRecommendations, setMarginRecommendations] = useState({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: '',
    yield_quantity: '1',
    yield_unit: 'porção',
    selling_price: '',
    desired_profit_margin: '',
    preparation_time: '',
    instructions: '',
    ingredients: [],
    variable_costs: []
  });

  // Real-time pricing calculations
  const calculatePricing = useCallback(() => {
    // Calculate ingredients cost
    let ingredientsCost = 0;
    formData.ingredients.forEach(ing => {
      if (ing.ingredient_id && ing.quantity) {
        const ingredient = ingredients.find(i => i.ingredient_id === ing.ingredient_id);
        if (ingredient) {
          ingredientsCost += parseFloat(ing.quantity) * ingredient.cost_per_unit;
        }
      }
    });

    // Calculate variable costs total
    let variableCostsTotal = 0;
    formData.variable_costs.forEach(vc => {
      if (vc.value) {
        variableCostsTotal += parseFloat(vc.value) || 0;
      }
    });

    // Total dish cost (ingredients + variable costs)
    const yieldQty = parseFloat(formData.yield_quantity) || 1;
    const totalDishCost = (ingredientsCost / yieldQty) + variableCostsTotal;

    // Desired margin and suggested price
    const desiredMarginPercent = parseFloat(formData.desired_profit_margin) || 0;
    const desiredMarginDecimal = desiredMarginPercent / 100;
    
    // suggested_price = total_dish_cost / (1 - desired_margin)
    let suggestedPrice = 0;
    if (desiredMarginDecimal > 0 && desiredMarginDecimal < 1) {
      suggestedPrice = totalDishCost / (1 - desiredMarginDecimal);
    }

    // Actual sale price and actual margin
    const actualSalePrice = parseFloat(formData.selling_price) || 0;
    
    // actual_margin = (actual_sale_price - total_dish_cost) / actual_sale_price
    let actualMargin = 0;
    if (actualSalePrice > 0) {
      actualMargin = ((actualSalePrice - totalDishCost) / actualSalePrice) * 100;
    }

    // Estimated profit per dish
    const estimatedProfit = actualSalePrice - totalDishCost;

    // Get recommended margin for category
    const category = formData.category || 'Outros';
    const recommendation = marginRecommendations[category] || marginRecommendations['Outros'] || { min: 0.5, max: 0.7, label: '50% - 70%' };
    const minRecommended = recommendation.min * 100;
    const maxRecommended = recommendation.max * 100;

    // Determine pricing status
    let pricingStatus = 'within';
    let statusText = 'Dentro da margem recomendada';
    let statusColor = 'bg-green-100 text-green-700 border-green-200';
    
    if (actualSalePrice > 0) {
      if (actualMargin < minRecommended) {
        pricingStatus = 'below';
        statusText = 'Abaixo da margem recomendada';
        statusColor = 'bg-red-100 text-red-700 border-red-200';
      } else if (actualMargin > maxRecommended) {
        pricingStatus = 'above';
        statusText = 'Acima da margem recomendada';
        statusColor = 'bg-green-100 text-green-700 border-green-200';
      } else if (actualMargin >= minRecommended - 5 && actualMargin < minRecommended) {
        pricingStatus = 'warning';
        statusText = 'Próximo do limite mínimo';
        statusColor = 'bg-yellow-100 text-yellow-700 border-yellow-200';
      }
    } else {
      statusText = 'Defina o preço de venda';
      statusColor = 'bg-gray-100 text-gray-600 border-gray-200';
    }

    return {
      ingredientsCost: ingredientsCost / yieldQty,
      variableCostsTotal,
      totalDishCost,
      suggestedPrice,
      actualMargin,
      estimatedProfit,
      pricingStatus,
      statusText,
      statusColor,
      recommendedRange: recommendation.label,
      minRecommended,
      maxRecommended
    };
  }, [formData, ingredients, marginRecommendations]);

  const pricing = calculatePricing();

  const loadData = useCallback(async () => {
    try {
      const [recipesRes, ingredientsRes, marginsRes] = await Promise.all([
        getRecipes({ search, category: categoryFilter || undefined }),
        getIngredients(),
        getMarginRecommendations()
      ]);
      setRecipes(recipesRes.data);
      setIngredients(ingredientsRes.data);
      setMarginRecommendations(marginsRes.data);
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao carregar fichas técnicas',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  }, [search, categoryFilter, toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const openModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        name: item.name,
        description: item.description || '',
        category: item.category || '',
        yield_quantity: item.yield_quantity?.toString() || '1',
        yield_unit: item.yield_unit || 'porção',
        selling_price: item.selling_price?.toString() || '',
        desired_profit_margin: item.desired_profit_margin ? (item.desired_profit_margin * 100).toString() : '',
        preparation_time: item.preparation_time?.toString() || '',
        instructions: item.instructions || '',
        ingredients: item.ingredients?.map(i => ({
          ingredient_id: i.ingredient_id,
          quantity: i.quantity.toString()
        })) || [],
        variable_costs: item.variable_costs?.map(vc => ({
          name: vc.name,
          value: vc.value.toString()
        })) || []
      });
    } else {
      setEditingItem(null);
      setFormData({
        name: '',
        description: '',
        category: '',
        yield_quantity: '1',
        yield_unit: 'porção',
        selling_price: '',
        desired_profit_margin: '',
        preparation_time: '',
        instructions: '',
        ingredients: [],
        variable_costs: []
      });
    }
    setModalOpen(true);
  };

  const addIngredient = () => {
    setFormData({
      ...formData,
      ingredients: [...formData.ingredients, { ingredient_id: '', quantity: '' }]
    });
  };

  const updateIngredientRow = (index, field, value) => {
    const updated = [...formData.ingredients];
    updated[index][field] = value;
    setFormData({ ...formData, ingredients: updated });
  };

  const removeIngredient = (index) => {
    const updated = formData.ingredients.filter((_, i) => i !== index);
    setFormData({ ...formData, ingredients: updated });
  };

  const addVariableCost = () => {
    setFormData({
      ...formData,
      variable_costs: [...formData.variable_costs, { name: '', value: '' }]
    });
  };

  const updateVariableCostRow = (index, field, value) => {
    const updated = [...formData.variable_costs];
    updated[index][field] = value;
    setFormData({ ...formData, variable_costs: updated });
  };

  const removeVariableCost = (index) => {
    const updated = formData.variable_costs.filter((_, i) => i !== index);
    setFormData({ ...formData, variable_costs: updated });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name) {
      toast({
        title: 'Erro',
        description: 'Nome é obrigatório',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      const data = {
        name: formData.name,
        description: formData.description || null,
        category: formData.category || null,
        yield_quantity: parseFloat(formData.yield_quantity) || 1,
        yield_unit: formData.yield_unit,
        selling_price: parseFloat(formData.selling_price) || 0,
        desired_profit_margin: formData.desired_profit_margin ? parseFloat(formData.desired_profit_margin) / 100 : 0,
        preparation_time: parseInt(formData.preparation_time) || null,
        instructions: formData.instructions || null,
        ingredients: formData.ingredients
          .filter(i => i.ingredient_id && i.quantity)
          .map(i => ({
            ingredient_id: i.ingredient_id,
            quantity: parseFloat(i.quantity)
          })),
        variable_costs: formData.variable_costs
          .filter(vc => vc.name && vc.value)
          .map(vc => ({
            name: vc.name,
            value: parseFloat(vc.value)
          }))
      };

      if (editingItem) {
        await updateRecipe(editingItem.recipe_id, data);
        toast({ title: 'Ficha técnica atualizada!' });
      } else {
        await createRecipe(data);
        toast({ title: 'Ficha técnica criada!' });
      }
      
      setModalOpen(false);
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao salvar',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (item) => {
    if (!window.confirm(`Excluir "${item.name}"?`)) return;
    
    try {
      await deleteRecipe(item.recipe_id);
      toast({ title: 'Ficha técnica excluída!' });
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao excluir',
        variant: 'destructive'
      });
    }
  };

  const handleDuplicate = async (item) => {
    try {
      const response = await duplicateRecipe(item.recipe_id);
      toast({ title: `Receita duplicada: ${response.data.name}` });
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao duplicar',
        variant: 'destructive'
      });
    }
  };

  const handleExportExcel = async () => {
    setExporting(true);
    try {
      const response = await exportRecipesExcel();
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'fichas_tecnicas.xlsx');
      document.body.appendChild(link);
      link.click();
      link.remove();
      toast({ title: 'Exportação concluída!' });
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao exportar',
        variant: 'destructive'
      });
    } finally {
      setExporting(false);
    }
  };

  const handleExportPdf = async (recipeId) => {
    try {
      const response = await exportRecipePdf(recipeId);
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `ficha_tecnica.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      toast({ title: 'PDF gerado!' });
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao gerar PDF',
        variant: 'destructive'
      });
    }
  };

  const getMarginStatusColor = (status) => {
    switch (status) {
      case 'below': return 'text-red-600 bg-red-50';
      case 'above': return 'text-green-600 bg-green-50';
      default: return 'text-blue-600 bg-blue-50';
    }
  };

  const getMarginStatusText = (status) => {
    switch (status) {
      case 'below': return 'Abaixo';
      case 'above': return 'Acima';
      default: return 'Ideal';
    }
  };

  return (
    <Layout 
      title="Fichas Técnicas"
      actions={
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={handleExportExcel}
            disabled={exporting}
            data-testid="export-recipes-btn"
          >
            {exporting ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Download className="w-4 h-4 mr-2" />
            )}
            Exportar
          </Button>
          <Button onClick={() => openModal()} data-testid="add-recipe-btn">
            <Plus className="w-4 h-4 mr-2" />
            Nova Ficha
          </Button>
        </div>
      }
    >
      {/* Filters */}
      <div className="flex gap-4 mb-6">
        <div className="flex-1 search-input">
          <Search className="w-4 h-4" />
          <Input
            placeholder="Buscar fichas técnicas..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
            data-testid="search-input"
          />
        </div>
        <Select value={categoryFilter || "all"} onValueChange={(v) => setCategoryFilter(v === "all" ? "" : v)}>
          <SelectTrigger className="w-48" data-testid="category-filter">
            <SelectValue placeholder="Todas categorias" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas categorias</SelectItem>
            {CATEGORIES.map(cat => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : recipes.length === 0 ? (
        <div className="empty-state">
          <BookOpen className="empty-state-icon" />
          <h3 className="font-semibold text-lg mb-1">Nenhuma ficha técnica</h3>
          <p className="text-muted-foreground mb-4">Crie suas fichas técnicas com cálculo automático de custo</p>
          <Button onClick={() => openModal()}>
            <Plus className="w-4 h-4 mr-2" />
            Nova Ficha
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" data-testid="recipes-grid">
          {recipes.map(item => (
            <div 
              key={item.recipe_id} 
              className="recipe-card"
              data-testid={`recipe-card-${item.recipe_id}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-lg">{item.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    {item.category && (
                      <span className="text-xs bg-muted px-2 py-0.5 rounded-full">
                        {item.category}
                      </span>
                    )}
                    {item.margin_status && (
                      <span className={`text-xs px-2 py-0.5 rounded-full ${getMarginStatusColor(item.margin_status)}`}>
                        {getMarginStatusText(item.margin_status)}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-1">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <Download className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleExportPdf(item.recipe_id)}>
                        <FileText className="w-4 h-4 mr-2" />
                        Exportar PDF
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDuplicate(item)}>
                        <Copy className="w-4 h-4 mr-2" />
                        Duplicar
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => openModal(item)}
                    data-testid={`edit-${item.recipe_id}`}
                  >
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={() => handleDelete(item)}
                    data-testid={`delete-${item.recipe_id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Cost Breakdown */}
              <div className="text-xs text-muted-foreground mb-3 space-y-1">
                <div className="flex justify-between">
                  <span>Ingredientes:</span>
                  <span>{formatCurrency(item.ingredients_cost || item.cost_per_portion, currency)}</span>
                </div>
                {item.variable_costs_total > 0 && (
                  <div className="flex justify-between">
                    <span>Custos variáveis:</span>
                    <span>{formatCurrency(item.variable_costs_total, currency)}</span>
                  </div>
                )}
                {item.fixed_cost_per_dish > 0 && (
                  <div className="flex justify-between">
                    <span>Custo fixo:</span>
                    <span>{formatCurrency(item.fixed_cost_per_dish, currency)}</span>
                  </div>
                )}
                <div className="flex justify-between font-semibold text-foreground border-t pt-1">
                  <span>Custo total:</span>
                  <span>{formatCurrency(item.cost_per_portion, currency)}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-muted/50 rounded-lg p-2.5">
                  <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                    <Target className="w-3.5 h-3.5" />
                    <span>Sugerido</span>
                  </div>
                  <div className="font-semibold text-primary">
                    {item.suggested_price > 0 ? formatCurrency(item.suggested_price, currency) : '-'}
                  </div>
                </div>

                <div className="bg-muted/50 rounded-lg p-2.5">
                  <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>Margem</span>
                  </div>
                  <div className={`font-semibold ${item.margin_status === 'below' ? 'text-red-600' : item.margin_status === 'above' ? 'text-green-600' : 'text-blue-600'}`}>
                    {formatNumber(item.margin_percentage, 1)}%
                  </div>
                  {item.recommended_margin && (
                    <div className="text-xs text-muted-foreground">
                      Rec: {item.recommended_margin.label}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between mt-3 pt-3 border-t text-sm">
                <span className="text-muted-foreground">
                  Venda: <span className="font-medium text-foreground">{formatCurrency(item.selling_price, currency)}</span>
                </span>
                <span className="font-medium text-green-600">
                  Lucro: {formatCurrency(item.profit, currency)}
                </span>
              </div>

              {item.margin_status === 'below' && item.recommended_margin && (
                <div className="mt-2 p-2 bg-red-50 border border-red-100 rounded-lg flex items-center gap-2 text-xs text-red-700">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Margem abaixo do recomendado ({item.recommended_margin.label})</span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? 'Editar Ficha Técnica' : 'Nova Ficha Técnica'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="form-grid">
              <div>
                <Label htmlFor="name">Nome da Receita *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Ex: Filé ao Molho Madeira"
                  data-testid="recipe-name"
                />
              </div>
              <div>
                <Label htmlFor="category">Categoria</Label>
                <Select 
                  value={formData.category || "none"} 
                  onValueChange={(v) => setFormData({...formData, category: v === "none" ? "" : v})}
                >
                  <SelectTrigger data-testid="recipe-category">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Selecione</SelectItem>
                    {CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Breve descrição do prato..."
                rows={2}
                data-testid="recipe-description"
              />
            </div>

            <div className="form-grid">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Label htmlFor="yield">Rendimento</Label>
                  <Input
                    id="yield"
                    type="number"
                    value={formData.yield_quantity}
                    onChange={(e) => setFormData({...formData, yield_quantity: e.target.value})}
                    data-testid="recipe-yield"
                  />
                </div>
                <div className="w-32">
                  <Label htmlFor="yield_unit">Unidade</Label>
                  <Input
                    id="yield_unit"
                    value={formData.yield_unit}
                    onChange={(e) => setFormData({...formData, yield_unit: e.target.value})}
                    placeholder="porção"
                    data-testid="recipe-yield-unit"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="time">Tempo de Preparo (min)</Label>
                <Input
                  id="time"
                  type="number"
                  value={formData.preparation_time}
                  onChange={(e) => setFormData({...formData, preparation_time: e.target.value})}
                  data-testid="recipe-time"
                />
              </div>
            </div>

            {/* Ingredients */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <Label className="flex items-center gap-2">
                  <Package className="w-4 h-4" />
                  Ingredientes
                </Label>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm"
                  onClick={addIngredient}
                  data-testid="add-ingredient-row"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Adicionar
                </Button>
              </div>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {formData.ingredients.map((ing, idx) => {
                  const selectedIng = ingredients.find(i => i.ingredient_id === ing.ingredient_id);
                  return (
                    <div key={idx} className="flex items-center gap-2">
                      <Select 
                        value={ing.ingredient_id || "none"} 
                        onValueChange={(v) => updateIngredientRow(idx, 'ingredient_id', v === "none" ? "" : v)}
                      >
                        <SelectTrigger className="flex-1" data-testid={`ingredient-select-${idx}`}>
                          <SelectValue placeholder="Selecione ingrediente" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Selecione</SelectItem>
                          {ingredients.map(i => (
                            <SelectItem key={i.ingredient_id} value={i.ingredient_id}>
                              {i.name} ({i.unit})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Input
                        type="number"
                        step="0.001"
                        value={ing.quantity}
                        onChange={(e) => updateIngredientRow(idx, 'quantity', e.target.value)}
                        placeholder="Qtd"
                        className="w-24"
                        data-testid={`ingredient-qty-${idx}`}
                      />
                      {selectedIng && (
                        <span className="text-sm text-muted-foreground w-12">
                          {selectedIng.unit}
                        </span>
                      )}
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeIngredient(idx)}
                        className="text-red-600"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  );
                })}
                {formData.ingredients.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Nenhum ingrediente adicionado
                  </p>
                )}
              </div>
            </div>

            {/* Variable Costs */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <Label className="flex items-center gap-2">
                  <Calculator className="w-4 h-4" />
                  Custos Variáveis
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger>
                        <Info className="w-4 h-4 text-muted-foreground" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Embalagem, taxa de entrega, cartão, marketplace, etc.</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </Label>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm"
                  onClick={addVariableCost}
                  data-testid="add-variable-cost"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Adicionar
                </Button>
              </div>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {formData.variable_costs.map((vc, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <Select 
                      value={vc.name || "custom"} 
                      onValueChange={(v) => updateVariableCostRow(idx, 'name', v === "custom" ? "" : v)}
                    >
                      <SelectTrigger className="flex-1" data-testid={`variable-cost-name-${idx}`}>
                        <SelectValue placeholder="Tipo de custo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="custom">Personalizado</SelectItem>
                        {VARIABLE_COST_SUGGESTIONS.map(name => (
                          <SelectItem key={name} value={name}>{name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {!VARIABLE_COST_SUGGESTIONS.includes(vc.name) && (
                      <Input
                        value={vc.name}
                        onChange={(e) => updateVariableCostRow(idx, 'name', e.target.value)}
                        placeholder="Nome"
                        className="w-32"
                      />
                    )}
                    <div className="relative w-28">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                        {getCurrencySymbol(currency)}
                      </span>
                      <Input
                        type="number"
                        step="0.01"
                        value={vc.value}
                        onChange={(e) => updateVariableCostRow(idx, 'value', e.target.value)}
                        placeholder="0.00"
                        className="pl-10"
                        data-testid={`variable-cost-value-${idx}`}
                      />
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeVariableCost(idx)}
                      className="text-red-600"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
                {formData.variable_costs.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Nenhum custo variável adicionado
                  </p>
                )}
              </div>
            </div>

            {/* Pricing */}
            <div className="border rounded-lg p-4 bg-muted/30">
              <Label className="flex items-center gap-2 mb-4">
                <DollarSign className="w-4 h-4" />
                Precificação
              </Label>
              
              {/* Cost Summary - Read Only */}
              <div className="bg-background rounded-lg p-3 mb-4 border">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Custo ingredientes:</span>
                    <span className="font-medium">{formatCurrency(pricing.ingredientsCost, currency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Custos variáveis:</span>
                    <span className="font-medium">{formatCurrency(pricing.variableCostsTotal, currency)}</span>
                  </div>
                </div>
                <div className="flex justify-between mt-2 pt-2 border-t text-sm font-semibold">
                  <span>Custo total do prato:</span>
                  <span className="text-primary" data-testid="total-dish-cost">
                    {formatCurrency(pricing.totalDishCost, currency)}
                  </span>
                </div>
              </div>

              {/* Category Recommendation */}
              {formData.category && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                  <div className="flex items-center gap-2 text-sm text-blue-700">
                    <Info className="w-4 h-4" />
                    <span>
                      <strong>Faixa recomendada para {formData.category}:</strong> {pricing.recommendedRange}
                    </span>
                  </div>
                </div>
              )}

              {/* Editable Inputs */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label htmlFor="margin" className="text-sm">Margem Desejada (%)</Label>
                  <Input
                    id="margin"
                    type="number"
                    step="1"
                    min="0"
                    max="99"
                    value={formData.desired_profit_margin}
                    onChange={(e) => setFormData({...formData, desired_profit_margin: e.target.value})}
                    placeholder="Ex: 70"
                    data-testid="recipe-margin"
                  />
                </div>
                <div>
                  <Label htmlFor="suggested-price" className="text-sm flex items-center gap-1">
                    <Target className="w-3.5 h-3.5" />
                    Preço Sugerido
                  </Label>
                  <div className="h-10 px-3 rounded-md border bg-muted flex items-center font-semibold text-primary" data-testid="suggested-price">
                    {pricing.suggestedPrice > 0 ? formatCurrency(pricing.suggestedPrice, currency) : '-'}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Calculado: Custo ÷ (1 - Margem)
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label htmlFor="price" className="text-sm">Preço de Venda Praticado ({getCurrencySymbol(currency)})</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    value={formData.selling_price}
                    onChange={(e) => setFormData({...formData, selling_price: e.target.value})}
                    placeholder="0.00"
                    data-testid="recipe-price"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Preço que você cobra do cliente
                  </p>
                </div>
                <div>
                  <Label className="text-sm flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5" />
                    Margem Real
                  </Label>
                  <div 
                    className={`h-10 px-3 rounded-md border flex items-center font-semibold ${
                      pricing.pricingStatus === 'below' ? 'bg-red-50 text-red-700 border-red-200' :
                      pricing.pricingStatus === 'warning' ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                      pricing.pricingStatus === 'above' || pricing.pricingStatus === 'within' ? 'bg-green-50 text-green-700 border-green-200' :
                      'bg-muted text-muted-foreground'
                    }`}
                    data-testid="actual-margin"
                  >
                    {formData.selling_price ? `${formatNumber(pricing.actualMargin, 1)}%` : '-'}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    (Venda - Custo) ÷ Venda
                  </p>
                </div>
              </div>

              {/* Profit and Status */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm flex items-center gap-1">
                    <Calculator className="w-3.5 h-3.5" />
                    Lucro por Prato
                  </Label>
                  <div 
                    className={`h-10 px-3 rounded-md border flex items-center font-semibold ${
                      pricing.estimatedProfit > 0 ? 'bg-green-50 text-green-700 border-green-200' :
                      pricing.estimatedProfit < 0 ? 'bg-red-50 text-red-700 border-red-200' :
                      'bg-muted text-muted-foreground'
                    }`}
                    data-testid="estimated-profit"
                  >
                    {formData.selling_price ? formatCurrency(pricing.estimatedProfit, currency) : '-'}
                  </div>
                </div>
                <div>
                  <Label className="text-sm">Status</Label>
                  <div 
                    className={`h-10 px-3 rounded-md border flex items-center text-sm font-medium ${pricing.statusColor}`}
                    data-testid="pricing-status"
                  >
                    {pricing.pricingStatus === 'below' && <AlertTriangle className="w-4 h-4 mr-2" />}
                    {pricing.statusText}
                  </div>
                </div>
              </div>

              {/* Warning/Info message */}
              {pricing.pricingStatus === 'below' && formData.selling_price && (
                <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-start gap-2 text-sm text-red-700">
                    <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <div>
                      <strong>Atenção:</strong> A margem real ({formatNumber(pricing.actualMargin, 1)}%) está abaixo da faixa recomendada ({pricing.recommendedRange}).
                      {pricing.suggestedPrice > 0 && (
                        <span> Considere aumentar o preço para pelo menos <strong>{formatCurrency(pricing.suggestedPrice, currency)}</strong>.</span>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="instructions">Modo de Preparo</Label>
              <Textarea
                id="instructions"
                value={formData.instructions}
                onChange={(e) => setFormData({...formData, instructions: e.target.value})}
                placeholder="Passo a passo do preparo..."
                rows={4}
                data-testid="recipe-instructions"
              />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={saving} data-testid="save-recipe-btn">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                {editingItem ? 'Salvar' : 'Criar'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default RecipesPage;
