import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { 
  getProductions,
  registerProduction,
  deleteProduction,
  getRecipes,
  getProductionSummary,
  formatCurrency,
  formatNumber,
  formatDateTime
} from '../lib/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import { useToast } from '../hooks/use-toast';
import { 
  Plus, 
  Loader2, 
  Trash2, 
  ChefHat,
  DollarSign,
  Calendar,
  Hash
} from 'lucide-react';

const ProductionPage = () => {
  const { currency } = useAuth();
  const [productions, setProductions] = useState([]);
  const [recipes, setRecipes] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    recipe_id: '',
    quantity: '1',
    notes: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [productionsRes, recipesRes, summaryRes] = await Promise.all([
        getProductions(),
        getRecipes(),
        getProductionSummary('today')
      ]);
      setProductions(productionsRes.data);
      setRecipes(recipesRes.data);
      setSummary(summaryRes.data);
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao carregar produções',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const openModal = () => {
    setFormData({
      recipe_id: '',
      quantity: '1',
      notes: ''
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.recipe_id || !formData.quantity) {
      toast({
        title: 'Erro',
        description: 'Receita e quantidade são obrigatórios',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      const data = {
        recipe_id: formData.recipe_id,
        quantity: parseFloat(formData.quantity),
        notes: formData.notes || null
      };

      const response = await registerProduction(data);
      toast({ 
        title: 'Produção registrada!',
        description: `${response.data.recipe_name} - Custo: ${formatCurrency(response.data.total_cost, currency)}`
      });
      
      setModalOpen(false);
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao registrar produção',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (item) => {
    if (!window.confirm(`Excluir produção de "${item.recipe_name}"? O estoque NÃO será restaurado.`)) return;
    
    try {
      await deleteProduction(item.production_id);
      toast({ title: 'Produção excluída!' });
      loadData();
    } catch (error) {
      toast({
        title: 'Erro',
        description: error.response?.data?.detail || 'Erro ao excluir',
        variant: 'destructive'
      });
    }
  };

  // Get selected recipe info
  const selectedRecipe = recipes.find(r => r.recipe_id === formData.recipe_id);
  const estimatedCost = selectedRecipe 
    ? (selectedRecipe.cost_per_portion * selectedRecipe.yield_quantity * parseFloat(formData.quantity || 0))
    : 0;

  return (
    <Layout 
      title="Produção"
      actions={
        <Button onClick={openModal} data-testid="add-production-btn">
          <Plus className="w-4 h-4 mr-2" />
          Registrar Produção
        </Button>
      }
    >
      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="metric-value">{formatCurrency(summary?.total_cost || 0, currency)}</div>
              <div className="metric-label">Custo Produção Hoje</div>
            </div>
            <div className="p-2.5 rounded-lg bg-amber-50">
              <DollarSign className="w-5 h-5 text-amber-600" />
            </div>
          </div>
        </div>
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="metric-value">{summary?.total_productions || 0}</div>
              <div className="metric-label">Produções Hoje</div>
            </div>
            <div className="p-2.5 rounded-lg bg-blue-50">
              <ChefHat className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </div>
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="metric-value">{formatNumber(summary?.total_quantity || 0, 0)}</div>
              <div className="metric-label">Lotes Produzidos</div>
            </div>
            <div className="p-2.5 rounded-lg bg-green-50">
              <Hash className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Productions Table */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : productions.length === 0 ? (
        <div className="empty-state">
          <ChefHat className="empty-state-icon" />
          <h3 className="font-semibold text-lg mb-1">Nenhuma produção registrada</h3>
          <p className="text-muted-foreground mb-4">Registre a produção diária para controlar custos e estoque</p>
          <Button onClick={openModal}>
            <Plus className="w-4 h-4 mr-2" />
            Registrar Produção
          </Button>
        </div>
      ) : (
        <div className="table-container" data-testid="productions-table">
          <table className="data-table">
            <thead>
              <tr>
                <th>Data/Hora</th>
                <th>Receita</th>
                <th>Quantidade</th>
                <th>Custo Total</th>
                <th className="text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {productions.map(item => (
                <tr key={item.production_id} data-testid={`row-${item.production_id}`}>
                  <td>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      {formatDateTime(item.created_at)}
                    </div>
                  </td>
                  <td className="font-medium">{item.recipe_name}</td>
                  <td>{formatNumber(item.quantity, 0)} lote(s)</td>
                  <td className="font-semibold text-amber-600">{formatCurrency(item.total_cost, currency)}</td>
                  <td>
                    <div className="flex justify-end">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        onClick={() => handleDelete(item)}
                        data-testid={`delete-${item.production_id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Registrar Produção</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="recipe">Receita *</Label>
              <Select 
                value={formData.recipe_id || "none"} 
                onValueChange={(v) => setFormData({...formData, recipe_id: v === "none" ? "" : v})}
              >
                <SelectTrigger data-testid="production-recipe">
                  <SelectValue placeholder="Selecione a receita" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Selecione</SelectItem>
                  {recipes.map(recipe => (
                    <SelectItem key={recipe.recipe_id} value={recipe.recipe_id}>
                      {recipe.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedRecipe && (
              <div className="bg-muted/50 rounded-lg p-3 text-sm space-y-1">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Rendimento por lote:</span>
                  <span className="font-medium">{selectedRecipe.yield_quantity} {selectedRecipe.yield_unit}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Custo por porção:</span>
                  <span className="font-medium">{formatCurrency(selectedRecipe.cost_per_portion, currency)}</span>
                </div>
              </div>
            )}

            <div>
              <Label htmlFor="quantity">Quantidade de Lotes *</Label>
              <Input
                id="quantity"
                type="number"
                step="1"
                min="1"
                value={formData.quantity}
                onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                placeholder="1"
                data-testid="production-quantity"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Quantas vezes a receita foi produzida
              </p>
            </div>

            {/* Cost Preview */}
            {selectedRecipe && formData.quantity && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-amber-600" />
                    <span className="font-medium text-amber-700">Custo estimado:</span>
                  </div>
                  <span className="text-lg font-bold text-amber-700">
                    {formatCurrency(estimatedCost, currency)}
                  </span>
                </div>
              </div>
            )}

            <div>
              <Label htmlFor="notes">Observações</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                placeholder="Observações opcionais..."
                rows={2}
                data-testid="production-notes"
              />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={saving} data-testid="save-production-btn">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Registrar
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default ProductionPage;
