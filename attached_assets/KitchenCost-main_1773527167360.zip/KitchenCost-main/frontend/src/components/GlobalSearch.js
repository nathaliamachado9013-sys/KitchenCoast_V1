import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { globalSearch } from '../lib/api';
import { Input } from './ui/input';
import { 
  Search, 
  ShoppingBasket, 
  BookOpen, 
  Truck,
  X,
  Loader2
} from 'lucide-react';

const GlobalSearch = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const inputRef = useRef(null);
  const containerRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const searchTimeout = setTimeout(async () => {
      if (query.length >= 2) {
        setLoading(true);
        try {
          const response = await globalSearch(query);
          setResults(response.data);
          setIsOpen(true);
        } catch (error) {
          console.error('Search error:', error);
        } finally {
          setLoading(false);
        }
      } else {
        setResults(null);
        setIsOpen(false);
      }
    }, 300);

    return () => clearTimeout(searchTimeout);
  }, [query]);

  const handleSelect = (item) => {
    setQuery('');
    setResults(null);
    setIsOpen(false);
    
    if (item.type === 'ingredient') {
      navigate('/ingredients', { state: { highlightId: item.ingredient_id } });
    } else if (item.type === 'recipe') {
      navigate('/recipes', { state: { highlightId: item.recipe_id } });
    } else if (item.type === 'supplier') {
      navigate('/suppliers', { state: { highlightId: item.supplier_id } });
    }
  };

  const getIcon = (type) => {
    switch (type) {
      case 'ingredient': return ShoppingBasket;
      case 'recipe': return BookOpen;
      case 'supplier': return Truck;
      default: return Search;
    }
  };

  const hasResults = results && (
    results.ingredients?.length > 0 || 
    results.recipes?.length > 0 || 
    results.suppliers?.length > 0
  );

  return (
    <div ref={containerRef} className="relative w-80">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          ref={inputRef}
          type="text"
          placeholder="Buscar ingredientes, receitas, fornecedores..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => results && setIsOpen(true)}
          className="pl-10 pr-10 bg-muted/50 border-0 focus:bg-white"
          data-testid="global-search-input"
        />
        {query && (
          <button
            onClick={() => {
              setQuery('');
              setResults(null);
              setIsOpen(false);
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="w-4 h-4" />
          </button>
        )}
        {loading && (
          <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-primary" />
        )}
      </div>

      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-lg border shadow-lg z-50 max-h-80 overflow-y-auto">
          {!hasResults ? (
            <div className="p-4 text-center text-muted-foreground text-sm">
              {query.length >= 2 ? 'Nenhum resultado encontrado' : 'Digite pelo menos 2 caracteres'}
            </div>
          ) : (
            <div className="py-2">
              {results.ingredients?.length > 0 && (
                <div>
                  <div className="px-3 py-1 text-xs font-medium text-muted-foreground uppercase">
                    Ingredientes
                  </div>
                  {results.ingredients.map((item) => {
                    const Icon = getIcon(item.type);
                    return (
                      <button
                        key={item.ingredient_id}
                        onClick={() => handleSelect(item)}
                        className="w-full px-3 py-2 flex items-center gap-3 hover:bg-muted text-left"
                        data-testid={`search-result-${item.ingredient_id}`}
                      >
                        <Icon className="w-4 h-4 text-blue-500" />
                        <div>
                          <div className="font-medium">{item.name}</div>
                          {item.category && (
                            <div className="text-xs text-muted-foreground">{item.category}</div>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {results.recipes?.length > 0 && (
                <div>
                  <div className="px-3 py-1 text-xs font-medium text-muted-foreground uppercase border-t mt-1 pt-2">
                    Fichas Técnicas
                  </div>
                  {results.recipes.map((item) => {
                    const Icon = getIcon(item.type);
                    return (
                      <button
                        key={item.recipe_id}
                        onClick={() => handleSelect(item)}
                        className="w-full px-3 py-2 flex items-center gap-3 hover:bg-muted text-left"
                        data-testid={`search-result-${item.recipe_id}`}
                      >
                        <Icon className="w-4 h-4 text-green-500" />
                        <div>
                          <div className="font-medium">{item.name}</div>
                          {item.category && (
                            <div className="text-xs text-muted-foreground">{item.category}</div>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {results.suppliers?.length > 0 && (
                <div>
                  <div className="px-3 py-1 text-xs font-medium text-muted-foreground uppercase border-t mt-1 pt-2">
                    Fornecedores
                  </div>
                  {results.suppliers.map((item) => {
                    const Icon = getIcon(item.type);
                    return (
                      <button
                        key={item.supplier_id}
                        onClick={() => handleSelect(item)}
                        className="w-full px-3 py-2 flex items-center gap-3 hover:bg-muted text-left"
                        data-testid={`search-result-${item.supplier_id}`}
                      >
                        <Icon className="w-4 h-4 text-purple-500" />
                        <div className="font-medium">{item.name}</div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default GlobalSearch;
