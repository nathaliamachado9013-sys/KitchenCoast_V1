import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  LayoutDashboard, 
  ShoppingBasket, 
  Truck, 
  BookOpen, 
  Package, 
  BarChart3, 
  Settings, 
  LogOut,
  ChefHat,
  UtensilsCrossed,
  Wine,
  Factory,
  ShoppingCart
} from 'lucide-react';

const Sidebar = () => {
  const { user, restaurant, logout } = useAuth();

  const navItems = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/menu', label: 'Cardápio', icon: UtensilsCrossed },
    { path: '/recipes', label: 'Fichas Técnicas', icon: BookOpen },
    { path: '/resale-products', label: 'Produtos de Revenda', icon: Wine },
    { path: '/ingredients', label: 'Ingredientes', icon: ShoppingBasket },
    { path: '/suppliers', label: 'Fornecedores', icon: Truck },
    { path: '/stock', label: 'Estoque', icon: Package },
    { path: '/production', label: 'Produção', icon: Factory },
    { path: '/sales', label: 'Vendas', icon: ShoppingCart },
    { path: '/reports', label: 'Relatórios', icon: BarChart3 },
    { path: '/settings', label: 'Configurações', icon: Settings },
  ];

  return (
    <aside className="sidebar" data-testid="sidebar">
      {/* Logo */}
      <div className="p-5 border-b">
        <div className="logo">
          <div className="logo-icon">
            <ChefHat className="w-5 h-5" />
          </div>
          <span>KitchenCost</span>
        </div>
      </div>

      {/* Restaurant info */}
      {restaurant && (
        <div className="px-5 py-3 border-b bg-muted/30">
          <p className="text-sm font-medium truncate">{restaurant.name}</p>
          <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => 
              `sidebar-link ${isActive ? 'active' : ''}`
            }
            data-testid={`nav-${item.path.replace('/', '')}`}
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      {/* User section */}
      <div className="p-3 border-t">
        <button
          onClick={logout}
          className="sidebar-link w-full text-red-600 hover:bg-red-50 hover:text-red-700"
          data-testid="logout-btn"
        >
          <LogOut className="w-5 h-5" />
          <span>Sair</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
