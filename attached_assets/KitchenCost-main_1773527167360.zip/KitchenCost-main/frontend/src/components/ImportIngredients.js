import React, { useState, useRef } from 'react';
import { 
  previewImportIngredients, 
  confirmImportIngredients 
} from '../lib/api';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';
import { useToast } from '../hooks/use-toast';
import { 
  Upload, 
  FileSpreadsheet, 
  Loader2, 
  CheckCircle, 
  XCircle,
  AlertTriangle
} from 'lucide-react';

const ImportIngredients = ({ onSuccess }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [previewData, setPreviewData] = useState(null);
  const fileInputRef = useRef(null);
  const { toast } = useToast();

  const handleFileSelect = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      const response = await previewImportIngredients(file);
      setPreviewData(response.data);
      setModalOpen(true);
    } catch (error) {
      toast({
        title: 'Erro ao ler arquivo',
        description: error.response?.data?.detail || 'Verifique se o arquivo está no formato correto',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
      event.target.value = '';
    }
  };

  const handleConfirmImport = async () => {
    if (!previewData?.data) return;

    const validItems = previewData.data.filter(d => d.status === 'ok');
    if (validItems.length === 0) {
      toast({
        title: 'Nenhum item válido',
        description: 'Todos os itens estão duplicados ou com erro',
        variant: 'destructive'
      });
      return;
    }

    setImporting(true);
    try {
      const response = await confirmImportIngredients(previewData.data);
      toast({
        title: 'Importação concluída!',
        description: `${response.data.imported} ingredientes importados, ${response.data.skipped} ignorados`
      });
      setModalOpen(false);
      setPreviewData(null);
      onSuccess?.();
    } catch (error) {
      toast({
        title: 'Erro na importação',
        description: error.response?.data?.detail || 'Erro ao importar',
        variant: 'destructive'
      });
    } finally {
      setImporting(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'ok':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'duplicate':
        return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      case 'error':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept=".xlsx,.xls"
        className="hidden"
      />
      
      <Button
        variant="outline"
        onClick={() => fileInputRef.current?.click()}
        disabled={loading}
        data-testid="import-ingredients-btn"
      >
        {loading ? (
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
        ) : (
          <Upload className="w-4 h-4 mr-2" />
        )}
        Importar Excel
      </Button>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5" />
              Pré-visualização da Importação
            </DialogTitle>
          </DialogHeader>

          {previewData && (
            <>
              {/* Summary */}
              <div className="grid grid-cols-4 gap-4 py-4 border-b">
                <div className="text-center">
                  <div className="text-2xl font-bold">{previewData.total_rows}</div>
                  <div className="text-sm text-muted-foreground">Total</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{previewData.valid}</div>
                  <div className="text-sm text-muted-foreground">Válidos</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-amber-600">{previewData.duplicates}</div>
                  <div className="text-sm text-muted-foreground">Duplicados</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">{previewData.errors}</div>
                  <div className="text-sm text-muted-foreground">Erros</div>
                </div>
              </div>

              {/* Data preview */}
              <div className="flex-1 overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted sticky top-0">
                    <tr>
                      <th className="text-left p-2">#</th>
                      <th className="text-left p-2">Status</th>
                      <th className="text-left p-2">Nome</th>
                      <th className="text-left p-2">Categoria</th>
                      <th className="text-left p-2">Unidade</th>
                      <th className="text-right p-2">Preço</th>
                      <th className="text-left p-2">Observação</th>
                    </tr>
                  </thead>
                  <tbody>
                    {previewData.data.map((item, idx) => (
                      <tr 
                        key={idx} 
                        className={`border-b ${
                          item.status === 'duplicate' ? 'bg-amber-50' :
                          item.status === 'error' ? 'bg-red-50' : ''
                        }`}
                      >
                        <td className="p-2 text-muted-foreground">{item.row}</td>
                        <td className="p-2">{getStatusIcon(item.status)}</td>
                        <td className="p-2 font-medium">{item.name}</td>
                        <td className="p-2">{item.category || '-'}</td>
                        <td className="p-2">{item.unit}</td>
                        <td className="p-2 text-right">{item.cost_per_unit?.toFixed(2)}</td>
                        <td className="p-2 text-sm text-muted-foreground">{item.error || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <DialogFooter className="border-t pt-4">
                <Button variant="outline" onClick={() => setModalOpen(false)}>
                  Cancelar
                </Button>
                <Button 
                  onClick={handleConfirmImport} 
                  disabled={importing || previewData.valid === 0}
                  data-testid="confirm-import-btn"
                >
                  {importing ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : null}
                  Importar {previewData.valid} Ingredientes
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ImportIngredients;
