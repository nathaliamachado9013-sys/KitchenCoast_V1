import React, { useState, useEffect } from 'react';
import { getIngredientPriceHistory, formatCurrency, formatDate } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Loader2, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

const PriceHistoryModal = ({ ingredientId, ingredientName, isOpen, onClose }) => {
  const { currency } = useAuth();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isOpen && ingredientId) {
      loadHistory();
    }
  }, [isOpen, ingredientId]);

  const loadHistory = async () => {
    setLoading(true);
    try {
      const response = await getIngredientPriceHistory(ingredientId);
      setHistory(response.data);
    } catch (error) {
      console.error('Error loading price history:', error);
    } finally {
      setLoading(false);
    }
  };

  const chartData = history
    .slice(0, 20)
    .reverse()
    .map(h => ({
      date: formatDate(h.created_at),
      price: h.price
    }));

  const getPriceTrend = () => {
    if (history.length < 2) return 'stable';
    const latest = history[0]?.price || 0;
    const previous = history[1]?.price || 0;
    if (latest > previous) return 'up';
    if (latest < previous) return 'down';
    return 'stable';
  };

  const getTrendIcon = () => {
    const trend = getPriceTrend();
    if (trend === 'up') return <TrendingUp className="w-4 h-4 text-red-500" />;
    if (trend === 'down') return <TrendingDown className="w-4 h-4 text-green-500" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Histórico de Preços - {ingredientName}</DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center h-48">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : history.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Nenhum histórico de preços disponível
          </div>
        ) : (
          <div className="space-y-4">
            {/* Current price with trend */}
            <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
              <div>
                <div className="text-sm text-muted-foreground">Preço Atual</div>
                <div className="text-2xl font-bold flex items-center gap-2">
                  {formatCurrency(history[0]?.price || 0, currency)}
                  {getTrendIcon()}
                </div>
              </div>
              {history.length > 1 && (
                <div className="ml-auto text-right">
                  <div className="text-sm text-muted-foreground">Preço Anterior</div>
                  <div className="text-lg">{formatCurrency(history[1]?.price || 0, currency)}</div>
                </div>
              )}
            </div>

            {/* Chart */}
            {chartData.length > 1 && (
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis 
                      dataKey="date" 
                      tick={{ fontSize: 10 }}
                      tickLine={false}
                    />
                    <YAxis 
                      tick={{ fontSize: 10 }}
                      tickLine={false}
                      tickFormatter={(value) => value.toFixed(2)}
                    />
                    <Tooltip 
                      formatter={(value) => [formatCurrency(value, currency), 'Preço']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="price" 
                      stroke="hsl(152, 60%, 40%)" 
                      strokeWidth={2}
                      dot={{ fill: "hsl(152, 60%, 40%)" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* History table */}
            <div className="max-h-48 overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted sticky top-0">
                  <tr>
                    <th className="text-left p-2">Data</th>
                    <th className="text-right p-2">Preço</th>
                    <th className="text-right p-2">Variação</th>
                  </tr>
                </thead>
                <tbody>
                  {history.slice(0, 20).map((item, idx) => {
                    const prevPrice = history[idx + 1]?.price;
                    const variation = prevPrice ? ((item.price - prevPrice) / prevPrice * 100) : 0;
                    return (
                      <tr key={item.history_id} className="border-b">
                        <td className="p-2">{formatDate(item.created_at)}</td>
                        <td className="p-2 text-right font-mono">
                          {formatCurrency(item.price, currency)}
                        </td>
                        <td className={`p-2 text-right font-mono ${
                          variation > 0 ? 'text-red-600' : 
                          variation < 0 ? 'text-green-600' : ''
                        }`}>
                          {idx < history.length - 1 ? (
                            variation > 0 ? `+${variation.toFixed(1)}%` : `${variation.toFixed(1)}%`
                          ) : '-'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default PriceHistoryModal;
