import React from 'react';
import Sidebar from './Sidebar';
import GlobalSearch from './GlobalSearch';

const Layout = ({ children, title, actions }) => {
  return (
    <div className="app-layout">
      <Sidebar />
      <main className="main-content">
        <header className="page-header">
          <div className="flex items-center gap-6">
            <h1 className="page-title" data-testid="page-title">{title}</h1>
            <GlobalSearch />
          </div>
          {actions && <div className="flex items-center gap-3">{actions}</div>}
        </header>
        <div className="page-content">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
