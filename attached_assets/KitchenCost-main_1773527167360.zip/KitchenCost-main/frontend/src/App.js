import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Toaster } from './components/ui/toaster';
import { Loader2 } from 'lucide-react';
import './App.css';

// Pages
import LoginPage from './pages/LoginPage';
import OnboardingPage from './pages/OnboardingPage';
import Dashboard from './pages/Dashboard';
import IngredientsPage from './pages/IngredientsPage';
import SuppliersPage from './pages/SuppliersPage';
import RecipesPage from './pages/RecipesPage';
import StockPage from './pages/StockPage';
import ReportsPage from './pages/ReportsPage';
import SettingsPage from './pages/SettingsPage';
import OperationalCostsPage from './pages/OperationalCostsPage';
import MenuPage from './pages/MenuPage';
import ResaleProductsPage from './pages/ResaleProductsPage';
import ProductionPage from './pages/ProductionPage';
import SalesPage from './pages/SalesPage';
import AuthCallback from './components/AuthCallback';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, restaurant, loading } = useAuth();
  const location = useLocation();

  // Show loading while checking auth
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  // If not authenticated, redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  // If authenticated but no restaurant and not on onboarding, redirect to onboarding
  if (!restaurant && location.pathname !== '/onboarding') {
    return <Navigate to="/onboarding" replace />;
  }

  // If has restaurant and trying to access onboarding, redirect to dashboard
  if (restaurant && location.pathname === '/onboarding') {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

// App Router with session_id detection
const AppRouter = () => {
  const location = useLocation();
  const { isAuthenticated, loading } = useAuth();

  // CRITICAL: Check URL fragment for session_id during render (not in useEffect)
  // This synchronous check prevents race conditions by processing new session_id FIRST
  if (location.hash?.includes('session_id=')) {
    return <AuthCallback />;
  }

  return (
    <Routes>
      {/* Public routes */}
      <Route 
        path="/" 
        element={
          loading ? (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : isAuthenticated ? (
            <Navigate to="/dashboard" replace />
          ) : (
            <LoginPage />
          )
        } 
      />
      
      {/* Protected routes */}
      <Route 
        path="/onboarding" 
        element={
          <ProtectedRoute>
            <OnboardingPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/dashboard" 
        element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/ingredients" 
        element={
          <ProtectedRoute>
            <IngredientsPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/suppliers" 
        element={
          <ProtectedRoute>
            <SuppliersPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/recipes" 
        element={
          <ProtectedRoute>
            <RecipesPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/stock" 
        element={
          <ProtectedRoute>
            <StockPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/reports" 
        element={
          <ProtectedRoute>
            <ReportsPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/settings" 
        element={
          <ProtectedRoute>
            <SettingsPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/operational-costs" 
        element={
          <ProtectedRoute>
            <OperationalCostsPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/menu" 
        element={
          <ProtectedRoute>
            <MenuPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/resale-products" 
        element={
          <ProtectedRoute>
            <ResaleProductsPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/production" 
        element={
          <ProtectedRoute>
            <ProductionPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/sales" 
        element={
          <ProtectedRoute>
            <SalesPage />
          </ProtectedRoute>
        } 
      />

      {/* Catch all - redirect to home */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRouter />
        <Toaster />
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
