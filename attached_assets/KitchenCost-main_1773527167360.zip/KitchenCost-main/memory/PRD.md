# KitchenCost - Product Requirements Document

## Visão Geral
KitchenCost é um SaaS multi-tenant para gestão de custos de cozinhas e restaurantes, permitindo controle completo de ingredientes, fichas técnicas, estoque, custos operacionais e relatórios financeiros.

## Personas de Usuário
1. **Dono de Restaurante**: Quer entender custos e margens para maximizar lucros
2. **Chef/Cozinheiro**: Precisa criar fichas técnicas e controlar ingredientes
3. **Gestor de Cozinha**: Monitora estoque, faz pedidos e analisa relatórios

## Requisitos Core (Estáticos)

### MVP - Fase 1 (Implementado ✅)
- [x] Autenticação com Google OAuth (Emergent Auth)
- [x] Estrutura Multi-tenant (cada restaurante isolado)
- [x] Cadastro de fornecedores (CRUD completo)
- [x] Cadastro de ingredientes com preços, categorias e fornecedor vinculado
- [x] Fichas técnicas de receitas com cálculo automático de custo
- [x] Cálculo automático de margem e lucro por porção
- [x] Busca de fichas técnicas por nome
- [x] Gestão de estoque (entradas e saídas)
- [x] Alertas de estoque baixo
- [x] Valor financeiro do inventário
- [x] Dashboard com KPIs principais
- [x] Relatórios de custos por período (hoje, semana, mês, ano)
- [x] Relatórios de margens por faixa

### Fase 1.5 - Extensões (Implementado ✅) - 13/03/2026
- [x] **Multi-currency support**: EUR (default), USD, BRL, GBP
- [x] **Custos Operacionais**: Módulo completo com aluguel, energia, água, internet, salários, contabilidade, impostos, outros
- [x] **Custo fixo por prato**: Cálculo automático (custo mensal total / pratos vendidos)
- [x] **Custos variáveis por receita**: Embalagem, taxa de entrega, cartão, marketplace, desperdício
- [x] **Sistema de precificação**: Margem desejada → preço sugerido automático
- [x] **Recomendações de margem por categoria**:
  - Bebidas: 80-90%
  - Pizza: 65-75%
  - Massa: 60-70%
  - Sobremesa: 70-80%
  - Entrada: 65-75%
  - Prato Principal: 60-70%
  - Acompanhamento: 55-65%
- [x] **Alertas visuais**: Quando margem está abaixo do recomendado
- [x] **UX de Precificação em Tempo Real** (13/03/2026):
  - Cálculos em tempo real no formulário de criação/edição de receita
  - Campos exibidos: custo total, preço sugerido, margem real, lucro por prato, status
  - Faixa recomendada da categoria exibida no formulário
  - Feedback visual com cores (verde/amarelo/vermelho) baseado na margem
  - Alerta detalhado quando margem está abaixo do recomendado

### Fase 2 (Implementado ✅) - 13/03/2026
- [x] **Cardápio**: Módulo que combina receitas e produtos de revenda em uma única visão
- [x] **Produtos de Revenda**: CRUD completo para bebidas e produtos comprados prontos
  - Categorias: Refrigerantes, Águas, Sucos, Cervejas, Vinhos, Destilados, Energéticos
  - Cálculo automático de margem: (preço_venda - custo) / preço_venda
  - Controle de estoque por produto
- [x] **Produção**: Registro de produção diária com dedução automática de estoque
  - Alimenta KPI "Custo Produção Hoje" no Dashboard
  - Calcula custo total baseado na receita
- [x] **Vendas**: Registro de vendas com dedução automática de estoque
  - Suporta receitas (recipe_item) e produtos de revenda (resale_product)
  - Canais: Balcão, Delivery, iFood, Rappi, Uber Eats, WhatsApp, Telefone
  - KPIs: Receita, Custo, Lucro, Itens Vendidos
- [x] **Nova estrutura de navegação**: Dashboard > Cardápio > Fichas Técnicas > Produtos de Revenda > Ingredientes > Fornecedores > Estoque > Produção > Vendas > Relatórios > Configurações
- [x] **Cardápio Estendido** (13/03/2026):
  - Botão "Adicionar Item ao Cardápio" com modal completo
  - 3 tipos de itens: Receita, Produto de Revenda, Prato Composto
  - Pratos compostos com múltiplos componentes (receitas + produtos)
  - Cálculo dinâmico de custo: soma(custo_componente * quantidade)
  - Precificação: margem desejada, preço sugerido, preço de venda
  - Profit Intelligence: custo, preço, lucro, margem em cada card
  - Filtros por tipo (Receitas/Revenda/Compostos) e categoria
  - Categorias configuráveis (Entradas, Pratos Principais, etc.)
- [x] **Menu Profit Intelligence (Menu Engineering)** (13/03/2026):
  - Métricas por item: profit_per_unit, margin, units_sold_period, total_profit_period
  - Classificação Menu Engineering: STAR, PLOWHORSE, PUZZLE, DOG
  - Filtro de período: Hoje, Semana, Mês, Ano
  - Dashboard: "Top Itens Mais Lucrativos" (top 5 por lucro no período)
  - Relatórios: Nova tab "Rentabilidade do Cardápio" com tabela ordenável
  - Cards do Cardápio mostram badge de classificação e dados de vendas
- [x] **Indicadores Visuais de Status** (13/03/2026):
  - Cardápio: Labels em português (Excelente retorno, Vende bem lucro baixo, Boa margem baixa saída, Precisa revisar)
  - Estoque: Badges de status (Crítico/vermelho, Atenção/amarelo, Saudável/verde)
  - Relatórios: Mesmas classificações com cores consistentes
  - Fichas Técnicas: Status de margem já implementado
- [x] **Analytics Summary Layer** (13/03/2026):
  - Novas coleções: daily_sales_summary, monthly_menu_profit_summary, dashboard_metrics_cache, inventory_value_snapshots
  - Atualizações incrementais: vendas e produção atualizam automaticamente os summaries
  - Endpoint de backfill: POST /api/analytics/backfill para processar dados existentes
  - Índices MongoDB otimizados para todas as coleções de analytics
  - Relatórios leem de analytics/monthly-profit para melhor performance

### Fase 3 (Backlog - P0)
- [ ] Exportação de relatórios em PDF
- [ ] Exportação de dados em Excel
- [ ] Importação de ingredientes por planilha
- [ ] Histórico e análise anual detalhada

### Fase 4 (Backlog - P1)
- [ ] Integração com sistemas POS (ponto de venda)
- [ ] Multi-unidades por restaurante
- [ ] Módulo de compras com pedidos automáticos
- [ ] Comparativo de preços entre fornecedores
- [ ] Dashboard mobile otimizado

## O que foi Implementado

### 13/03/2026 - MVP + Extensões de Custos

**Backend (FastAPI + MongoDB)**
- Autenticação completa com Emergent Auth (Google OAuth)
- Sistema multi-tenant com isolamento de dados por restaurante
- **Multi-currency**: Configuração por tenant (EUR/USD/BRL/GBP)
- CRUD completo para: Fornecedores, Ingredientes, Receitas
- **Custos Operacionais**: Módulo completo com cálculo de custo fixo por prato
- **Receitas com custos expandidos**:
  - ingredients_cost (custo dos ingredientes)
  - variable_costs_total (custos variáveis)
  - fixed_cost_per_dish (custo fixo rateado)
  - total_cost (soma de todos os custos)
  - suggested_price (calculado pela margem desejada)
  - margin_status (below/within/above)
  - recommended_margin (por categoria)
- Sistema de estoque com entradas, saídas e movimentações
- Registro de produções com baixa automática de estoque
- Dashboard com métricas consolidadas
- Relatórios de custos por período
- Relatórios de análise de margens
- Alertas de estoque baixo
- Endpoint para recalcular todas as receitas

**Frontend (React + Tailwind CSS)**
- Landing page profissional com call-to-action
- Fluxo de onboarding para criação de restaurante
- Dashboard interativo com KPIs e alertas
- **Configurações**: Seletor de moeda e link para custos operacionais
- **Custos Operacionais**: Formulário completo com cálculos em tempo real
- **Fichas Técnicas**:
  - Ingredientes com quantidades
  - Custos variáveis (embalagem, delivery, cartão, etc.)
  - Margem de lucro desejada
  - Preço sugerido automático
  - Breakdown de custos detalhado
  - Alertas de margem baixa
- Página de Ingredientes com CRUD, filtros e busca
- Página de Fornecedores com cards organizados
- Página de Estoque com tabs (Inventário, Movimentações, Alertas)
- Página de Relatórios com gráficos (Recharts)
- Design responsivo e profissional
- Formatação de moeda dinâmica

**Arquitetura**
- Backend: `/app/backend/server.py`
- Frontend: `/app/frontend/src/`
- Collections MongoDB:
  - users, user_sessions
  - restaurants
  - suppliers
  - ingredients
  - recipes (expandido com variable_costs, margin_status, etc.)
  - stock_movements
  - productions
  - operational_costs (NOVO)

## Fórmulas Implementadas

### Custo Total do Prato
```
total_cost = ingredients_cost + variable_costs_total + fixed_cost_per_dish
```

### Custo Fixo por Prato
```
fixed_cost_per_dish = total_monthly_operational_cost / average_dishes_sold_per_month
```

### Preço Sugerido
```
suggested_price = total_cost / (1 - desired_profit_margin)
```

Exemplo:
- Custo = €5.00
- Margem desejada = 70%
- Preço sugerido = 5 / (1 - 0.70) = €16.67

## Métricas de Sucesso
- Backend: 97.1% de testes passando
- Frontend: 95% funcional
- Multi-currency funcionando
- Cálculos de custo/margem validados
- Sem erros de SelectItem (bug corrigido)

## Próximas Tarefas (Priorizado)
1. Implementar exportação PDF para relatórios
2. Implementar exportação Excel para dados
3. Melhorar feedback visual ao salvar formulários
4. Adicionar histórico de preços de ingredientes

## Stack Tecnológico
- **Frontend**: React 19, Tailwind CSS, Radix UI, Recharts, Lucide Icons
- **Backend**: FastAPI, Motor (async MongoDB)
- **Database**: MongoDB
- **Auth**: Emergent Auth (Google OAuth)
