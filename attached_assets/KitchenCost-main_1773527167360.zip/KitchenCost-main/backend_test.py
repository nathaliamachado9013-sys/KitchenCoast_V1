#!/usr/bin/env python3
"""
KitchenCost Backend API Testing Suite
Tests all CRUD operations, authentication, stock management, and reporting endpoints.
"""

import requests
import sys
import json
from datetime import datetime

class KitchenCostAPITester:
    def __init__(self, base_url="https://kitchen-cost-preview.preview.emergentagent.com/api"):
        self.base_url = base_url
        self.session_token = "test_session_1773413748976"
        self.user_id = "test-user-1773413748976"
        self.tests_run = 0
        self.tests_passed = 0
        self.restaurant_id = None
        self.supplier_id = None
        self.ingredient_id = None
        self.recipe_id = None

    def get_headers(self, auth=True):
        """Get headers for API requests"""
        headers = {'Content-Type': 'application/json'}
        if auth and self.session_token:
            headers['Authorization'] = f'Bearer {self.session_token}'
        return headers

    def run_test(self, name, method, endpoint, expected_status, data=None, auth=True):
        """Run a single API test"""
        url = f"{self.base_url}/{endpoint}"
        headers = self.get_headers(auth)
        
        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=10)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=headers, timeout=10)
            elif method == 'DELETE':
                response = requests.delete(url, headers=headers, timeout=10)
            else:
                print(f"❌ Unsupported method: {method}")
                return False, {}

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    return success, response.json()
                except:
                    return success, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    print(f"   Response: {response.text[:200]}")
                except:
                    pass
                return False, {}

        except requests.exceptions.Timeout:
            print(f"❌ Failed - Request timeout")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_health_check(self):
        """Test API health check"""
        success, response = self.run_test(
            "Health Check", "GET", "", 200, auth=False
        )
        if success:
            print(f"   Health status: {response.get('status', 'unknown')}")
        return success

    def test_health_specific(self):
        """Test specific health endpoint"""
        success, response = self.run_test(
            "Health Endpoint", "GET", "health", 200, auth=False
        )
        if success:
            print(f"   Health status: {response.get('status', 'unknown')}")
        return success

    def test_auth_me(self):
        """Test getting current user"""
        success, response = self.run_test(
            "Get Current User", "GET", "auth/me", 200
        )
        if success:
            print(f"   User: {response.get('name', 'Unknown')} ({response.get('email', 'No email')})")
        return success

    def test_auth_session_mock(self):
        """Test session exchange (mock - will fail without real session_id but tests endpoint)"""
        success, response = self.run_test(
            "Session Exchange (Mock)", "POST", "auth/session", 
            400,  # Expecting 400 for missing session_id
            data={"session_id": "fake_session_id"}, 
            auth=False
        )
        print("   Note: This is expected to fail without real Emergent Auth session_id")
        return True  # Mark as passed since 400 is expected behavior

    def test_create_restaurant(self):
        """Test creating a restaurant"""
        restaurant_data = {
            "name": "Test Kitchen",
            "address": "123 Test Street, Test City",
            "phone": "+55 11 99999-9999"
        }
        
        success, response = self.run_test(
            "Create Restaurant", "POST", "restaurants", 200, restaurant_data
        )
        
        if success:
            self.restaurant_id = response.get('restaurant_id')
            print(f"   Restaurant ID: {self.restaurant_id}")
        return success

    def test_get_restaurant(self):
        """Test getting user's restaurant"""
        success, response = self.run_test(
            "Get My Restaurant", "GET", "restaurants/me", 200
        )
        
        if success and response:
            print(f"   Restaurant: {response.get('name', 'Unknown')}")
            if not self.restaurant_id:
                self.restaurant_id = response.get('restaurant_id')
        return success

    def test_create_supplier(self):
        """Test creating a supplier"""
        supplier_data = {
            "name": "Test Supplier Ltd",
            "contact_name": "João Silva",
            "phone": "+55 11 88888-8888",
            "email": "joao@testsupplier.com",
            "address": "456 Supplier Ave",
            "notes": "Test supplier for integration testing"
        }
        
        success, response = self.run_test(
            "Create Supplier", "POST", "suppliers", 200, supplier_data
        )
        
        if success:
            self.supplier_id = response.get('supplier_id')
            print(f"   Supplier ID: {self.supplier_id}")
        return success

    def test_list_suppliers(self):
        """Test listing suppliers"""
        success, response = self.run_test(
            "List Suppliers", "GET", "suppliers", 200
        )
        
        if success and isinstance(response, list):
            print(f"   Found {len(response)} suppliers")
        return success

    def test_update_supplier(self):
        """Test updating a supplier"""
        if not self.supplier_id:
            print("❌ No supplier ID available for update test")
            return False
        
        update_data = {
            "notes": "Updated notes for testing"
        }
        
        success, response = self.run_test(
            "Update Supplier", "PUT", f"suppliers/{self.supplier_id}", 200, update_data
        )
        return success

    def test_get_supplier(self):
        """Test getting a specific supplier"""
        if not self.supplier_id:
            print("❌ No supplier ID available for get test")
            return False
        
        success, response = self.run_test(
            "Get Supplier", "GET", f"suppliers/{self.supplier_id}", 200
        )
        
        if success:
            print(f"   Supplier: {response.get('name', 'Unknown')}")
        return success

    def test_create_ingredient(self):
        """Test creating an ingredient"""
        ingredient_data = {
            "name": "Tomate",
            "unit": "kg",
            "cost_per_unit": 8.50,
            "supplier_id": self.supplier_id,
            "current_stock": 10.0,
            "min_stock": 2.0,
            "category": "Vegetais"
        }
        
        success, response = self.run_test(
            "Create Ingredient", "POST", "ingredients", 200, ingredient_data
        )
        
        if success:
            self.ingredient_id = response.get('ingredient_id')
            print(f"   Ingredient ID: {self.ingredient_id}")
        return success

    def test_list_ingredients(self):
        """Test listing ingredients"""
        success, response = self.run_test(
            "List Ingredients", "GET", "ingredients", 200
        )
        
        if success and isinstance(response, list):
            print(f"   Found {len(response)} ingredients")
        return success

    def test_update_ingredient(self):
        """Test updating an ingredient"""
        if not self.ingredient_id:
            print("❌ No ingredient ID available for update test")
            return False
        
        update_data = {
            "cost_per_unit": 9.00,
            "current_stock": 15.0
        }
        
        success, response = self.run_test(
            "Update Ingredient", "PUT", f"ingredients/{self.ingredient_id}", 200, update_data
        )
        return success

    def test_get_ingredient(self):
        """Test getting a specific ingredient"""
        if not self.ingredient_id:
            print("❌ No ingredient ID available for get test")
            return False
        
        success, response = self.run_test(
            "Get Ingredient", "GET", f"ingredients/{self.ingredient_id}", 200
        )
        
        if success:
            print(f"   Ingredient: {response.get('name', 'Unknown')} - Stock: {response.get('current_stock', 0)}")
        return success

    def test_create_recipe(self):
        """Test creating a recipe with cost calculation"""
        if not self.ingredient_id:
            print("❌ No ingredient ID available for recipe test")
            return False
        
        recipe_data = {
            "name": "Molho de Tomate",
            "description": "Molho básico de tomate para massas",
            "category": "Molhos",
            "yield_quantity": 4.0,
            "yield_unit": "porções",
            "ingredients": [
                {
                    "ingredient_id": self.ingredient_id,
                    "quantity": 2.0
                }
            ],
            "selling_price": 25.00,
            "preparation_time": 30,
            "instructions": "Corte os tomates e refogue com temperos"
        }
        
        success, response = self.run_test(
            "Create Recipe", "POST", "recipes", 200, recipe_data
        )
        
        if success:
            self.recipe_id = response.get('recipe_id')
            print(f"   Recipe ID: {self.recipe_id}")
            print(f"   Total Cost: R$ {response.get('total_cost', 0):.2f}")
        return success

    def test_list_recipes(self):
        """Test listing recipes"""
        success, response = self.run_test(
            "List Recipes", "GET", "recipes", 200
        )
        
        if success and isinstance(response, list):
            print(f"   Found {len(response)} recipes")
        return success

    def test_update_recipe(self):
        """Test updating a recipe"""
        if not self.recipe_id:
            print("❌ No recipe ID available for update test")
            return False
        
        update_data = {
            "selling_price": 30.00,
            "preparation_time": 25
        }
        
        success, response = self.run_test(
            "Update Recipe", "PUT", f"recipes/{self.recipe_id}", 200, update_data
        )
        return success

    def test_get_recipe(self):
        """Test getting a specific recipe"""
        if not self.recipe_id:
            print("❌ No recipe ID available for get test")
            return False
        
        success, response = self.run_test(
            "Get Recipe", "GET", f"recipes/{self.recipe_id}", 200
        )
        
        if success:
            print(f"   Recipe: {response.get('name', 'Unknown')}")
            print(f"   Cost per portion: R$ {response.get('cost_per_portion', 0):.2f}")
            print(f"   Margin: {response.get('margin_percentage', 0):.1f}%")
        return success

    def test_stock_entry(self):
        """Test creating stock entry"""
        if not self.ingredient_id:
            print("❌ No ingredient ID available for stock entry test")
            return False
        
        entry_data = {
            "ingredient_id": self.ingredient_id,
            "quantity": 5.0,
            "unit_cost": 8.75,
            "reason": "compra"
        }
        
        success, response = self.run_test(
            "Create Stock Entry", "POST", "stock/entry", 200, entry_data
        )
        
        if success:
            print(f"   New stock level: {response.get('new_stock', 0)}")
        return success

    def test_stock_exit(self):
        """Test creating stock exit"""
        if not self.ingredient_id:
            print("❌ No ingredient ID available for stock exit test")
            return False
        
        exit_data = {
            "ingredient_id": self.ingredient_id,
            "quantity": 1.0,
            "reason": "producao",
            "recipe_id": self.recipe_id
        }
        
        success, response = self.run_test(
            "Create Stock Exit", "POST", "stock/exit", 200, exit_data
        )
        
        if success:
            print(f"   New stock level: {response.get('new_stock', 0)}")
        return success

    def test_inventory_value(self):
        """Test getting inventory value"""
        success, response = self.run_test(
            "Get Inventory Value", "GET", "stock/inventory-value", 200
        )
        
        if success:
            print(f"   Total value: R$ {response.get('total_value', 0):.2f}")
            print(f"   Items count: {response.get('items_count', 0)}")
            print(f"   Low stock alerts: {response.get('low_stock_count', 0)}")
        return success

    def test_dashboard_summary(self):
        """Test getting dashboard summary"""
        success, response = self.run_test(
            "Get Dashboard Summary", "GET", "dashboard/summary", 200
        )
        
        if success:
            print(f"   Ingredients: {response.get('ingredients_count', 0)}")
            print(f"   Recipes: {response.get('recipes_count', 0)}")
            print(f"   Suppliers: {response.get('suppliers_count', 0)}")
            print(f"   Low stock alerts: {response.get('low_stock_alerts', 0)}")
        return success

    def test_cost_report(self):
        """Test getting cost report"""
        success, response = self.run_test(
            "Get Cost Report", "GET", "reports/costs?period=month", 200
        )
        
        if success:
            print(f"   Period: {response.get('period', 'unknown')}")
            print(f"   Total purchases: R$ {response.get('total_purchases', 0):.2f}")
            print(f"   Total production cost: R$ {response.get('total_production_cost', 0):.2f}")
        return success

    def test_margin_report(self):
        """Test getting margin report"""
        success, response = self.run_test(
            "Get Margin Report", "GET", "reports/margins", 200
        )
        
        if success:
            print(f"   Total recipes: {response.get('total_recipes', 0)}")
            print(f"   Average margin: {response.get('average_margin', 0):.1f}%")
            margin_dist = response.get('margin_distribution', {})
            print(f"   Margin distribution: {margin_dist}")
        return success

    def test_get_currencies(self):
        """Test getting supported currencies (NEW FEATURE)"""
        success, response = self.run_test(
            "Get Supported Currencies", "GET", "restaurants/currencies", 200, auth=False
        )
        
        if success:
            print(f"   Currencies: {response.get('currencies', [])}")
            print(f"   Default: {response.get('default', 'Unknown')}")
            symbols = response.get('symbols', {})
            print(f"   Symbols: {symbols}")
        return success

    def test_get_margin_recommendations(self):
        """Test getting margin recommendations by category (NEW FEATURE)"""
        success, response = self.run_test(
            "Get Margin Recommendations", "GET", "margin-recommendations", 200, auth=False
        )
        
        if success:
            print(f"   Categories with recommendations: {len(response) if isinstance(response, dict) else 0}")
            for category, rec in response.items() if isinstance(response, dict) else []:
                print(f"   {category}: {rec.get('label', 'Unknown')}")
                break  # Just show first one to avoid clutter
        return success

    def test_get_operational_costs(self):
        """Test getting operational costs (NEW FEATURE)"""
        success, response = self.run_test(
            "Get Operational Costs", "GET", "operational-costs", 200
        )
        
        if success:
            print(f"   Monthly total: R$ {response.get('total_monthly_cost', 0):.2f}")
            print(f"   Fixed cost per dish: R$ {response.get('fixed_cost_per_dish', 0):.2f}")
            print(f"   Average dishes/month: {response.get('average_dishes_sold_per_month', 0)}")
        return success

    def test_update_operational_costs(self):
        """Test updating operational costs (NEW FEATURE)"""
        costs_data = {
            "rent": 2500.00,
            "electricity": 400.00,
            "water": 150.00,
            "internet": 80.00,
            "salaries": 8000.00,
            "accounting": 300.00,
            "taxes": 600.00,
            "other_costs": 200.00,
            "average_dishes_sold_per_month": 500.0
        }
        
        success, response = self.run_test(
            "Update Operational Costs", "PUT", "operational-costs", 200, costs_data
        )
        
        if success:
            print(f"   Operational costs updated successfully")
        return success

    def test_create_recipe_with_variable_costs(self):
        """Test creating a recipe with variable costs (NEW FEATURE)"""
        if not self.ingredient_id:
            print("❌ No ingredient ID available for recipe with variable costs test")
            return False
        
        recipe_data = {
            "name": "Pizza Margherita Premium",
            "description": "Pizza especial com custos variáveis incluídos",
            "category": "Pizza",
            "yield_quantity": 1.0,
            "yield_unit": "porção",
            "ingredients": [
                {
                    "ingredient_id": self.ingredient_id,
                    "quantity": 0.3
                }
            ],
            "variable_costs": [
                {"name": "Embalagem", "value": 2.50},
                {"name": "Taxa de entrega", "value": 3.00},
                {"name": "Taxa de cartão", "value": 1.50}
            ],
            "desired_profit_margin": 0.65,  # 65%
            "selling_price": 35.00,
            "preparation_time": 20,
            "instructions": "Preparar pizza com ingredientes premium"
        }
        
        success, response = self.run_test(
            "Create Recipe with Variable Costs", "POST", "recipes", 200, recipe_data
        )
        
        if success:
            print(f"   Recipe ID: {response.get('recipe_id')}")
            print(f"   Total Cost: R$ {response.get('total_cost', 0):.2f}")
            # Store recipe ID for later tests
            if not self.recipe_id:
                self.recipe_id = response.get('recipe_id')
        return success

    def test_update_recipe_with_margin(self):
        """Test updating recipe with desired profit margin (NEW FEATURE)"""
        if not self.recipe_id:
            print("❌ No recipe ID available for margin update test")
            return False
        
        update_data = {
            "desired_profit_margin": 0.70,  # 70%
            "selling_price": 40.00
        }
        
        success, response = self.run_test(
            "Update Recipe with Margin", "PUT", f"recipes/{self.recipe_id}", 200, update_data
        )
        
        if success:
            print(f"   Recipe updated with new margin successfully")
        return success

    def test_recipe_cost_breakdown(self):
        """Test getting recipe with complete cost breakdown (NEW FEATURE)"""
        if not self.recipe_id:
            print("❌ No recipe ID available for cost breakdown test")
            return False
        
        success, response = self.run_test(
            "Get Recipe Cost Breakdown", "GET", f"recipes/{self.recipe_id}", 200
        )
        
        if success:
            print(f"   Recipe: {response.get('name', 'Unknown')}")
            print(f"   Ingredients cost: R$ {response.get('ingredients_cost', 0):.2f}")
            print(f"   Variable costs total: R$ {response.get('variable_costs_total', 0):.2f}")
            print(f"   Fixed cost per dish: R$ {response.get('fixed_cost_per_dish', 0):.2f}")
            print(f"   Total cost: R$ {response.get('total_cost', 0):.2f}")
            print(f"   Suggested price: R$ {response.get('suggested_price', 0):.2f}")
            print(f"   Margin status: {response.get('margin_status', 'unknown')}")
            print(f"   Recommended margin: {response.get('recommended_margin', {}).get('label', 'None')}")
        return success

    def test_recalculate_all_recipes(self):
        """Test recalculating all recipes (NEW FEATURE)"""
        success, response = self.run_test(
            "Recalculate All Recipes", "POST", "recipes/recalculate-all", 200
        )
        
        if success:
            print(f"   Response: {response.get('message', 'No message')}")
        return success

    def test_delete_recipe(self):
        """Test deleting a recipe"""
        if not self.recipe_id:
            print("❌ No recipe ID available for delete test")
            return False
        
        success, response = self.run_test(
            "Delete Recipe", "DELETE", f"recipes/{self.recipe_id}", 200
        )
        return success

    def test_delete_ingredient(self):
        """Test deleting an ingredient"""
        if not self.ingredient_id:
            print("❌ No ingredient ID available for delete test")
            return False
        
        success, response = self.run_test(
            "Delete Ingredient", "DELETE", f"ingredients/{self.ingredient_id}", 200
        )
        return success

    def test_delete_supplier(self):
        """Test deleting a supplier"""
        if not self.supplier_id:
            print("❌ No supplier ID available for delete test")
            return False
        
        success, response = self.run_test(
            "Delete Supplier", "DELETE", f"suppliers/{self.supplier_id}", 200
        )
        return success

    def run_all_tests(self):
        """Run the complete test suite"""
        print("=" * 80)
        print("🚀 STARTING KITCHENCOST API TESTING SUITE")
        print("=" * 80)
        print(f"Base URL: {self.base_url}")
        print(f"Session Token: {self.session_token}")
        print(f"Test Time: {datetime.now()}")
        
        # Basic health and auth tests
        self.test_health_check()
        self.test_health_specific()
        self.test_auth_session_mock()
        self.test_auth_me()
        
        # NEW FEATURE TESTS - Multi-currency and system configuration
        self.test_get_currencies()
        self.test_get_margin_recommendations()
        
        # Restaurant setup
        self.test_create_restaurant()
        self.test_get_restaurant()
        
        # NEW FEATURE TESTS - Operational costs
        self.test_get_operational_costs()
        self.test_update_operational_costs()
        
        # Supplier CRUD
        self.test_create_supplier()
        self.test_list_suppliers()
        self.test_get_supplier()
        self.test_update_supplier()
        
        # Ingredient CRUD
        self.test_create_ingredient()
        self.test_list_ingredients()
        self.test_get_ingredient()
        self.test_update_ingredient()
        
        # Recipe CRUD with cost calculation
        self.test_create_recipe()
        self.test_list_recipes()
        self.test_get_recipe()
        self.test_update_recipe()
        
        # NEW FEATURE TESTS - Enhanced recipes with variable costs and margins
        self.test_create_recipe_with_variable_costs()
        self.test_update_recipe_with_margin()
        self.test_recipe_cost_breakdown()
        self.test_recalculate_all_recipes()
        
        # Stock management
        self.test_stock_entry()
        self.test_stock_exit()
        self.test_inventory_value()
        
        # Dashboard and reports
        self.test_dashboard_summary()
        self.test_cost_report()
        self.test_margin_report()
        
        # Cleanup - delete in reverse order
        self.test_delete_recipe()
        self.test_delete_ingredient()
        self.test_delete_supplier()
        
        # Final results
        print("\n" + "=" * 80)
        print("📊 TEST RESULTS")
        print("=" * 80)
        print(f"Tests run: {self.tests_run}")
        print(f"Tests passed: {self.tests_passed}")
        print(f"Tests failed: {self.tests_run - self.tests_passed}")
        success_rate = (self.tests_passed / self.tests_run * 100) if self.tests_run > 0 else 0
        print(f"Success rate: {success_rate:.1f}%")
        
        if self.tests_passed == self.tests_run:
            print("🎉 ALL TESTS PASSED!")
            return 0
        else:
            print(f"❌ {self.tests_run - self.tests_passed} TESTS FAILED")
            return 1

def main():
    tester = KitchenCostAPITester()
    return tester.run_all_tests()

if __name__ == "__main__":
    sys.exit(main())