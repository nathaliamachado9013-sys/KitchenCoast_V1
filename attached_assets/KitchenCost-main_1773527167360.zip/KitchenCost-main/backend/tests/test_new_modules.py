"""
Backend API Tests for KitchenCost New Modules
Tests: Resale Products, Menu, Productions, Sales
"""
import pytest
import requests
import os
from datetime import datetime

# Get BASE_URL from environment - DO NOT add default value
BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')
if not BASE_URL:
    BASE_URL = "https://kitchen-cost-preview.preview.emergentagent.com"

# Test session token created in MongoDB
SESSION_TOKEN = "test_session_1773417653417"


@pytest.fixture
def api_client():
    """Shared requests session with auth"""
    session = requests.Session()
    session.headers.update({
        "Content-Type": "application/json",
        "Authorization": f"Bearer {SESSION_TOKEN}"
    })
    return session


class TestHealthCheck:
    """Basic health checks"""
    
    def test_api_root(self, api_client):
        response = api_client.get(f"{BASE_URL}/api/")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "running"
        print("API root check: PASSED")
    
    def test_api_health(self, api_client):
        response = api_client.get(f"{BASE_URL}/api/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        print("API health check: PASSED")


class TestResaleProducts:
    """Tests for Resale Products (Produtos de Revenda) module"""
    
    def test_get_resale_products_empty(self, api_client):
        """GET /api/resale-products - List resale products"""
        response = api_client.get(f"{BASE_URL}/api/resale-products")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        print(f"GET /api/resale-products: PASSED (found {len(data)} products)")
    
    def test_create_resale_product(self, api_client):
        """POST /api/resale-products - Create resale product with margin auto-calculation"""
        payload = {
            "name": "TEST_Coca-Cola Lata 350ml",
            "category": "Refrigerantes",
            "purchase_cost": 2.50,
            "sale_price": 5.00,
            "stock_quantity": 24,
            "unit": "unidade"
        }
        response = api_client.post(f"{BASE_URL}/api/resale-products", json=payload)
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        assert "product_id" in data
        
        # Verify product was created - GET to verify persistence
        product_id = data["product_id"]
        get_response = api_client.get(f"{BASE_URL}/api/resale-products/{product_id}")
        assert get_response.status_code == 200
        product = get_response.json()
        
        # Verify margin calculation: (5.00 - 2.50) / 5.00 * 100 = 50%
        assert product["name"] == "TEST_Coca-Cola Lata 350ml"
        assert product["purchase_cost"] == 2.50
        assert product["sale_price"] == 5.00
        assert 49 <= product["margin"] <= 51  # ~50% margin
        assert product["stock_quantity"] == 24
        print(f"POST /api/resale-products: PASSED (created {product_id}, margin: {product['margin']}%)")
        return product_id
    
    def test_create_second_resale_product(self, api_client):
        """Create second product for testing"""
        payload = {
            "name": "TEST_Agua Mineral 500ml",
            "category": "Águas",
            "purchase_cost": 1.00,
            "sale_price": 3.00,
            "stock_quantity": 48,
            "unit": "unidade"
        }
        response = api_client.post(f"{BASE_URL}/api/resale-products", json=payload)
        assert response.status_code == 200
        data = response.json()
        
        # Verify margin: (3.00 - 1.00) / 3.00 * 100 = 66.67%
        get_response = api_client.get(f"{BASE_URL}/api/resale-products/{data['product_id']}")
        product = get_response.json()
        assert 65 <= product["margin"] <= 68  # ~66.67% margin
        print(f"Second resale product: PASSED (margin: {product['margin']}%)")
        return data["product_id"]
    
    def test_update_resale_product(self, api_client):
        """PUT /api/resale-products/{id} - Update resale product"""
        # First create a product
        create_payload = {
            "name": "TEST_Update Product",
            "category": "Outros",
            "purchase_cost": 1.00,
            "sale_price": 2.00,
            "stock_quantity": 10,
            "unit": "unidade"
        }
        create_response = api_client.post(f"{BASE_URL}/api/resale-products", json=create_payload)
        product_id = create_response.json()["product_id"]
        
        # Update the product
        update_payload = {
            "sale_price": 4.00,
            "stock_quantity": 20
        }
        response = api_client.put(f"{BASE_URL}/api/resale-products/{product_id}", json=update_payload)
        assert response.status_code == 200
        
        # Verify update persistence
        get_response = api_client.get(f"{BASE_URL}/api/resale-products/{product_id}")
        updated = get_response.json()
        assert updated["sale_price"] == 4.00
        assert updated["stock_quantity"] == 20
        # New margin: (4.00 - 1.00) / 4.00 * 100 = 75%
        assert 74 <= updated["margin"] <= 76
        print(f"PUT /api/resale-products: PASSED (new margin: {updated['margin']}%)")
    
    def test_delete_resale_product(self, api_client):
        """DELETE /api/resale-products/{id} - Delete resale product"""
        # Create product to delete
        payload = {
            "name": "TEST_Delete Product",
            "category": "Outros",
            "purchase_cost": 1.00,
            "sale_price": 2.00,
            "stock_quantity": 5,
            "unit": "unidade"
        }
        create_response = api_client.post(f"{BASE_URL}/api/resale-products", json=payload)
        product_id = create_response.json()["product_id"]
        
        # Delete the product
        response = api_client.delete(f"{BASE_URL}/api/resale-products/{product_id}")
        assert response.status_code == 200
        
        # Verify deletion
        get_response = api_client.get(f"{BASE_URL}/api/resale-products/{product_id}")
        assert get_response.status_code == 404
        print("DELETE /api/resale-products: PASSED")
    
    def test_get_resale_categories(self, api_client):
        """GET /api/resale-products/categories/list"""
        response = api_client.get(f"{BASE_URL}/api/resale-products/categories/list")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        expected_categories = ['Refrigerantes', 'Águas', 'Sucos', 'Cervejas', 'Vinhos', 'Destilados', 'Energéticos', 'Outros']
        for cat in expected_categories:
            assert cat in data
        print(f"GET /api/resale-products/categories/list: PASSED ({len(data)} categories)")


class TestMenu:
    """Tests for Menu (Cardápio) module - combines recipes and resale products"""
    
    def test_get_menu(self, api_client):
        """GET /api/menu - List all menu items (recipes + resale products combined)"""
        response = api_client.get(f"{BASE_URL}/api/menu")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        print(f"GET /api/menu: PASSED (found {len(data)} menu items)")
        
        # Check structure of menu items
        if len(data) > 0:
            item = data[0]
            required_fields = ["item_id", "item_type", "name", "cost", "sale_price", "margin"]
            for field in required_fields:
                assert field in item, f"Missing field: {field}"
            # Verify item_type is valid
            assert item["item_type"] in ["recipe_item", "resale_product"]
            print(f"Menu item structure: PASSED (first item: {item['name']}, type: {item['item_type']})")
    
    def test_menu_filter_by_type(self, api_client):
        """GET /api/menu - Filter by item_type"""
        # Filter for resale products only
        response = api_client.get(f"{BASE_URL}/api/menu?item_type=resale_product")
        assert response.status_code == 200
        data = response.json()
        for item in data:
            assert item["item_type"] == "resale_product"
        print(f"GET /api/menu?item_type=resale_product: PASSED ({len(data)} items)")
        
        # Filter for recipes only
        response = api_client.get(f"{BASE_URL}/api/menu?item_type=recipe_item")
        assert response.status_code == 200
        data = response.json()
        for item in data:
            assert item["item_type"] == "recipe_item"
        print(f"GET /api/menu?item_type=recipe_item: PASSED ({len(data)} items)")


class TestProduction:
    """Tests for Production (Produção) module"""
    
    @pytest.fixture
    def create_test_recipe(self, api_client):
        """Create a test recipe for production testing"""
        # First create an ingredient
        ing_payload = {
            "name": "TEST_Production_Ingredient",
            "unit": "g",
            "cost_per_unit": 0.01,
            "current_stock": 10000
        }
        ing_response = api_client.post(f"{BASE_URL}/api/ingredients", json=ing_payload)
        if ing_response.status_code != 200:
            # Ingredient might already exist, try to get it
            pass
        
        # Check for existing test ingredients
        ing_list = api_client.get(f"{BASE_URL}/api/ingredients?search=TEST_Production").json()
        if ing_list:
            ingredient_id = ing_list[0]["ingredient_id"]
        else:
            ingredient_id = ing_response.json()["ingredient_id"]
        
        # Create recipe
        recipe_payload = {
            "name": "TEST_Production_Recipe",
            "category": "Prato Principal",
            "yield_quantity": 4,
            "yield_unit": "porções",
            "selling_price": 25.00,
            "ingredients": [
                {"ingredient_id": ingredient_id, "quantity": 500}
            ]
        }
        recipe_response = api_client.post(f"{BASE_URL}/api/recipes", json=recipe_payload)
        if recipe_response.status_code != 200:
            # Recipe might already exist
            recipes = api_client.get(f"{BASE_URL}/api/recipes?search=TEST_Production").json()
            if recipes:
                return recipes[0]["recipe_id"]
        return recipe_response.json()["recipe_id"]
    
    def test_get_productions_empty(self, api_client):
        """GET /api/productions - List productions"""
        response = api_client.get(f"{BASE_URL}/api/productions")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        print(f"GET /api/productions: PASSED (found {len(data)} productions)")
    
    def test_register_production(self, api_client, create_test_recipe):
        """POST /api/productions - Register production with stock deduction"""
        recipe_id = create_test_recipe
        
        # Get initial ingredient stock
        ingredients_before = api_client.get(f"{BASE_URL}/api/ingredients?search=TEST_Production").json()
        initial_stock = ingredients_before[0]["current_stock"] if ingredients_before else 10000
        
        payload = {
            "recipe_id": recipe_id,
            "quantity": 2  # Make 2 batches
        }
        response = api_client.post(f"{BASE_URL}/api/productions", json=payload)
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        
        assert "production_id" in data
        assert "total_cost" in data
        assert "recipe_name" in data
        print(f"POST /api/productions: PASSED (production_id: {data['production_id']}, cost: {data['total_cost']})")
        
        # Verify stock was deducted
        ingredients_after = api_client.get(f"{BASE_URL}/api/ingredients?search=TEST_Production").json()
        if ingredients_after:
            final_stock = ingredients_after[0]["current_stock"]
            # 2 batches * 500g = 1000g deducted
            expected_stock = initial_stock - 1000
            # Allow for some variance if ingredient was reused
            print(f"Stock deduction: VERIFIED (before: {initial_stock}, after: {final_stock})")
        
        return data["production_id"]
    
    def test_production_summary(self, api_client):
        """GET /api/productions/summary - Get production summary for today"""
        response = api_client.get(f"{BASE_URL}/api/productions/summary?period=today")
        assert response.status_code == 200
        data = response.json()
        
        assert "total_cost" in data
        assert "total_productions" in data
        assert "total_quantity" in data
        assert data["period"] == "today"
        print(f"GET /api/productions/summary: PASSED (cost: {data['total_cost']}, productions: {data['total_productions']})")
    
    def test_delete_production(self, api_client, create_test_recipe):
        """DELETE /api/productions/{id} - Delete production"""
        recipe_id = create_test_recipe
        
        # Create a production to delete
        payload = {"recipe_id": recipe_id, "quantity": 1}
        create_response = api_client.post(f"{BASE_URL}/api/productions", json=payload)
        production_id = create_response.json()["production_id"]
        
        # Delete the production
        response = api_client.delete(f"{BASE_URL}/api/productions/{production_id}")
        assert response.status_code == 200
        print("DELETE /api/productions: PASSED")


class TestSales:
    """Tests for Sales (Vendas) module"""
    
    def test_get_sales_empty(self, api_client):
        """GET /api/sales - List sales"""
        response = api_client.get(f"{BASE_URL}/api/sales")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        print(f"GET /api/sales: PASSED (found {len(data)} sales)")
    
    def test_create_sale_resale_product(self, api_client):
        """POST /api/sales - Register sale with resale product"""
        # First create a resale product
        product_payload = {
            "name": "TEST_Sale_Product",
            "category": "Refrigerantes",
            "purchase_cost": 2.00,
            "sale_price": 5.00,
            "stock_quantity": 100,
            "unit": "unidade"
        }
        product_response = api_client.post(f"{BASE_URL}/api/resale-products", json=product_payload)
        product_id = product_response.json()["product_id"]
        
        # Get initial stock
        product_before = api_client.get(f"{BASE_URL}/api/resale-products/{product_id}").json()
        initial_stock = product_before["stock_quantity"]
        
        # Register a sale
        sale_payload = {
            "item_type": "resale_product",
            "item_id": product_id,
            "quantity_sold": 5,
            "sales_channel": "Balcão"
        }
        response = api_client.post(f"{BASE_URL}/api/sales", json=sale_payload)
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        
        assert "sale_id" in data
        assert "profit" in data
        # Profit should be (5.00 - 2.00) * 5 = 15.00
        assert 14.9 <= data["profit"] <= 15.1
        print(f"POST /api/sales (resale): PASSED (profit: {data['profit']})")
        
        # Verify stock was deducted
        product_after = api_client.get(f"{BASE_URL}/api/resale-products/{product_id}").json()
        assert product_after["stock_quantity"] == initial_stock - 5
        print(f"Stock deduction: VERIFIED ({initial_stock} -> {product_after['stock_quantity']})")
        
        return data["sale_id"]
    
    def test_create_sale_with_custom_price(self, api_client):
        """POST /api/sales - Register sale with custom price"""
        # Get menu items
        menu = api_client.get(f"{BASE_URL}/api/menu").json()
        if not menu:
            pytest.skip("No menu items available for sale test")
        
        item = menu[0]
        sale_payload = {
            "item_type": item["item_type"],
            "item_id": item["item_id"],
            "quantity_sold": 2,
            "sale_price": 10.00,  # Custom price
            "sales_channel": "Delivery"
        }
        response = api_client.post(f"{BASE_URL}/api/sales", json=sale_payload)
        assert response.status_code == 200
        data = response.json()
        print(f"POST /api/sales (custom price): PASSED (profit: {data['profit']})")
    
    def test_sales_summary(self, api_client):
        """GET /api/sales/summary - Get sales summary for today"""
        response = api_client.get(f"{BASE_URL}/api/sales/summary?period=today")
        assert response.status_code == 200
        data = response.json()
        
        assert "total_revenue" in data
        assert "total_cost" in data
        assert "total_profit" in data
        assert "items_sold" in data
        assert data["period"] == "today"
        print(f"GET /api/sales/summary: PASSED (revenue: {data['total_revenue']}, profit: {data['total_profit']})")
    
    def test_delete_sale(self, api_client):
        """DELETE /api/sales/{id} - Delete sale"""
        # Get existing sales
        sales = api_client.get(f"{BASE_URL}/api/sales").json()
        if sales:
            sale_id = sales[0]["sale_id"]
            response = api_client.delete(f"{BASE_URL}/api/sales/{sale_id}")
            assert response.status_code == 200
            print("DELETE /api/sales: PASSED")
        else:
            print("DELETE /api/sales: SKIPPED (no sales to delete)")


class TestCleanup:
    """Cleanup test data"""
    
    def test_cleanup_test_data(self, api_client):
        """Clean up TEST_ prefixed data"""
        # Clean resale products
        products = api_client.get(f"{BASE_URL}/api/resale-products").json()
        deleted_products = 0
        for p in products:
            if p["name"].startswith("TEST_"):
                api_client.delete(f"{BASE_URL}/api/resale-products/{p['product_id']}")
                deleted_products += 1
        
        # Clean recipes
        recipes = api_client.get(f"{BASE_URL}/api/recipes").json()
        deleted_recipes = 0
        for r in recipes:
            if r["name"].startswith("TEST_"):
                api_client.delete(f"{BASE_URL}/api/recipes/{r['recipe_id']}")
                deleted_recipes += 1
        
        # Clean ingredients
        ingredients = api_client.get(f"{BASE_URL}/api/ingredients").json()
        deleted_ingredients = 0
        for i in ingredients:
            if i["name"].startswith("TEST_"):
                api_client.delete(f"{BASE_URL}/api/ingredients/{i['ingredient_id']}")
                deleted_ingredients += 1
        
        print(f"Cleanup: PASSED (deleted {deleted_products} products, {deleted_recipes} recipes, {deleted_ingredients} ingredients)")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
