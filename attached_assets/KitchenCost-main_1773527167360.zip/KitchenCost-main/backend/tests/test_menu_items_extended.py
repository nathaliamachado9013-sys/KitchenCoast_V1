"""
Backend API Tests for Extended Menu Items (Cardápio) Module
Tests: Custom Menu Items with types: recipe, resale_product, composite_dish
Tests: Profit intelligence (cost, sale_price, margin, profit_per_unit)
"""
import pytest
import requests
import os

# Get BASE_URL from environment
BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')
if not BASE_URL:
    BASE_URL = "https://kitchen-cost-preview.preview.emergentagent.com"

# Test session token (created via mongosh)
SESSION_TOKEN = "test_session_menu_1773418816932"


@pytest.fixture(scope="session")
def api_client():
    """Shared requests session with auth - session scoped"""
    session = requests.Session()
    session.headers.update({
        "Content-Type": "application/json",
        "Authorization": f"Bearer {SESSION_TOKEN}"
    })
    return session


class TestMenuCategories:
    """Test GET /api/menu/categories"""
    
    def test_get_menu_categories(self, api_client):
        """GET /api/menu/categories - Returns list of menu categories"""
        response = api_client.get(f"{BASE_URL}/api/menu/categories")
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        
        # Should return predefined categories
        assert isinstance(data, list)
        expected_categories = ['Entradas', 'Pratos Principais', 'Acompanhamentos', 'Sobremesas', 'Bebidas', 'Snacks', 'Pizzas', 'Outros']
        for cat in expected_categories:
            assert cat in data, f"Missing category: {cat}"
        print(f"GET /api/menu/categories: PASSED ({len(data)} categories)")


class TestSetupTestData:
    """Create necessary test data for menu item tests"""
    
    def test_create_test_ingredient(self, api_client):
        """Create test ingredient for recipe"""
        payload = {
            "name": "TEST_MENU_Ingredient_Tomato",
            "unit": "kg",
            "cost_per_unit": 3.50,
            "current_stock": 100
        }
        response = api_client.post(f"{BASE_URL}/api/ingredients", json=payload)
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        assert "ingredient_id" in data
        print(f"Created test ingredient: {data['ingredient_id']}")
    
    def test_create_test_recipe(self, api_client):
        """Create test recipe"""
        # Get ingredient
        ingredients = api_client.get(f"{BASE_URL}/api/ingredients?search=TEST_MENU_Ingredient").json()
        if not ingredients:
            pytest.skip("Test ingredient not found")
        ingredient_id = ingredients[0]["ingredient_id"]
        
        payload = {
            "name": "TEST_MENU_Recipe_Pasta",
            "category": "Massa",
            "yield_quantity": 2,
            "yield_unit": "porções",
            "selling_price": 25.00,
            "desired_profit_margin": 0.65,
            "ingredients": [
                {"ingredient_id": ingredient_id, "quantity": 0.5}
            ]
        }
        response = api_client.post(f"{BASE_URL}/api/recipes", json=payload)
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        assert "recipe_id" in data
        print(f"Created test recipe: {data['recipe_id']}")
    
    def test_create_test_resale_product(self, api_client):
        """Create test resale product"""
        payload = {
            "name": "TEST_MENU_Product_Soda",
            "category": "Refrigerantes",
            "purchase_cost": 2.00,
            "sale_price": 5.00,
            "stock_quantity": 50,
            "unit": "unidade"
        }
        response = api_client.post(f"{BASE_URL}/api/resale-products", json=payload)
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        assert "product_id" in data
        print(f"Created test resale product: {data['product_id']}")


class TestMenuItemTypeRecipe:
    """POST /api/menu-items - Create menu item type 'recipe' with recipe_id"""
    
    def test_create_menu_item_recipe(self, api_client):
        """Create menu item of type recipe"""
        # Get test recipe
        recipes = api_client.get(f"{BASE_URL}/api/recipes?search=TEST_MENU_Recipe").json()
        if not recipes:
            pytest.skip("Test recipe not found")
        recipe_id = recipes[0]["recipe_id"]
        
        payload = {
            "name": "TEST_MenuItem_Pasta Special",
            "category": "Pratos Principais",
            "item_type": "recipe",
            "recipe_id": recipe_id,
            "desired_margin": 0.70,
            "sale_price": 30.00
        }
        response = api_client.post(f"{BASE_URL}/api/menu-items", json=payload)
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        
        assert "menu_item_id" in data
        assert "cost" in data  # From calculate_menu_item_cost
        assert "margin" in data
        assert "profit_per_unit" in data
        
        menu_item_id = data["menu_item_id"]
        print(f"POST /api/menu-items (recipe): PASSED - ID: {menu_item_id}, cost: {data['cost']}, margin: {data['margin']}%")
        
        # Verify GET returns the item with calculations
        get_response = api_client.get(f"{BASE_URL}/api/menu-items/{menu_item_id}")
        assert get_response.status_code == 200
        item = get_response.json()
        assert item["item_type"] == "recipe"
        assert item["recipe_id"] == recipe_id
        assert item["cost"] >= 0  # Cost should be calculated
        print(f"GET /api/menu-items/{menu_item_id}: PASSED - verified persistence")
    
    def test_recipe_menu_item_has_profit_intelligence(self, api_client):
        """Verify recipe menu item has cost, margin, profit_per_unit in response"""
        # Get test recipe
        recipes = api_client.get(f"{BASE_URL}/api/recipes?search=TEST_MENU_Recipe").json()
        if not recipes:
            pytest.skip("Test recipe not found")
        recipe_id = recipes[0]["recipe_id"]
        
        # Create menu item
        payload = {
            "name": "TEST_MenuItem_Recipe_Profit_Check",
            "category": "Pratos Principais",
            "item_type": "recipe",
            "recipe_id": recipe_id,
            "sale_price": 28.00
        }
        response = api_client.post(f"{BASE_URL}/api/menu-items", json=payload)
        assert response.status_code == 200
        data = response.json()
        
        # Must have profit intelligence fields
        assert "cost" in data, "Missing cost in response"
        assert "margin" in data, "Missing margin in response"
        assert "profit_per_unit" in data, "Missing profit_per_unit in response"
        assert "sale_price" in data, "Missing sale_price in response"
        
        # Verify margin calculation: margin = (sale_price - cost) / sale_price * 100
        if data["sale_price"] > 0:
            expected_margin = ((data["sale_price"] - data["cost"]) / data["sale_price"]) * 100
            assert abs(data["margin"] - expected_margin) < 1, f"Margin mismatch: {data['margin']} vs {expected_margin}"
        
        print(f"Recipe profit intelligence: PASSED - cost: {data['cost']}, margin: {data['margin']}%, profit: {data['profit_per_unit']}")


class TestMenuItemTypeResaleProduct:
    """POST /api/menu-items - Create menu item type 'resale_product' with product_id"""
    
    def test_create_menu_item_resale_product(self, api_client):
        """Create menu item of type resale_product"""
        # Get test product
        products = api_client.get(f"{BASE_URL}/api/resale-products?search=TEST_MENU_Product").json()
        if not products:
            pytest.skip("Test product not found")
        product_id = products[0]["product_id"]
        
        payload = {
            "name": "TEST_MenuItem_Soda Premium",
            "category": "Bebidas",
            "item_type": "resale_product",
            "product_id": product_id,
            "desired_margin": 0.60,
            "sale_price": 6.00
        }
        response = api_client.post(f"{BASE_URL}/api/menu-items", json=payload)
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        
        assert "menu_item_id" in data
        assert "cost" in data
        assert "margin" in data
        assert "profit_per_unit" in data
        
        menu_item_id = data["menu_item_id"]
        print(f"POST /api/menu-items (resale_product): PASSED - ID: {menu_item_id}, cost: {data['cost']}, margin: {data['margin']}%")
        
        # Verify cost comes from product's purchase_cost (should be 2.00)
        assert data["cost"] == 2.00, f"Expected cost 2.00, got {data['cost']}"
        
        # Verify margin: (6.00 - 2.00) / 6.00 * 100 = 66.67%
        assert 65 <= data["margin"] <= 68, f"Expected ~66.67% margin, got {data['margin']}%"
        
        # Verify profit_per_unit: 6.00 - 2.00 = 4.00
        assert 3.9 <= data["profit_per_unit"] <= 4.1, f"Expected ~4.00 profit, got {data['profit_per_unit']}"


class TestMenuItemTypeCompositeDish:
    """POST /api/menu-items - Create menu item type 'composite_dish' with components array"""
    
    def test_create_menu_item_composite_dish(self, api_client):
        """Create menu item of type composite_dish with multiple components"""
        # Get test recipe
        recipes = api_client.get(f"{BASE_URL}/api/recipes?search=TEST_MENU_Recipe").json()
        if not recipes:
            pytest.skip("Test recipe not found")
        recipe_id = recipes[0]["recipe_id"]
        
        # Get test product
        products = api_client.get(f"{BASE_URL}/api/resale-products?search=TEST_MENU_Product").json()
        if not products:
            pytest.skip("Test product not found")
        product_id = products[0]["product_id"]
        
        payload = {
            "name": "TEST_MenuItem_Combo Meal",
            "category": "Pratos Principais",
            "item_type": "composite_dish",
            "components": [
                {"component_type": "recipe", "component_id": recipe_id, "quantity": 1},
                {"component_type": "resale_product", "component_id": product_id, "quantity": 2}
            ],
            "desired_margin": 0.65,
            "sale_price": 35.00
        }
        response = api_client.post(f"{BASE_URL}/api/menu-items", json=payload)
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        
        assert "menu_item_id" in data
        assert "cost" in data
        assert "margin" in data
        assert "profit_per_unit" in data
        
        menu_item_id = data["menu_item_id"]
        print(f"POST /api/menu-items (composite_dish): PASSED - ID: {menu_item_id}, cost: {data['cost']}, margin: {data['margin']}%")
        
        # Verify GET
        get_response = api_client.get(f"{BASE_URL}/api/menu-items/{menu_item_id}")
        assert get_response.status_code == 200
        item = get_response.json()
        assert item["item_type"] == "composite_dish"
        assert len(item.get("components", [])) == 2
    
    def test_composite_dish_cost_calculation(self, api_client):
        """Verify composite dish cost = sum(component_cost * quantity)"""
        # Get test recipe
        recipes = api_client.get(f"{BASE_URL}/api/recipes?search=TEST_MENU_Recipe").json()
        if not recipes:
            pytest.skip("Test recipe not found")
        recipe_id = recipes[0]["recipe_id"]
        recipe = api_client.get(f"{BASE_URL}/api/recipes/{recipe_id}").json()
        recipe_cost = recipe.get("cost_per_portion", 0)
        
        # Get test product
        products = api_client.get(f"{BASE_URL}/api/resale-products?search=TEST_MENU_Product").json()
        if not products:
            pytest.skip("Test product not found")
        product_id = products[0]["product_id"]
        product = api_client.get(f"{BASE_URL}/api/resale-products/{product_id}").json()
        product_cost = product.get("purchase_cost", 0)
        
        # Create composite with known quantities
        payload = {
            "name": "TEST_MenuItem_Cost_Calc_Verify",
            "category": "Pratos Principais",
            "item_type": "composite_dish",
            "components": [
                {"component_type": "recipe", "component_id": recipe_id, "quantity": 2},  # 2x recipe
                {"component_type": "resale_product", "component_id": product_id, "quantity": 3}  # 3x product
            ],
            "sale_price": 50.00
        }
        response = api_client.post(f"{BASE_URL}/api/menu-items", json=payload)
        assert response.status_code == 200
        data = response.json()
        
        # Expected cost = (recipe_cost * 2) + (product_cost * 3)
        expected_cost = (recipe_cost * 2) + (product_cost * 3)
        
        # Allow small rounding difference
        assert abs(data["cost"] - expected_cost) < 0.5, f"Cost mismatch: expected {expected_cost}, got {data['cost']}"
        print(f"Composite cost calculation: PASSED - recipe_cost={recipe_cost}, product_cost={product_cost}, total={data['cost']} (expected={expected_cost})")


class TestSuggestedPriceCalculation:
    """Verify suggested_price = cost / (1 - desired_margin)"""
    
    def test_suggested_price_formula(self, api_client):
        """Test suggested price calculation"""
        # Create a simple resale product first
        product_payload = {
            "name": "TEST_MENU_SuggestedPrice_Product",
            "category": "Outros",
            "purchase_cost": 10.00,
            "sale_price": 20.00,
            "stock_quantity": 10,
            "unit": "unidade"
        }
        product_response = api_client.post(f"{BASE_URL}/api/resale-products", json=product_payload)
        assert product_response.status_code == 200, f"Failed to create product: {product_response.text}"
        product_id = product_response.json()["product_id"]
        
        # Create menu item with desired_margin = 0.60 (60%)
        payload = {
            "name": "TEST_MenuItem_SuggestedPrice",
            "category": "Outros",
            "item_type": "resale_product",
            "product_id": product_id,
            "desired_margin": 0.60,  # 60% margin
            "sale_price": 0  # No sale price set
        }
        response = api_client.post(f"{BASE_URL}/api/menu-items", json=payload)
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        
        # With cost = 10.00 and desired_margin = 0.60
        # suggested_price = 10.00 / (1 - 0.60) = 10.00 / 0.40 = 25.00
        expected_suggested = 10.00 / (1 - 0.60)
        
        assert "suggested_price" in data, "Missing suggested_price in response"
        assert abs(data["suggested_price"] - expected_suggested) < 0.5, f"Expected suggested_price ~{expected_suggested}, got {data['suggested_price']}"
        print(f"Suggested price: PASSED - cost: {data['cost']}, margin: 60%, suggested: {data['suggested_price']} (expected: {expected_suggested})")


class TestMenuItemCRUD:
    """Test Update and Delete operations for menu items"""
    
    def test_update_menu_item(self, api_client):
        """PUT /api/menu-items/{id} - Update menu item"""
        # First create a product for the menu item
        product_payload = {
            "name": "TEST_MENU_Update_Product",
            "category": "Outros",
            "purchase_cost": 5.00,
            "sale_price": 10.00,
            "stock_quantity": 20,
            "unit": "unidade"
        }
        product_response = api_client.post(f"{BASE_URL}/api/resale-products", json=product_payload)
        assert product_response.status_code == 200, f"Failed to create product: {product_response.text}"
        product_id = product_response.json()["product_id"]
        
        # Create menu item
        create_payload = {
            "name": "TEST_MenuItem_ToUpdate",
            "category": "Bebidas",
            "item_type": "resale_product",
            "product_id": product_id,
            "sale_price": 12.00
        }
        create_response = api_client.post(f"{BASE_URL}/api/menu-items", json=create_payload)
        assert create_response.status_code == 200, f"Failed to create menu item: {create_response.text}"
        menu_item_id = create_response.json()["menu_item_id"]
        
        # Update the menu item
        update_payload = {
            "name": "TEST_MenuItem_Updated",
            "sale_price": 15.00,
            "category": "Snacks"
        }
        update_response = api_client.put(f"{BASE_URL}/api/menu-items/{menu_item_id}", json=update_payload)
        assert update_response.status_code == 200, f"Update failed: {update_response.text}"
        
        # Verify update persistence
        get_response = api_client.get(f"{BASE_URL}/api/menu-items/{menu_item_id}")
        assert get_response.status_code == 200
        item = get_response.json()
        assert item["name"] == "TEST_MenuItem_Updated"
        assert item["sale_price"] == 15.00
        assert item["category"] == "Snacks"
        
        print(f"PUT /api/menu-items/{menu_item_id}: PASSED - name updated, price: {item['sale_price']}")
    
    def test_delete_menu_item(self, api_client):
        """DELETE /api/menu-items/{id} - Delete menu item"""
        # Create product first
        product_payload = {
            "name": "TEST_MENU_Delete_Product",
            "category": "Outros",
            "purchase_cost": 3.00,
            "sale_price": 6.00,
            "stock_quantity": 10,
            "unit": "unidade"
        }
        product_response = api_client.post(f"{BASE_URL}/api/resale-products", json=product_payload)
        assert product_response.status_code == 200, f"Failed to create product: {product_response.text}"
        product_id = product_response.json()["product_id"]
        
        # Create menu item
        create_payload = {
            "name": "TEST_MenuItem_ToDelete",
            "category": "Outros",
            "item_type": "resale_product",
            "product_id": product_id,
            "sale_price": 8.00
        }
        create_response = api_client.post(f"{BASE_URL}/api/menu-items", json=create_payload)
        assert create_response.status_code == 200, f"Failed to create menu item: {create_response.text}"
        menu_item_id = create_response.json()["menu_item_id"]
        
        # Delete the menu item
        delete_response = api_client.delete(f"{BASE_URL}/api/menu-items/{menu_item_id}")
        assert delete_response.status_code == 200, f"Delete failed: {delete_response.text}"
        
        # Verify deletion
        get_response = api_client.get(f"{BASE_URL}/api/menu-items/{menu_item_id}")
        assert get_response.status_code == 404
        
        print(f"DELETE /api/menu-items/{menu_item_id}: PASSED - item no longer exists")


class TestMenuWithCalculatedFields:
    """GET /api/menu - Returns all menu items with calculated cost, margin, profit_per_unit"""
    
    def test_menu_returns_calculated_fields(self, api_client):
        """Verify GET /api/menu returns items with profit intelligence"""
        response = api_client.get(f"{BASE_URL}/api/menu")
        assert response.status_code == 200, f"Failed: {response.text}"
        data = response.json()
        
        if len(data) == 0:
            print("GET /api/menu: PASSED (no items to check)")
            return
        
        # Check all items have required fields
        for item in data:
            assert "cost" in item, f"Missing cost in item: {item.get('name')}"
            assert "sale_price" in item, f"Missing sale_price in item: {item.get('name')}"
            assert "margin" in item, f"Missing margin in item: {item.get('name')}"
            assert "profit_per_unit" in item or "profit" in item, f"Missing profit field in item: {item.get('name')}"
            assert "item_type" in item, f"Missing item_type in item: {item.get('name')}"
        
        # Check for custom (menu_items collection) items
        custom_items = [i for i in data if i.get("is_custom")]
        legacy_items = [i for i in data if not i.get("is_custom")]
        
        print(f"GET /api/menu: PASSED - {len(data)} total items ({len(custom_items)} custom, {len(legacy_items)} legacy)")
        
        # Verify a few items have valid calculations
        for item in data[:3]:
            if item["sale_price"] > 0:
                expected_profit = item["sale_price"] - item["cost"]
                actual_profit = item.get("profit_per_unit", item.get("profit", 0))
                # Allow for rounding
                assert abs(actual_profit - expected_profit) < 0.5, f"Profit mismatch for {item['name']}: expected {expected_profit}, got {actual_profit}"
            print(f"  - {item['name']}: cost={item['cost']}, price={item['sale_price']}, margin={item['margin']}%")


class TestMenuItemValidation:
    """Test validation for menu item creation"""
    
    def test_invalid_item_type(self, api_client):
        """Should reject invalid item_type"""
        payload = {
            "name": "TEST_MenuItem_InvalidType",
            "item_type": "invalid_type",
            "sale_price": 10.00
        }
        response = api_client.post(f"{BASE_URL}/api/menu-items", json=payload)
        assert response.status_code == 400, f"Expected 400, got {response.status_code}: {response.text}"
        print("Validation (invalid item_type): PASSED - rejected")
    
    def test_missing_recipe_id_for_recipe_type(self, api_client):
        """Recipe type without recipe_id should work but have zero cost"""
        payload = {
            "name": "TEST_MenuItem_NoRecipeId",
            "item_type": "recipe",
            # No recipe_id provided
            "sale_price": 20.00
        }
        response = api_client.post(f"{BASE_URL}/api/menu-items", json=payload)
        # Should succeed but cost will be 0
        if response.status_code == 200:
            data = response.json()
            assert data["cost"] == 0
            print("Validation (no recipe_id): PASSED - created with zero cost")


class TestCleanupMenuItems:
    """Clean up test data"""
    
    def test_cleanup_test_menu_items(self, api_client):
        """Clean up TEST_ prefixed menu items"""
        # Get all menu items
        menu = api_client.get(f"{BASE_URL}/api/menu").json()
        deleted_menu_items = 0
        for item in menu:
            if isinstance(item, dict) and item.get("name", "").startswith("TEST_") and item.get("menu_item_id"):
                api_client.delete(f"{BASE_URL}/api/menu-items/{item['menu_item_id']}")
                deleted_menu_items += 1
        
        # Clean resale products
        products = api_client.get(f"{BASE_URL}/api/resale-products").json()
        deleted_products = 0
        for p in products:
            if isinstance(p, dict) and p.get("name", "").startswith("TEST_MENU"):
                api_client.delete(f"{BASE_URL}/api/resale-products/{p['product_id']}")
                deleted_products += 1
        
        # Clean recipes
        recipes = api_client.get(f"{BASE_URL}/api/recipes").json()
        deleted_recipes = 0
        for r in recipes:
            if isinstance(r, dict) and r.get("name", "").startswith("TEST_MENU"):
                api_client.delete(f"{BASE_URL}/api/recipes/{r['recipe_id']}")
                deleted_recipes += 1
        
        # Clean ingredients
        ingredients = api_client.get(f"{BASE_URL}/api/ingredients").json()
        deleted_ingredients = 0
        for i in ingredients:
            if isinstance(i, dict) and i.get("name", "").startswith("TEST_MENU"):
                api_client.delete(f"{BASE_URL}/api/ingredients/{i['ingredient_id']}")
                deleted_ingredients += 1
        
        print(f"Cleanup: PASSED (deleted {deleted_menu_items} menu items, {deleted_products} products, {deleted_recipes} recipes, {deleted_ingredients} ingredients)")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
