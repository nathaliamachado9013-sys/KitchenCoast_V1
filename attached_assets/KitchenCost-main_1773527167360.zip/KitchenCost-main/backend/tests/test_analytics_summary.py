"""
Analytics Summary Layer Tests for KitchenCost
Tests the new summary collections and incremental update functionality:
- daily_sales_summary
- monthly_menu_profit_summary
- dashboard_metrics_cache
- inventory_value_snapshots
"""

import pytest
import requests
import os
from datetime import datetime, timedelta

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')


class TestAnalyticsSetup:
    """Setup test data - create restaurant, ingredients, recipes, resale products"""
    
    @pytest.fixture(scope="class")
    def session_token(self):
        """Get session token from MongoDB test user"""
        import subprocess
        result = subprocess.run([
            "mongosh", "--eval", """
use('test_database');
var session = db.user_sessions.findOne({session_token: {$regex: /test_analytics_session/}});
if (session) { print('TOKEN=' + session.session_token); }
else { print('TOKEN=NOT_FOUND'); }
"""
        ], capture_output=True, text=True)
        for line in result.stdout.split('\n'):
            if line.startswith('TOKEN='):
                token = line.split('=')[1]
                if token != 'NOT_FOUND':
                    return token
        pytest.skip("No test session found")
    
    @pytest.fixture(scope="class")
    def api_client(self, session_token):
        """Create API client with auth header"""
        session = requests.Session()
        session.headers.update({
            "Content-Type": "application/json",
            "Authorization": f"Bearer {session_token}"
        })
        return session
    
    @pytest.fixture(scope="class")
    def restaurant(self, api_client):
        """Create or get restaurant for testing"""
        # Try to get existing restaurant
        response = api_client.get(f"{BASE_URL}/api/restaurants/me")
        if response.status_code == 200 and response.json():
            return response.json()
        
        # Create new restaurant
        response = api_client.post(f"{BASE_URL}/api/restaurants", json={
            "name": "TEST_Analytics_Restaurant",
            "currency": "EUR"
        })
        assert response.status_code == 200, f"Failed to create restaurant: {response.text}"
        
        # Get the restaurant details
        response = api_client.get(f"{BASE_URL}/api/restaurants/me")
        assert response.status_code == 200
        return response.json()


class TestAnalyticsAPIs(TestAnalyticsSetup):
    """Test Analytics API endpoints"""
    
    def test_01_dashboard_analytics_empty(self, api_client, restaurant):
        """GET /api/analytics/dashboard - Returns cached metrics (may be empty initially)"""
        response = api_client.get(f"{BASE_URL}/api/analytics/dashboard")
        assert response.status_code == 200, f"Dashboard analytics failed: {response.text}"
        
        data = response.json()
        # Check response structure
        assert "date" in data, "Response should have 'date' field"
        assert "total_revenue" in data, "Response should have 'total_revenue' field"
        assert "total_profit" in data, "Response should have 'total_profit' field"
        assert "total_units_sold" in data, "Response should have 'total_units_sold' field"
        assert "total_production_cost" in data, "Response should have 'total_production_cost' field"
        assert "inventory_value" in data, "Response should have 'inventory_value' field"
        assert "low_stock_count" in data, "Response should have 'low_stock_count' field"
        print(f"Dashboard analytics returned: {data}")
    
    def test_02_dashboard_analytics_with_date(self, api_client, restaurant):
        """GET /api/analytics/dashboard with specific date"""
        today = datetime.now().strftime("%Y-%m-%d")
        response = api_client.get(f"{BASE_URL}/api/analytics/dashboard", params={"date": today})
        assert response.status_code == 200, f"Dashboard analytics with date failed: {response.text}"
        
        data = response.json()
        assert data.get("date") == today, f"Expected date {today}, got {data.get('date')}"
        print(f"Dashboard analytics for {today}: {data}")
    
    def test_03_daily_sales_empty(self, api_client, restaurant):
        """GET /api/analytics/daily-sales - Returns daily sales summaries"""
        response = api_client.get(f"{BASE_URL}/api/analytics/daily-sales")
        assert response.status_code == 200, f"Daily sales analytics failed: {response.text}"
        
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        print(f"Daily sales summaries count: {len(data)}")
    
    def test_04_daily_sales_with_date_range(self, api_client, restaurant):
        """GET /api/analytics/daily-sales with date filters"""
        today = datetime.now().strftime("%Y-%m-%d")
        week_ago = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
        
        response = api_client.get(f"{BASE_URL}/api/analytics/daily-sales", params={
            "start_date": week_ago,
            "end_date": today
        })
        assert response.status_code == 200, f"Daily sales with date range failed: {response.text}"
        
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        print(f"Daily sales in range {week_ago} to {today}: {len(data)} records")
    
    def test_05_monthly_profit_summary(self, api_client, restaurant):
        """GET /api/analytics/monthly-profit - Returns monthly profit with classifications"""
        response = api_client.get(f"{BASE_URL}/api/analytics/monthly-profit")
        assert response.status_code == 200, f"Monthly profit analytics failed: {response.text}"
        
        data = response.json()
        # Check response structure
        assert "year" in data, "Response should have 'year' field"
        assert "month" in data, "Response should have 'month' field"
        assert "items" in data, "Response should have 'items' field"
        assert "summary" in data, "Response should have 'summary' field"
        assert "classification_counts" in data, "Response should have 'classification_counts' field"
        
        # Check classification counts structure
        cls_counts = data.get("classification_counts", {})
        expected_classifications = ["STAR", "PLOWHORSE", "PUZZLE", "DOG", "UNCLASSIFIED"]
        for cls in expected_classifications:
            assert cls in cls_counts, f"Missing classification: {cls}"
        
        print(f"Monthly profit for {data['year']}/{data['month']}: {len(data['items'])} items")
        print(f"Classification counts: {cls_counts}")
    
    def test_06_monthly_profit_with_params(self, api_client, restaurant):
        """GET /api/analytics/monthly-profit with year/month parameters"""
        now = datetime.now()
        response = api_client.get(f"{BASE_URL}/api/analytics/monthly-profit", params={
            "year": now.year,
            "month": now.month
        })
        assert response.status_code == 200, f"Monthly profit with params failed: {response.text}"
        
        data = response.json()
        assert data.get("year") == now.year, f"Expected year {now.year}"
        assert data.get("month") == now.month, f"Expected month {now.month}"
        print(f"Monthly profit summary: {data.get('summary', {})}")
    
    def test_07_inventory_snapshots(self, api_client, restaurant):
        """GET /api/analytics/inventory-snapshots - Returns inventory value snapshots"""
        response = api_client.get(f"{BASE_URL}/api/analytics/inventory-snapshots")
        assert response.status_code == 200, f"Inventory snapshots failed: {response.text}"
        
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        print(f"Inventory snapshots count: {len(data)}")
    
    def test_08_inventory_snapshots_with_days(self, api_client, restaurant):
        """GET /api/analytics/inventory-snapshots with days parameter"""
        response = api_client.get(f"{BASE_URL}/api/analytics/inventory-snapshots", params={"days": 7})
        assert response.status_code == 200, f"Inventory snapshots with days failed: {response.text}"
        
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        print(f"Inventory snapshots (7 days): {len(data)} records")


class TestBackfillEndpoint(TestAnalyticsSetup):
    """Test the backfill endpoint"""
    
    def test_09_backfill_analytics(self, api_client, restaurant):
        """POST /api/analytics/backfill - Processes existing data into summaries"""
        response = api_client.post(f"{BASE_URL}/api/analytics/backfill")
        assert response.status_code == 200, f"Backfill failed: {response.text}"
        
        data = response.json()
        assert "message" in data, "Response should have 'message' field"
        assert "daily_sales_records" in data, "Response should have 'daily_sales_records'"
        assert "monthly_profit_records" in data, "Response should have 'monthly_profit_records'"
        assert "dashboard_cache_records" in data, "Response should have 'dashboard_cache_records'"
        
        print(f"Backfill result: {data}")


class TestIncrementalUpdates(TestAnalyticsSetup):
    """Test incremental updates when sales/production are created"""
    
    @pytest.fixture(scope="class")
    def test_ingredient(self, api_client, restaurant):
        """Create test ingredient for testing"""
        response = api_client.post(f"{BASE_URL}/api/ingredients", json={
            "name": "TEST_Analytics_Ingredient",
            "unit": "kg",
            "cost_per_unit": 10.0,
            "current_stock": 100.0,
            "min_stock": 10.0
        })
        if response.status_code == 200:
            return response.json()
        # If already exists, try to find it
        response = api_client.get(f"{BASE_URL}/api/ingredients")
        if response.status_code == 200:
            for ing in response.json():
                if ing.get("name") == "TEST_Analytics_Ingredient":
                    return ing
        pytest.skip("Could not create or find test ingredient")
    
    @pytest.fixture(scope="class")
    def test_recipe(self, api_client, restaurant, test_ingredient):
        """Create test recipe for testing"""
        response = api_client.post(f"{BASE_URL}/api/recipes", json={
            "name": "TEST_Analytics_Recipe",
            "category": "Prato Principal",
            "yield_quantity": 1.0,
            "ingredients": [{
                "ingredient_id": test_ingredient.get("ingredient_id"),
                "quantity": 0.5
            }],
            "selling_price": 50.0
        })
        if response.status_code == 200:
            return response.json()
        # If already exists, try to find it
        response = api_client.get(f"{BASE_URL}/api/recipes")
        if response.status_code == 200:
            for rec in response.json():
                if rec.get("name") == "TEST_Analytics_Recipe":
                    return rec
        pytest.skip("Could not create or find test recipe")
    
    def test_10_create_sale_updates_summaries(self, api_client, restaurant, test_recipe):
        """When a sale is created, analytics summaries should be updated"""
        # Get current dashboard metrics
        today = datetime.now().strftime("%Y-%m-%d")
        before_response = api_client.get(f"{BASE_URL}/api/analytics/dashboard", params={"date": today})
        before_data = before_response.json() if before_response.status_code == 200 else {}
        before_revenue = before_data.get("total_revenue", 0)
        before_units = before_data.get("total_units_sold", 0)
        
        # Create a sale
        sale_response = api_client.post(f"{BASE_URL}/api/sales", json={
            "item_type": "recipe_item",
            "item_id": test_recipe.get("recipe_id"),
            "quantity_sold": 2,
            "sale_price": 50.0
        })
        assert sale_response.status_code == 200, f"Sale creation failed: {sale_response.text}"
        sale_data = sale_response.json()
        print(f"Sale created: {sale_data}")
        
        # Check dashboard metrics were updated
        after_response = api_client.get(f"{BASE_URL}/api/analytics/dashboard", params={"date": today})
        assert after_response.status_code == 200
        after_data = after_response.json()
        
        # Verify incremental update
        expected_revenue_increase = 100.0  # 2 * 50
        assert after_data.get("total_revenue", 0) >= before_revenue + expected_revenue_increase - 1, \
            f"Revenue not updated correctly. Before: {before_revenue}, After: {after_data.get('total_revenue')}"
        assert after_data.get("total_units_sold", 0) >= before_units + 2 - 1, \
            f"Units sold not updated. Before: {before_units}, After: {after_data.get('total_units_sold')}"
        
        print(f"Dashboard updated - Revenue: {before_revenue} -> {after_data.get('total_revenue')}")
        print(f"Dashboard updated - Units: {before_units} -> {after_data.get('total_units_sold')}")
    
    def test_11_sale_updates_daily_summary(self, api_client, restaurant, test_recipe):
        """Sale should update daily_sales_summary"""
        today = datetime.now().strftime("%Y-%m-%d")
        
        response = api_client.get(f"{BASE_URL}/api/analytics/daily-sales", params={
            "start_date": today,
            "end_date": today
        })
        assert response.status_code == 200
        
        data = response.json()
        # Check if there's a summary for our test item
        test_summaries = [s for s in data if s.get("menu_item_id") == test_recipe.get("recipe_id")]
        if test_summaries:
            summary = test_summaries[0]
            assert summary.get("units_sold", 0) > 0, "Units sold should be > 0"
            assert summary.get("revenue_total", 0) > 0, "Revenue should be > 0"
            print(f"Daily sales summary for test item: {summary}")
        else:
            print("No daily sales summary found for test item yet")
    
    def test_12_sale_updates_monthly_summary(self, api_client, restaurant, test_recipe):
        """Sale should update monthly_menu_profit_summary"""
        now = datetime.now()
        
        response = api_client.get(f"{BASE_URL}/api/analytics/monthly-profit", params={
            "year": now.year,
            "month": now.month
        })
        assert response.status_code == 200
        
        data = response.json()
        items = data.get("items", [])
        test_items = [i for i in items if i.get("menu_item_id") == test_recipe.get("recipe_id")]
        
        if test_items:
            item = test_items[0]
            assert item.get("units_sold", 0) > 0, "Units sold should be > 0"
            assert item.get("revenue_total", 0) > 0, "Revenue should be > 0"
            assert "classification" in item, "Should have classification"
            print(f"Monthly profit summary for test item: {item}")
        else:
            print("No monthly profit summary found for test item yet")
    
    def test_13_production_updates_dashboard(self, api_client, restaurant, test_recipe):
        """When production is created, dashboard_metrics_cache production_cost should be updated"""
        today = datetime.now().strftime("%Y-%m-%d")
        
        # Get current production cost
        before_response = api_client.get(f"{BASE_URL}/api/analytics/dashboard", params={"date": today})
        before_data = before_response.json() if before_response.status_code == 200 else {}
        before_cost = before_data.get("total_production_cost", 0)
        
        # Create production
        prod_response = api_client.post(f"{BASE_URL}/api/productions", json={
            "recipe_id": test_recipe.get("recipe_id"),
            "quantity": 2
        })
        
        if prod_response.status_code != 200:
            # Production may fail due to insufficient stock - that's ok for this test
            print(f"Production creation response: {prod_response.status_code} - {prod_response.text}")
            pytest.skip("Could not create production (may be insufficient stock)")
        
        prod_data = prod_response.json()
        production_cost = prod_data.get("total_cost", 0)
        print(f"Production created with cost: {production_cost}")
        
        # Check dashboard updated
        after_response = api_client.get(f"{BASE_URL}/api/analytics/dashboard", params={"date": today})
        assert after_response.status_code == 200
        after_data = after_response.json()
        
        # Verify production cost increased
        after_cost = after_data.get("total_production_cost", 0)
        assert after_cost >= before_cost, \
            f"Production cost should increase. Before: {before_cost}, After: {after_cost}"
        
        print(f"Dashboard production cost updated: {before_cost} -> {after_cost}")
    
    def test_14_inventory_snapshot_updated(self, api_client, restaurant):
        """Inventory snapshot should be updated after operations"""
        response = api_client.get(f"{BASE_URL}/api/analytics/inventory-snapshots", params={"days": 1})
        assert response.status_code == 200
        
        data = response.json()
        # Should have at least one snapshot from today's operations
        today = datetime.now().strftime("%Y-%m-%d")
        today_snapshots = [s for s in data if s.get("date") == today]
        
        if today_snapshots:
            snapshot = today_snapshots[0]
            assert "inventory_value" in snapshot, "Should have inventory_value"
            assert "ingredients_count" in snapshot, "Should have ingredients_count"
            print(f"Today's inventory snapshot: {snapshot}")
        else:
            print("No inventory snapshot for today yet")


class TestMongoDBIndexes(TestAnalyticsSetup):
    """Test that MongoDB indexes are created for analytics collections"""
    
    def test_15_verify_indexes_exist(self, api_client):
        """Verify MongoDB indexes are created for summary collections"""
        import subprocess
        
        # Check indexes on daily_sales_summary
        result = subprocess.run([
            "mongosh", "--eval", """
use('test_database');
print('DAILY_SALES_INDEXES:');
printjson(db.daily_sales_summary.getIndexes());
print('MONTHLY_PROFIT_INDEXES:');
printjson(db.monthly_menu_profit_summary.getIndexes());
print('DASHBOARD_CACHE_INDEXES:');
printjson(db.dashboard_metrics_cache.getIndexes());
print('INVENTORY_SNAPSHOTS_INDEXES:');
printjson(db.inventory_value_snapshots.getIndexes());
"""
        ], capture_output=True, text=True)
        
        output = result.stdout
        print(f"Index verification output:\n{output}")
        
        # Check for expected indexes
        assert "daily_sales_summary" in output or "DAILY_SALES_INDEXES" in output, "Should show daily_sales indexes"
        print("Index verification completed")


class TestCleanup:
    """Cleanup test data"""
    
    def test_99_cleanup_test_data(self):
        """Clean up test data created during tests"""
        import subprocess
        result = subprocess.run([
            "mongosh", "--eval", """
use('test_database');
// Clean up test data
db.ingredients.deleteMany({name: {$regex: /^TEST_/}});
db.recipes.deleteMany({name: {$regex: /^TEST_/}});
db.sales.deleteMany({item_name: {$regex: /^TEST_/}});
db.productions.deleteMany({recipe_name: {$regex: /^TEST_/}});
db.restaurants.deleteMany({name: {$regex: /^TEST_/}});
print('Cleanup completed');
"""
        ], capture_output=True, text=True)
        print(result.stdout)


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
