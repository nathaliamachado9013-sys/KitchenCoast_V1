"""
Test Menu Categories CRUD endpoints for KitchenCost SaaS

Tests:
- GET /api/menu/categories - Active categories only (names only)
- GET /api/menu/categories/all - All categories with full objects
- POST /api/menu/categories - Create new category
- PUT /api/menu/categories/{id} - Update category (name, is_active)
- DELETE /api/menu/categories/{id} - Delete or deactivate category
"""

import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

# Session token will be set by fixture
SESSION_TOKEN = None

@pytest.fixture(scope="module")
def api_client():
    """Shared requests session"""
    session = requests.Session()
    session.headers.update({"Content-Type": "application/json"})
    return session

@pytest.fixture(scope="module")
def session_token(api_client):
    """Get or create test session for category testing"""
    global SESSION_TOKEN
    # Use the session token created earlier
    import subprocess
    result = subprocess.run(
        ["mongosh", "--quiet", "--eval", '''
use('test_database');
var session = db.user_sessions.findOne({session_token: /test_session_cat_/}, {_id: 0});
if (session) {
    print('TOKEN=' + session.session_token);
} else {
    print('TOKEN=none');
}
'''],
        capture_output=True,
        text=True
    )
    for line in result.stdout.strip().split('\n'):
        if line.startswith('TOKEN='):
            token = line.split('=')[1]
            if token != 'none':
                SESSION_TOKEN = token
                return token
    
    # Create new session if none exists
    result = subprocess.run(
        ["mongosh", "--quiet", "--eval", '''
use('test_database');
var userId = 'test-user-cat-' + Date.now();
var sessionToken = 'test_session_cat_' + Date.now();
var restId = 'rest_cat_' + Date.now();

db.users.insertOne({
  user_id: userId,
  email: 'test.cat.' + Date.now() + '@example.com',
  name: 'Category Test User',
  created_at: new Date()
});
db.user_sessions.insertOne({
  user_id: userId,
  session_token: sessionToken,
  expires_at: new Date(Date.now() + 7*24*60*60*1000),
  created_at: new Date()
});
db.restaurants.insertOne({
  restaurant_id: restId,
  user_id: userId,
  name: 'Category Test Restaurant',
  currency: 'BRL',
  created_at: new Date()
});
print('TOKEN=' + sessionToken);
'''],
        capture_output=True,
        text=True
    )
    for line in result.stdout.strip().split('\n'):
        if line.startswith('TOKEN='):
            SESSION_TOKEN = line.split('=')[1]
            return SESSION_TOKEN
    pytest.skip("Could not create test session")

@pytest.fixture
def authenticated_client(api_client, session_token):
    """Session with auth header"""
    api_client.headers.update({"Authorization": f"Bearer {session_token}"})
    return api_client


class TestMenuCategoriesEndpoints:
    """Test Menu Categories CRUD operations"""
    
    def test_get_active_categories_returns_names_only(self, authenticated_client):
        """GET /api/menu/categories - Should return only active category names"""
        response = authenticated_client.get(f"{BASE_URL}/api/menu/categories")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        # Should be a list of strings (category names)
        assert isinstance(data, list), "Response should be a list"
        
        # Default categories should be created
        if len(data) > 0:
            assert isinstance(data[0], str), "Each item should be a string (category name)"
            # Check some default categories exist
            expected_defaults = ['Entradas', 'Pratos Principais', 'Sobremesas', 'Bebidas']
            for cat in expected_defaults:
                assert cat in data, f"Default category '{cat}' should exist"
        
        print(f"✓ GET /api/menu/categories returned {len(data)} active categories")
    
    def test_get_all_categories_returns_full_objects(self, authenticated_client):
        """GET /api/menu/categories/all - Should return all categories with full details"""
        response = authenticated_client.get(f"{BASE_URL}/api/menu/categories/all")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        
        if len(data) > 0:
            category = data[0]
            # Should have full object structure
            assert "category_id" in category, "Category should have category_id"
            assert "name" in category, "Category should have name"
            assert "is_active" in category, "Category should have is_active"
            assert "display_order" in category, "Category should have display_order"
            assert "restaurant_id" in category, "Category should have restaurant_id"
            
            # is_active should be boolean
            assert isinstance(category["is_active"], bool), "is_active should be boolean"
        
        print(f"✓ GET /api/menu/categories/all returned {len(data)} categories with full objects")
    
    def test_create_category(self, authenticated_client):
        """POST /api/menu/categories - Should create a new category"""
        # Create a unique category name
        import time
        cat_name = f"TEST_Category_{int(time.time())}"
        
        response = authenticated_client.post(
            f"{BASE_URL}/api/menu/categories",
            json={"name": cat_name}
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        assert "category_id" in data, "Response should contain category_id"
        assert "message" in data, "Response should contain message"
        
        # Verify it appears in the list
        list_response = authenticated_client.get(f"{BASE_URL}/api/menu/categories")
        assert cat_name in list_response.json(), f"New category '{cat_name}' should appear in active list"
        
        print(f"✓ POST /api/menu/categories created category '{cat_name}'")
        return data["category_id"]
    
    def test_create_duplicate_category_fails(self, authenticated_client):
        """POST /api/menu/categories - Should reject duplicate names"""
        # Try to create a category that already exists (default)
        response = authenticated_client.post(
            f"{BASE_URL}/api/menu/categories",
            json={"name": "Bebidas"}
        )
        assert response.status_code == 400, f"Expected 400 for duplicate, got {response.status_code}"
        
        data = response.json()
        assert "detail" in data, "Should return error detail"
        
        print("✓ Duplicate category creation correctly rejected")
    
    def test_update_category_name(self, authenticated_client):
        """PUT /api/menu/categories/{id} - Should update category name"""
        # First create a category to update
        import time
        original_name = f"TEST_Update_{int(time.time())}"
        create_response = authenticated_client.post(
            f"{BASE_URL}/api/menu/categories",
            json={"name": original_name}
        )
        assert create_response.status_code == 200
        category_id = create_response.json()["category_id"]
        
        # Update the name
        new_name = f"TEST_Updated_{int(time.time())}"
        update_response = authenticated_client.put(
            f"{BASE_URL}/api/menu/categories/{category_id}",
            json={"name": new_name}
        )
        assert update_response.status_code == 200, f"Expected 200, got {update_response.status_code}: {update_response.text}"
        
        # Verify the update
        list_response = authenticated_client.get(f"{BASE_URL}/api/menu/categories/all")
        categories = list_response.json()
        updated_cat = next((c for c in categories if c["category_id"] == category_id), None)
        assert updated_cat is not None, "Updated category should exist"
        assert updated_cat["name"] == new_name, f"Name should be '{new_name}', got '{updated_cat['name']}'"
        
        print(f"✓ PUT /api/menu/categories/{category_id} updated name to '{new_name}'")
    
    def test_toggle_category_active_status(self, authenticated_client):
        """PUT /api/menu/categories/{id} - Should toggle is_active"""
        # First create a category
        import time
        cat_name = f"TEST_Toggle_{int(time.time())}"
        create_response = authenticated_client.post(
            f"{BASE_URL}/api/menu/categories",
            json={"name": cat_name}
        )
        assert create_response.status_code == 200
        category_id = create_response.json()["category_id"]
        
        # Verify it's active by default
        list_response = authenticated_client.get(f"{BASE_URL}/api/menu/categories")
        assert cat_name in list_response.json(), "New category should be active"
        
        # Deactivate it
        deactivate_response = authenticated_client.put(
            f"{BASE_URL}/api/menu/categories/{category_id}",
            json={"is_active": False}
        )
        assert deactivate_response.status_code == 200
        
        # Verify it's not in active list
        list_response = authenticated_client.get(f"{BASE_URL}/api/menu/categories")
        assert cat_name not in list_response.json(), "Deactivated category should not be in active list"
        
        # But should be in all categories list
        all_response = authenticated_client.get(f"{BASE_URL}/api/menu/categories/all")
        all_cats = all_response.json()
        deactivated_cat = next((c for c in all_cats if c["category_id"] == category_id), None)
        assert deactivated_cat is not None, "Category should still exist"
        assert deactivated_cat["is_active"] == False, "Category should be inactive"
        
        # Re-activate it
        reactivate_response = authenticated_client.put(
            f"{BASE_URL}/api/menu/categories/{category_id}",
            json={"is_active": True}
        )
        assert reactivate_response.status_code == 200
        
        # Verify it's active again
        list_response = authenticated_client.get(f"{BASE_URL}/api/menu/categories")
        assert cat_name in list_response.json(), "Reactivated category should be in active list"
        
        print(f"✓ Toggle is_active works correctly for category '{cat_name}'")
    
    def test_delete_unused_category(self, authenticated_client):
        """DELETE /api/menu/categories/{id} - Should delete unused category"""
        # Create a category to delete
        import time
        cat_name = f"TEST_Delete_{int(time.time())}"
        create_response = authenticated_client.post(
            f"{BASE_URL}/api/menu/categories",
            json={"name": cat_name}
        )
        assert create_response.status_code == 200
        category_id = create_response.json()["category_id"]
        
        # Delete it
        delete_response = authenticated_client.delete(
            f"{BASE_URL}/api/menu/categories/{category_id}"
        )
        assert delete_response.status_code == 200, f"Expected 200, got {delete_response.status_code}: {delete_response.text}"
        
        # Verify it's gone
        all_response = authenticated_client.get(f"{BASE_URL}/api/menu/categories/all")
        all_cats = all_response.json()
        deleted_cat = next((c for c in all_cats if c["category_id"] == category_id), None)
        assert deleted_cat is None, "Deleted category should not exist"
        
        print(f"✓ DELETE /api/menu/categories/{category_id} successfully deleted category")
    
    def test_delete_category_not_found(self, authenticated_client):
        """DELETE /api/menu/categories/{id} - Should return 404 for non-existent"""
        response = authenticated_client.delete(
            f"{BASE_URL}/api/menu/categories/nonexistent_cat_id_12345"
        )
        assert response.status_code == 404, f"Expected 404, got {response.status_code}"
        
        print("✓ DELETE non-existent category returns 404")
    
    def test_default_categories_created_automatically(self, authenticated_client):
        """Verify default categories are created for new tenants"""
        # The GET request should auto-create defaults if none exist
        response = authenticated_client.get(f"{BASE_URL}/api/menu/categories")
        assert response.status_code == 200
        
        data = response.json()
        # Check default categories exist
        expected_defaults = [
            'Entradas', 'Pratos Principais', 'Acompanhamentos', 
            'Sobremesas', 'Bebidas', 'Snacks', 'Pizzas', 'Outros'
        ]
        
        for default_cat in expected_defaults:
            assert default_cat in data, f"Default category '{default_cat}' should exist"
        
        print(f"✓ All {len(expected_defaults)} default categories exist")
    
    def test_categories_ordered_by_display_order(self, authenticated_client):
        """Verify categories are returned sorted by display_order"""
        response = authenticated_client.get(f"{BASE_URL}/api/menu/categories/all")
        assert response.status_code == 200
        
        data = response.json()
        if len(data) > 1:
            # Check display_order is ascending
            for i in range(1, len(data)):
                assert data[i]["display_order"] >= data[i-1]["display_order"], \
                    "Categories should be sorted by display_order"
        
        print("✓ Categories are correctly sorted by display_order")


class TestMenuCategoriesIntegration:
    """Test menu categories integration with other modules"""
    
    def test_active_categories_used_in_menu_filter(self, authenticated_client):
        """Categories from GET /api/menu/categories should work for menu filtering"""
        # Get active categories
        cat_response = authenticated_client.get(f"{BASE_URL}/api/menu/categories")
        assert cat_response.status_code == 200
        categories = cat_response.json()
        
        # Each category should be a valid filter value
        assert len(categories) > 0, "Should have at least one category"
        assert all(isinstance(c, str) for c in categories), "All categories should be strings"
        
        print(f"✓ {len(categories)} categories available for menu filtering")


# Cleanup fixture
@pytest.fixture(scope="module", autouse=True)
def cleanup_test_categories():
    """Cleanup TEST_ prefixed categories after tests"""
    yield
    import subprocess
    subprocess.run(
        ["mongosh", "--quiet", "--eval", '''
use('test_database');
var deleted = db.menu_categories.deleteMany({name: /^TEST_/});
print('Cleaned up ' + deleted.deletedCount + ' test categories');
'''],
        capture_output=True,
        text=True
    )
