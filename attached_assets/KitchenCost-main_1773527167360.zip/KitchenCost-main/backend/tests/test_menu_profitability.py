"""
Test Menu Profitability API - Menu Engineering Classification Tests

Tests for GET /api/menu/profitability endpoint and related features:
- Profitability metrics (profit_per_unit, margin, units_sold_period, total_profit_period)
- Menu Engineering classification (STAR, PLOWHORSE, PUZZLE, DOG)
- Period filtering (today, week, month, year)
- Top profitable items
"""

import pytest
import requests
import os
from datetime import datetime, timedelta

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL').rstrip('/')
SESSION_TOKEN = "test_session_profit_1773419526584"

# Headers with auth
HEADERS = {
    "Authorization": f"Bearer {SESSION_TOKEN}",
    "Content-Type": "application/json"
}


class TestMenuProfitabilityEndpoint:
    """Tests for GET /api/menu/profitability endpoint"""
    
    def test_profitability_endpoint_exists(self):
        """Test that profitability endpoint returns 200"""
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "month"}
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        print("✓ Profitability endpoint returns 200")
        
    def test_profitability_response_structure(self):
        """Test profitability response has required fields: items, summary, classification_counts, top_profitable"""
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "month"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Check top-level fields
        assert "items" in data, "Missing 'items' array"
        assert "summary" in data, "Missing 'summary' object"
        assert "classification_counts" in data, "Missing 'classification_counts'"
        assert "top_profitable" in data, "Missing 'top_profitable' array"
        assert "period" in data, "Missing 'period' field"
        
        # Check summary structure
        summary = data["summary"]
        assert "total_profit_period" in summary, "Missing total_profit_period in summary"
        assert "total_items_sold" in summary, "Missing total_items_sold in summary"
        assert "total_items" in summary, "Missing total_items in summary"
        assert "avg_profit_per_unit" in summary, "Missing avg_profit_per_unit in summary"
        
        # Check classification_counts structure
        counts = data["classification_counts"]
        for cls in ["STAR", "PLOWHORSE", "PUZZLE", "DOG", "UNCLASSIFIED"]:
            assert cls in counts, f"Missing classification: {cls}"
            
        print(f"✓ Response structure valid - {len(data['items'])} items, classifications: {counts}")
        
    def test_profitability_item_fields(self):
        """Test each item has profit metrics and classification"""
        # First create some test data
        # Create ingredient
        ing_response = requests.post(
            f"{BASE_URL}/api/ingredients",
            headers=HEADERS,
            json={"name": "Test Ing Profit", "unit": "g", "cost_per_unit": 0.01}
        )
        assert ing_response.status_code == 200
        ing_id = ing_response.json()["ingredient_id"]
        
        # Create recipe with selling price
        recipe_response = requests.post(
            f"{BASE_URL}/api/recipes",
            headers=HEADERS,
            json={
                "name": "Test Recipe Profit",
                "category": "Prato Principal",
                "ingredients": [{"ingredient_id": ing_id, "quantity": 100}],
                "selling_price": 25.00
            }
        )
        assert recipe_response.status_code == 200
        recipe_id = recipe_response.json()["recipe_id"]
        
        # Get profitability
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "month"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Find our test recipe
        test_item = None
        for item in data["items"]:
            if item.get("name") == "Test Recipe Profit":
                test_item = item
                break
        
        assert test_item is not None, "Test recipe not found in profitability data"
        
        # Check required fields on item
        required_fields = [
            "profit_per_unit", "margin", "units_sold_period", 
            "total_profit_period", "classification", "cost", "sale_price"
        ]
        for field in required_fields:
            assert field in test_item, f"Missing field: {field}"
        
        # Verify profit calculation
        expected_profit = test_item["sale_price"] - test_item["cost"]
        assert abs(test_item["profit_per_unit"] - expected_profit) < 0.1, "Profit calculation incorrect"
        
        # Verify classification is valid
        valid_classifications = ["STAR", "PLOWHORSE", "PUZZLE", "DOG", "UNCLASSIFIED"]
        assert test_item["classification"] in valid_classifications, f"Invalid classification: {test_item['classification']}"
        
        print(f"✓ Item fields valid - profit_per_unit: {test_item['profit_per_unit']}, classification: {test_item['classification']}")
        
        # Cleanup
        requests.delete(f"{BASE_URL}/api/recipes/{recipe_id}", headers=HEADERS)
        requests.delete(f"{BASE_URL}/api/ingredients/{ing_id}", headers=HEADERS)


class TestPeriodFiltering:
    """Tests for period filtering (today, week, month, year)"""
    
    def test_period_today(self):
        """Test period=today"""
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "today"}
        )
        assert response.status_code == 200
        assert response.json()["period"] == "today"
        print("✓ Period 'today' works")
        
    def test_period_week(self):
        """Test period=week"""
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "week"}
        )
        assert response.status_code == 200
        assert response.json()["period"] == "week"
        print("✓ Period 'week' works")
        
    def test_period_month(self):
        """Test period=month (default)"""
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "month"}
        )
        assert response.status_code == 200
        assert response.json()["period"] == "month"
        print("✓ Period 'month' works")
        
    def test_period_year(self):
        """Test period=year"""
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "year"}
        )
        assert response.status_code == 200
        assert response.json()["period"] == "year"
        print("✓ Period 'year' works")


class TestClassificationLogic:
    """Tests for Menu Engineering classification logic"""
    
    def test_classification_counts_sum_equals_total(self):
        """Test that classification counts sum equals total items"""
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "month"}
        )
        assert response.status_code == 200
        data = response.json()
        
        total_items = data["summary"]["total_items"]
        counts = data["classification_counts"]
        
        classification_sum = sum(counts.values())
        assert classification_sum == total_items, f"Classification sum ({classification_sum}) != total items ({total_items})"
        print(f"✓ Classification counts sum ({classification_sum}) equals total items ({total_items})")
        
    def test_top_profitable_sorted_correctly(self):
        """Test top_profitable is sorted by total_profit_period desc"""
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "month"}
        )
        assert response.status_code == 200
        data = response.json()
        
        top = data["top_profitable"]
        if len(top) > 1:
            for i in range(len(top) - 1):
                assert top[i]["total_profit_period"] >= top[i+1]["total_profit_period"], \
                    "top_profitable not sorted by total_profit_period desc"
        print(f"✓ Top profitable ({len(top)} items) sorted correctly")
        
    def test_top_profitable_max_five(self):
        """Test top_profitable returns max 5 items"""
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "month"}
        )
        assert response.status_code == 200
        data = response.json()
        
        assert len(data["top_profitable"]) <= 5, f"top_profitable should have max 5 items, got {len(data['top_profitable'])}"
        print(f"✓ top_profitable returns {len(data['top_profitable'])} items (max 5)")


class TestSalesIntegration:
    """Tests for sales data integration with profitability"""
    
    def test_units_sold_period_from_sales(self):
        """Test units_sold_period is calculated from sales data"""
        # Create ingredient and recipe
        ing_response = requests.post(
            f"{BASE_URL}/api/ingredients",
            headers=HEADERS,
            json={"name": "Sales Test Ingredient", "unit": "g", "cost_per_unit": 0.01}
        )
        assert ing_response.status_code == 200
        ing_id = ing_response.json()["ingredient_id"]
        
        recipe_response = requests.post(
            f"{BASE_URL}/api/recipes",
            headers=HEADERS,
            json={
                "name": "Sales Test Recipe",
                "category": "Prato Principal",
                "ingredients": [{"ingredient_id": ing_id, "quantity": 100}],
                "selling_price": 30.00
            }
        )
        assert recipe_response.status_code == 200
        recipe_id = recipe_response.json()["recipe_id"]
        
        # Create a sale for this recipe
        sale_response = requests.post(
            f"{BASE_URL}/api/sales",
            headers=HEADERS,
            json={
                "item_type": "recipe_item",
                "item_id": recipe_id,
                "quantity_sold": 5,
                "sale_price": 30.00
            }
        )
        assert sale_response.status_code == 200
        sale_id = sale_response.json()["sale_id"]
        
        # Get profitability
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "month"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Find our recipe
        test_item = None
        for item in data["items"]:
            if item.get("item_id") == recipe_id:
                test_item = item
                break
        
        assert test_item is not None, "Sales test recipe not found"
        assert test_item["units_sold_period"] >= 5, f"Expected at least 5 units sold, got {test_item['units_sold_period']}"
        assert test_item["total_profit_period"] > 0, "Total profit should be positive"
        
        print(f"✓ Sales integration works - units_sold: {test_item['units_sold_period']}, total_profit: {test_item['total_profit_period']}")
        
        # Cleanup
        requests.delete(f"{BASE_URL}/api/sales/{sale_id}", headers=HEADERS)
        requests.delete(f"{BASE_URL}/api/recipes/{recipe_id}", headers=HEADERS)
        requests.delete(f"{BASE_URL}/api/ingredients/{ing_id}", headers=HEADERS)


class TestResaleProductsProfitability:
    """Tests for resale products in profitability"""
    
    def test_resale_products_included(self):
        """Test resale products appear in profitability data"""
        # Create resale product
        product_response = requests.post(
            f"{BASE_URL}/api/resale-products",
            headers=HEADERS,
            json={
                "name": "Profit Test Product",
                "purchase_cost": 5.00,
                "sale_price": 12.00,
                "category": "Bebidas"
            }
        )
        assert product_response.status_code == 200
        product_id = product_response.json()["product_id"]
        
        # Get profitability
        response = requests.get(
            f"{BASE_URL}/api/menu/profitability",
            headers=HEADERS,
            params={"period": "month"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Find our product
        found = False
        for item in data["items"]:
            if item.get("item_id") == product_id and item.get("item_type") == "resale_product":
                found = True
                assert item["cost"] == 5.00, f"Expected cost 5.00, got {item['cost']}"
                assert item["sale_price"] == 12.00, f"Expected sale_price 12.00, got {item['sale_price']}"
                assert item["profit_per_unit"] == 7.00, f"Expected profit 7.00, got {item['profit_per_unit']}"
                break
        
        assert found, "Resale product not found in profitability data"
        print(f"✓ Resale products included in profitability")
        
        # Cleanup
        requests.delete(f"{BASE_URL}/api/resale-products/{product_id}", headers=HEADERS)


class TestDashboardIntegration:
    """Tests for dashboard top_profitable integration"""
    
    def test_dashboard_summary_endpoint(self):
        """Test dashboard summary endpoint exists"""
        response = requests.get(
            f"{BASE_URL}/api/dashboard/summary",
            headers=HEADERS
        )
        assert response.status_code == 200
        print("✓ Dashboard summary endpoint works")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
