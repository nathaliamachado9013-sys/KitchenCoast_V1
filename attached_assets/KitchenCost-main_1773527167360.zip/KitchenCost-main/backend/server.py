from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Depends, UploadFile, File, Query
from fastapi.responses import JSONResponse, StreamingResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import httpx
import io
import json

# Import for Excel/PDF
from openpyxl import Workbook, load_workbook
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.enums import TA_CENTER, TA_RIGHT

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app
app = FastAPI(title="KitchenCost API")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============= MODELS =============

# User Models
class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    email: str
    name: str
    picture: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserSession(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    session_token: str
    expires_at: datetime
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Supported currencies
SUPPORTED_CURRENCIES = ["EUR", "USD", "BRL", "GBP"]
DEFAULT_CURRENCY = "EUR"

# Margin recommendations by category
MARGIN_RECOMMENDATIONS = {
    "Bebida": {"min": 0.80, "max": 0.90, "label": "80% - 90%"},
    "Pizza": {"min": 0.65, "max": 0.75, "label": "65% - 75%"},
    "Massa": {"min": 0.60, "max": 0.70, "label": "60% - 70%"},
    "Sobremesa": {"min": 0.70, "max": 0.80, "label": "70% - 80%"},
    "Entrada": {"min": 0.65, "max": 0.75, "label": "65% - 75%"},
    "Prato Principal": {"min": 0.60, "max": 0.70, "label": "60% - 70%"},
    "Acompanhamento": {"min": 0.55, "max": 0.65, "label": "55% - 65%"},
    "Outros": {"min": 0.50, "max": 0.70, "label": "50% - 70%"}
}

# Unit conversion factors (base unit: g for mass, ml for volume)
UNIT_CONVERSIONS = {
    # Mass units
    "g": 1.0,
    "kg": 1000.0,
    # Volume units
    "ml": 1.0,
    "l": 1000.0,
    # Count units (no conversion)
    "unit": 1.0,
    "unidade": 1.0,
    "package": 1.0,
    "pacote": 1.0,
    "box": 1.0,
    "caixa": 1.0,
    "dúzia": 12.0,
}

# Unit groups for conversion compatibility
UNIT_GROUPS = {
    "mass": ["g", "kg"],
    "volume": ["ml", "l"],
    "count": ["unit", "unidade", "package", "pacote", "box", "caixa", "dúzia"]
}

# User roles and permissions
USER_ROLES = {
    "admin": {
        "label": "Administrador",
        "permissions": ["all"]
    },
    "manager": {
        "label": "Gerente",
        "permissions": ["recipes", "stock", "ingredients", "suppliers", "reports", "production"]
    },
    "staff": {
        "label": "Funcionário",
        "permissions": ["view"]
    }
}

# Restaurant/Tenant Models
class Restaurant(BaseModel):
    model_config = ConfigDict(extra="ignore")
    restaurant_id: str = Field(default_factory=lambda: f"rest_{uuid.uuid4().hex[:12]}")
    user_id: str
    name: str
    address: Optional[str] = None
    phone: Optional[str] = None
    currency: str = DEFAULT_CURRENCY
    alert_email: Optional[str] = None  # NEW: for stock alerts
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class RestaurantCreate(BaseModel):
    name: str
    address: Optional[str] = None
    phone: Optional[str] = None
    currency: str = DEFAULT_CURRENCY
    alert_email: Optional[str] = None

class RestaurantUpdate(BaseModel):
    name: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    currency: Optional[str] = None
    alert_email: Optional[str] = None

# User Role Model (for team members)
class TeamMember(BaseModel):
    model_config = ConfigDict(extra="ignore")
    member_id: str = Field(default_factory=lambda: f"member_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    user_id: str
    email: str
    name: str
    role: str = "staff"  # admin, manager, staff
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class TeamMemberCreate(BaseModel):
    email: str
    name: str
    role: str = "staff"

class TeamMemberUpdate(BaseModel):
    name: Optional[str] = None
    role: Optional[str] = None

# Operational Costs Models
class OperationalCosts(BaseModel):
    model_config = ConfigDict(extra="ignore")
    costs_id: str = Field(default_factory=lambda: f"costs_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    rent: float = 0.0
    electricity: float = 0.0
    water: float = 0.0
    internet: float = 0.0
    salaries: float = 0.0
    accounting: float = 0.0
    taxes: float = 0.0
    other_costs: float = 0.0
    average_dishes_sold_per_month: float = 1.0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class OperationalCostsUpdate(BaseModel):
    rent: Optional[float] = None
    electricity: Optional[float] = None
    water: Optional[float] = None
    internet: Optional[float] = None
    salaries: Optional[float] = None
    accounting: Optional[float] = None
    taxes: Optional[float] = None
    other_costs: Optional[float] = None
    average_dishes_sold_per_month: Optional[float] = None

# Variable Cost Model
class VariableCost(BaseModel):
    name: str
    value: float

# Supplier Models
class Supplier(BaseModel):
    model_config = ConfigDict(extra="ignore")
    supplier_id: str = Field(default_factory=lambda: f"sup_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    name: str
    contact_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SupplierCreate(BaseModel):
    name: str
    contact_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None

class SupplierUpdate(BaseModel):
    name: Optional[str] = None
    contact_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None

# Ingredient Models
class Ingredient(BaseModel):
    model_config = ConfigDict(extra="ignore")
    ingredient_id: str = Field(default_factory=lambda: f"ing_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    supplier_id: Optional[str] = None
    name: str
    unit: str  # kg, g, L, ml, unidade - base unit for recipes
    purchase_unit: Optional[str] = None  # unit when purchased (may differ)
    cost_per_unit: float
    current_stock: float = 0.0
    min_stock: float = 0.0  # for alerts
    category: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class IngredientCreate(BaseModel):
    name: str
    unit: str
    purchase_unit: Optional[str] = None
    cost_per_unit: float
    supplier_id: Optional[str] = None
    current_stock: float = 0.0
    min_stock: float = 0.0
    category: Optional[str] = None

class IngredientUpdate(BaseModel):
    name: Optional[str] = None
    unit: Optional[str] = None
    purchase_unit: Optional[str] = None
    cost_per_unit: Optional[float] = None
    supplier_id: Optional[str] = None
    current_stock: Optional[float] = None
    min_stock: Optional[float] = None
    category: Optional[str] = None

# Ingredient Price History Model
class IngredientPriceHistory(BaseModel):
    model_config = ConfigDict(extra="ignore")
    history_id: str = Field(default_factory=lambda: f"price_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    ingredient_id: str
    price: float
    supplier_id: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Recipe/Ficha Técnica Models
class RecipeIngredient(BaseModel):
    ingredient_id: str
    ingredient_name: str
    quantity: float
    unit: str  # unit used in recipe (may differ from purchase unit)
    original_unit: Optional[str] = None  # ingredient's base unit
    cost: float  # calculated: quantity * cost_per_unit (with unit conversion)

class RecipeIngredientInput(BaseModel):
    ingredient_id: str
    quantity: float
    unit: Optional[str] = None  # if different from ingredient's unit

class Recipe(BaseModel):
    model_config = ConfigDict(extra="ignore")
    recipe_id: str = Field(default_factory=lambda: f"rec_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    yield_quantity: float = 1.0  # how many portions
    yield_unit: str = "porção"
    ingredients: List[RecipeIngredient] = []
    variable_costs: List[VariableCost] = []  # NEW: packaging, delivery, etc.
    ingredients_cost: float = 0.0  # NEW: only ingredients
    variable_costs_total: float = 0.0  # NEW: sum of variable costs
    fixed_cost_per_dish: float = 0.0  # NEW: calculated from operational costs
    total_cost: float = 0.0  # ingredients + variable + fixed
    cost_per_portion: float = 0.0
    desired_profit_margin: float = 0.0  # NEW: target margin (0-1)
    suggested_price: float = 0.0  # NEW: calculated from margin
    selling_price: float = 0.0  # actual price
    margin_percentage: float = 0.0
    profit: float = 0.0
    margin_status: Optional[str] = None  # NEW: "below", "within", "above"
    recommended_margin: Optional[dict] = None  # NEW: from category
    preparation_time: Optional[int] = None  # minutes
    instructions: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class VariableCostInput(BaseModel):
    name: str
    value: float

# Helper function for unit conversion
def convert_units(quantity: float, from_unit: str, to_unit: str) -> float:
    """Convert quantity from one unit to another"""
    from_unit = from_unit.lower()
    to_unit = to_unit.lower()
    
    if from_unit == to_unit:
        return quantity
    
    # Find unit groups
    from_group = None
    to_group = None
    for group, units in UNIT_GROUPS.items():
        if from_unit in units:
            from_group = group
        if to_unit in units:
            to_group = group
    
    # Can only convert within same group
    if from_group != to_group or from_group is None:
        return quantity  # No conversion possible
    
    # Convert to base unit, then to target
    from_factor = UNIT_CONVERSIONS.get(from_unit, 1.0)
    to_factor = UNIT_CONVERSIONS.get(to_unit, 1.0)
    
    return (quantity * from_factor) / to_factor

class RecipeCreate(BaseModel):
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    yield_quantity: float = 1.0
    yield_unit: str = "porção"
    ingredients: List[RecipeIngredientInput] = []
    variable_costs: List[VariableCostInput] = []  # NEW
    desired_profit_margin: float = 0.0  # NEW
    selling_price: float = 0.0
    preparation_time: Optional[int] = None
    instructions: Optional[str] = None

class RecipeUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    yield_quantity: Optional[float] = None
    yield_unit: Optional[str] = None
    ingredients: Optional[List[RecipeIngredientInput]] = None
    variable_costs: Optional[List[VariableCostInput]] = None  # NEW
    desired_profit_margin: Optional[float] = None  # NEW
    selling_price: Optional[float] = None
    preparation_time: Optional[int] = None
    instructions: Optional[str] = None

# Stock Movement Models
class StockMovement(BaseModel):
    model_config = ConfigDict(extra="ignore")
    movement_id: str = Field(default_factory=lambda: f"mov_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    ingredient_id: str
    ingredient_name: str
    movement_type: str  # "entrada" or "saida"
    quantity: float
    unit_cost: Optional[float] = None  # for entries
    total_cost: Optional[float] = None
    reason: Optional[str] = None  # "compra", "producao", "ajuste", "perda"
    recipe_id: Optional[str] = None  # if deducted for production
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class StockEntryCreate(BaseModel):
    ingredient_id: str
    quantity: float
    unit_cost: Optional[float] = None
    reason: str = "compra"

class StockExitCreate(BaseModel):
    ingredient_id: str
    quantity: float
    reason: str = "producao"
    recipe_id: Optional[str] = None

# Production Models (for automatic stock deduction)
class Production(BaseModel):
    model_config = ConfigDict(extra="ignore")
    production_id: str = Field(default_factory=lambda: f"prod_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    recipe_id: str
    recipe_name: str
    quantity: float  # how many times the recipe was made
    total_cost: float
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ProductionCreate(BaseModel):
    recipe_id: str
    quantity: float = 1.0
    date: Optional[datetime] = None
    notes: Optional[str] = None

# ============= RESALE PRODUCTS MODELS =============

RESALE_CATEGORIES = ['Refrigerantes', 'Águas', 'Sucos', 'Cervejas', 'Vinhos', 'Destilados', 'Energéticos', 'Outros']

class ResaleProduct(BaseModel):
    model_config = ConfigDict(extra="ignore")
    product_id: str = Field(default_factory=lambda: f"resale_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    name: str
    category: Optional[str] = None
    purchase_cost: float
    sale_price: float
    margin: float = 0.0  # auto calculated
    supplier_id: Optional[str] = None
    stock_quantity: float = 0.0
    unit: str = "unidade"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ResaleProductCreate(BaseModel):
    name: str
    category: Optional[str] = None
    purchase_cost: float
    sale_price: float
    supplier_id: Optional[str] = None
    stock_quantity: float = 0.0
    unit: str = "unidade"

class ResaleProductUpdate(BaseModel):
    name: Optional[str] = None
    category: Optional[str] = None
    purchase_cost: Optional[float] = None
    sale_price: Optional[float] = None
    supplier_id: Optional[str] = None
    stock_quantity: Optional[float] = None
    unit: Optional[str] = None

# ============= SALES MODELS =============

class Sale(BaseModel):
    model_config = ConfigDict(extra="ignore")
    sale_id: str = Field(default_factory=lambda: f"sale_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    item_type: str  # "recipe_item" or "resale_product"
    item_id: str
    item_name: str
    quantity_sold: float
    unit_cost: float
    sale_price: float
    total_revenue: float
    total_cost: float
    profit: float
    sales_channel: Optional[str] = None
    notes: Optional[str] = None
    date: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SaleCreate(BaseModel):
    item_type: str  # "recipe_item" or "resale_product"
    item_id: str
    quantity_sold: float
    sale_price: Optional[float] = None  # if None, uses default price
    sales_channel: Optional[str] = None
    notes: Optional[str] = None
    date: Optional[datetime] = None

# ============= MENU ITEMS MODELS =============

DEFAULT_MENU_CATEGORIES = ['Entradas', 'Pratos Principais', 'Acompanhamentos', 'Sobremesas', 'Bebidas', 'Snacks', 'Pizzas', 'Outros']

class MenuCategory(BaseModel):
    model_config = ConfigDict(extra="ignore")
    category_id: str = Field(default_factory=lambda: f"cat_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    name: str
    slug: str = ""
    display_order: int = 0
    is_active: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class MenuCategoryCreate(BaseModel):
    name: str
    display_order: Optional[int] = None

class MenuCategoryUpdate(BaseModel):
    name: Optional[str] = None
    display_order: Optional[int] = None
    is_active: Optional[bool] = None

class MenuItemComponent(BaseModel):
    component_type: str  # "recipe" or "resale_product"
    component_id: str
    quantity: float = 1.0

class MenuItem(BaseModel):
    model_config = ConfigDict(extra="ignore")
    menu_item_id: str = Field(default_factory=lambda: f"menu_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    name: str
    category: Optional[str] = None
    item_type: str  # "recipe", "resale_product", "composite_dish"
    recipe_id: Optional[str] = None
    product_id: Optional[str] = None
    components: List[MenuItemComponent] = []
    desired_margin: float = 0.0
    sale_price: float = 0.0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class MenuItemComponentInput(BaseModel):
    component_type: str
    component_id: str
    quantity: float = 1.0

class MenuItemCreate(BaseModel):
    name: str
    category: Optional[str] = None
    item_type: str
    recipe_id: Optional[str] = None
    product_id: Optional[str] = None
    components: List[MenuItemComponentInput] = []
    desired_margin: float = 0.0
    sale_price: float = 0.0

class MenuItemUpdate(BaseModel):
    name: Optional[str] = None
    category: Optional[str] = None
    item_type: Optional[str] = None
    recipe_id: Optional[str] = None
    product_id: Optional[str] = None
    components: Optional[List[MenuItemComponentInput]] = None
    desired_margin: Optional[float] = None
    sale_price: Optional[float] = None

# ============= ANALYTICS SUMMARY MODELS =============

class DailySalesSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")
    summary_id: str = Field(default_factory=lambda: f"dss_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    date: str  # YYYY-MM-DD format for easy querying
    menu_item_id: Optional[str] = None
    item_name: Optional[str] = None
    item_type: Optional[str] = None
    units_sold: float = 0.0
    revenue_total: float = 0.0
    cost_total: float = 0.0
    profit_total: float = 0.0
    average_margin: float = 0.0
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class MonthlyMenuProfitSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")
    summary_id: str = Field(default_factory=lambda: f"mmps_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    year: int
    month: int
    menu_item_id: str
    item_name: str
    item_type: str
    category: Optional[str] = None
    units_sold: float = 0.0
    revenue_total: float = 0.0
    cost_total: float = 0.0
    profit_total: float = 0.0
    profit_per_unit: float = 0.0
    average_margin: float = 0.0
    classification: str = "UNCLASSIFIED"
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class DashboardMetricsCache(BaseModel):
    model_config = ConfigDict(extra="ignore")
    cache_id: str = Field(default_factory=lambda: f"dmc_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    date: str  # YYYY-MM-DD format
    total_revenue: float = 0.0
    total_profit: float = 0.0
    total_units_sold: float = 0.0
    total_production_cost: float = 0.0
    inventory_value: float = 0.0
    low_stock_count: int = 0
    top_profit_item_id: Optional[str] = None
    top_profit_item_name: Optional[str] = None
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class InventoryValueSnapshot(BaseModel):
    model_config = ConfigDict(extra="ignore")
    snapshot_id: str = Field(default_factory=lambda: f"ivs_{uuid.uuid4().hex[:12]}")
    restaurant_id: str
    date: str  # YYYY-MM-DD format
    inventory_value: float = 0.0
    ingredients_count: int = 0
    low_stock_count: int = 0
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# ============= AUTH HELPERS =============

async def get_session_from_cookie(request: Request) -> Optional[str]:
    """Extract session token from cookie or header"""
    session_token = request.cookies.get("session_token")
    if not session_token:
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            session_token = auth_header.split(" ")[1]
    return session_token

async def get_current_user(request: Request) -> User:
    """Get current authenticated user"""
    session_token = await get_session_from_cookie(request)
    if not session_token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    session_doc = await db.user_sessions.find_one(
        {"session_token": session_token},
        {"_id": 0}
    )
    if not session_doc:
        raise HTTPException(status_code=401, detail="Invalid session")
    
    # Check expiry
    expires_at = session_doc["expires_at"]
    if isinstance(expires_at, str):
        expires_at = datetime.fromisoformat(expires_at)
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    if expires_at < datetime.now(timezone.utc):
        raise HTTPException(status_code=401, detail="Session expired")
    
    user_doc = await db.users.find_one(
        {"user_id": session_doc["user_id"]},
        {"_id": 0}
    )
    if not user_doc:
        raise HTTPException(status_code=401, detail="User not found")
    
    return User(**user_doc)

async def get_current_restaurant(request: Request, user: User = Depends(get_current_user)) -> Restaurant:
    """Get current user's restaurant"""
    restaurant_doc = await db.restaurants.find_one(
        {"user_id": user.user_id},
        {"_id": 0}
    )
    if not restaurant_doc:
        raise HTTPException(status_code=404, detail="Restaurant not found. Please create one first.")
    return Restaurant(**restaurant_doc)

# ============= AUTH ROUTES =============

@api_router.post("/auth/session")
async def exchange_session(request: Request, response: Response):
    """Exchange session_id from Emergent Auth for session token"""
    body = await request.json()
    session_id = body.get("session_id")
    
    if not session_id:
        raise HTTPException(status_code=400, detail="session_id required")
    
    # Call Emergent Auth to get user data
    async with httpx.AsyncClient() as client:
        auth_response = await client.get(
            "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data",
            headers={"X-Session-ID": session_id}
        )
    
    if auth_response.status_code != 200:
        raise HTTPException(status_code=401, detail="Invalid session_id")
    
    auth_data = auth_response.json()
    user_id = f"user_{uuid.uuid4().hex[:12]}"
    
    # Check if user exists
    existing_user = await db.users.find_one(
        {"email": auth_data["email"]},
        {"_id": 0}
    )
    
    if existing_user:
        user_id = existing_user["user_id"]
        # Update user data
        await db.users.update_one(
            {"user_id": user_id},
            {"$set": {
                "name": auth_data["name"],
                "picture": auth_data.get("picture")
            }}
        )
    else:
        # Create new user
        new_user = {
            "user_id": user_id,
            "email": auth_data["email"],
            "name": auth_data["name"],
            "picture": auth_data.get("picture"),
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        await db.users.insert_one(new_user)
    
    # Create session
    session_token = auth_data.get("session_token", f"sess_{uuid.uuid4().hex}")
    expires_at = datetime.now(timezone.utc) + timedelta(days=7)
    
    session_doc = {
        "user_id": user_id,
        "session_token": session_token,
        "expires_at": expires_at.isoformat(),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    # Remove old sessions for this user
    await db.user_sessions.delete_many({"user_id": user_id})
    await db.user_sessions.insert_one(session_doc)
    
    # Set cookie
    response.set_cookie(
        key="session_token",
        value=session_token,
        httponly=True,
        secure=True,
        samesite="none",
        path="/",
        max_age=7 * 24 * 60 * 60
    )
    
    # Get user data
    user_doc = await db.users.find_one({"user_id": user_id}, {"_id": 0})
    
    return {"user": user_doc, "session_token": session_token}

@api_router.get("/auth/me")
async def get_me(user: User = Depends(get_current_user)):
    """Get current user data"""
    return user.model_dump()

@api_router.post("/auth/logout")
async def logout(request: Request, response: Response):
    """Logout user"""
    session_token = await get_session_from_cookie(request)
    if session_token:
        await db.user_sessions.delete_many({"session_token": session_token})
    
    response.delete_cookie(key="session_token", path="/")
    return {"message": "Logged out successfully"}

# ============= RESTAURANT ROUTES =============

@api_router.post("/restaurants", response_model=dict)
async def create_restaurant(data: RestaurantCreate, user: User = Depends(get_current_user)):
    """Create a restaurant for the user"""
    # Check if user already has a restaurant
    existing = await db.restaurants.find_one({"user_id": user.user_id}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="User already has a restaurant")
    
    # Validate currency
    currency = data.currency if data.currency in SUPPORTED_CURRENCIES else DEFAULT_CURRENCY
    
    restaurant = Restaurant(
        user_id=user.user_id,
        name=data.name,
        address=data.address,
        phone=data.phone,
        currency=currency
    )
    
    doc = restaurant.model_dump()
    doc["created_at"] = doc["created_at"].isoformat()
    await db.restaurants.insert_one(doc)
    
    # Create default operational costs
    op_costs = OperationalCosts(restaurant_id=restaurant.restaurant_id)
    costs_doc = op_costs.model_dump()
    costs_doc["created_at"] = costs_doc["created_at"].isoformat()
    costs_doc["updated_at"] = costs_doc["updated_at"].isoformat()
    await db.operational_costs.insert_one(costs_doc)
    
    return {"restaurant_id": restaurant.restaurant_id, "name": restaurant.name, "currency": currency}

@api_router.get("/restaurants/me")
async def get_my_restaurant(user: User = Depends(get_current_user)):
    """Get current user's restaurant"""
    restaurant_doc = await db.restaurants.find_one(
        {"user_id": user.user_id},
        {"_id": 0}
    )
    return restaurant_doc

@api_router.put("/restaurants/me")
async def update_my_restaurant(data: RestaurantUpdate, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Update current user's restaurant"""
    update_data = {k: v for k, v in data.model_dump().items() if v is not None}
    
    # Validate currency if provided
    if "currency" in update_data and update_data["currency"] not in SUPPORTED_CURRENCIES:
        update_data["currency"] = DEFAULT_CURRENCY
    
    await db.restaurants.update_one(
        {"restaurant_id": restaurant.restaurant_id},
        {"$set": update_data}
    )
    return {"message": "Restaurant updated"}

@api_router.get("/restaurants/currencies")
async def get_supported_currencies():
    """Get list of supported currencies"""
    return {
        "currencies": SUPPORTED_CURRENCIES,
        "default": DEFAULT_CURRENCY,
        "symbols": {
            "EUR": "€",
            "USD": "$",
            "BRL": "R$",
            "GBP": "£"
        }
    }

# ============= OPERATIONAL COSTS ROUTES =============

async def get_fixed_cost_per_dish(restaurant_id: str) -> float:
    """Calculate fixed cost per dish from operational costs"""
    costs_doc = await db.operational_costs.find_one(
        {"restaurant_id": restaurant_id},
        {"_id": 0}
    )
    if not costs_doc:
        return 0.0
    
    total_monthly = (
        costs_doc.get("rent", 0) +
        costs_doc.get("electricity", 0) +
        costs_doc.get("water", 0) +
        costs_doc.get("internet", 0) +
        costs_doc.get("salaries", 0) +
        costs_doc.get("accounting", 0) +
        costs_doc.get("taxes", 0) +
        costs_doc.get("other_costs", 0)
    )
    
    avg_dishes = costs_doc.get("average_dishes_sold_per_month", 1)
    if avg_dishes <= 0:
        avg_dishes = 1
    
    return total_monthly / avg_dishes

@api_router.get("/operational-costs")
async def get_operational_costs(restaurant: Restaurant = Depends(get_current_restaurant)):
    """Get operational costs for the restaurant"""
    costs_doc = await db.operational_costs.find_one(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    
    if not costs_doc:
        # Create default if not exists
        op_costs = OperationalCosts(restaurant_id=restaurant.restaurant_id)
        costs_doc = op_costs.model_dump()
        costs_doc["created_at"] = costs_doc["created_at"].isoformat()
        costs_doc["updated_at"] = costs_doc["updated_at"].isoformat()
        await db.operational_costs.insert_one(costs_doc)
    
    # Calculate totals
    total_monthly = (
        costs_doc.get("rent", 0) +
        costs_doc.get("electricity", 0) +
        costs_doc.get("water", 0) +
        costs_doc.get("internet", 0) +
        costs_doc.get("salaries", 0) +
        costs_doc.get("accounting", 0) +
        costs_doc.get("taxes", 0) +
        costs_doc.get("other_costs", 0)
    )
    
    avg_dishes = costs_doc.get("average_dishes_sold_per_month", 1)
    if avg_dishes <= 0:
        avg_dishes = 1
    
    fixed_cost_per_dish = total_monthly / avg_dishes
    
    return {
        **costs_doc,
        "total_monthly_cost": round(total_monthly, 2),
        "fixed_cost_per_dish": round(fixed_cost_per_dish, 2)
    }

@api_router.put("/operational-costs")
async def update_operational_costs(data: OperationalCostsUpdate, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Update operational costs"""
    update_data = {k: v for k, v in data.model_dump().items() if v is not None}
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    result = await db.operational_costs.update_one(
        {"restaurant_id": restaurant.restaurant_id},
        {"$set": update_data},
        upsert=True
    )
    
    return {"message": "Operational costs updated"}

@api_router.get("/margin-recommendations")
async def get_margin_recommendations():
    """Get margin recommendations by category"""
    return MARGIN_RECOMMENDATIONS

# ============= SUPPLIER ROUTES =============

@api_router.get("/suppliers", response_model=List[dict])
async def list_suppliers(restaurant: Restaurant = Depends(get_current_restaurant)):
    """List all suppliers for the restaurant"""
    suppliers = await db.suppliers.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).sort("name", 1).to_list(1000)
    return suppliers

@api_router.post("/suppliers", response_model=dict)
async def create_supplier(data: SupplierCreate, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Create a new supplier"""
    supplier = Supplier(
        restaurant_id=restaurant.restaurant_id,
        **data.model_dump()
    )
    doc = supplier.model_dump()
    doc["created_at"] = doc["created_at"].isoformat()
    await db.suppliers.insert_one(doc)
    return {"supplier_id": supplier.supplier_id, "name": supplier.name}

@api_router.get("/suppliers/{supplier_id}")
async def get_supplier(supplier_id: str, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Get a specific supplier"""
    supplier = await db.suppliers.find_one(
        {"supplier_id": supplier_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")
    return supplier

@api_router.put("/suppliers/{supplier_id}")
async def update_supplier(supplier_id: str, data: SupplierUpdate, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Update a supplier"""
    update_data = {k: v for k, v in data.model_dump().items() if v is not None}
    result = await db.suppliers.update_one(
        {"supplier_id": supplier_id, "restaurant_id": restaurant.restaurant_id},
        {"$set": update_data}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Supplier not found")
    return {"message": "Supplier updated"}

@api_router.delete("/suppliers/{supplier_id}")
async def delete_supplier(supplier_id: str, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Delete a supplier"""
    result = await db.suppliers.delete_one(
        {"supplier_id": supplier_id, "restaurant_id": restaurant.restaurant_id}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Supplier not found")
    return {"message": "Supplier deleted"}

# ============= ANALYTICS SUMMARY HELPERS =============

async def update_daily_sales_summary(restaurant_id: str, date_str: str, item_id: str, item_name: str, item_type: str, units: float, revenue: float, cost: float):
    """Update or create daily sales summary for an item"""
    profit = revenue - cost
    margin = (profit / revenue * 100) if revenue > 0 else 0
    
    existing = await db.daily_sales_summary.find_one({
        "restaurant_id": restaurant_id,
        "date": date_str,
        "menu_item_id": item_id
    })
    
    if existing:
        new_units = existing.get("units_sold", 0) + units
        new_revenue = existing.get("revenue_total", 0) + revenue
        new_cost = existing.get("cost_total", 0) + cost
        new_profit = new_revenue - new_cost
        new_margin = (new_profit / new_revenue * 100) if new_revenue > 0 else 0
        
        await db.daily_sales_summary.update_one(
            {"_id": existing["_id"]},
            {"$set": {
                "units_sold": new_units,
                "revenue_total": new_revenue,
                "cost_total": new_cost,
                "profit_total": new_profit,
                "average_margin": new_margin,
                "updated_at": datetime.now(timezone.utc)
            }}
        )
    else:
        summary = DailySalesSummary(
            restaurant_id=restaurant_id,
            date=date_str,
            menu_item_id=item_id,
            item_name=item_name,
            item_type=item_type,
            units_sold=units,
            revenue_total=revenue,
            cost_total=cost,
            profit_total=profit,
            average_margin=margin
        )
        await db.daily_sales_summary.insert_one(summary.model_dump())

async def update_monthly_menu_profit_summary(restaurant_id: str, year: int, month: int, item_id: str, item_name: str, item_type: str, category: str, units: float, revenue: float, cost: float):
    """Update or create monthly profit summary for a menu item"""
    profit = revenue - cost
    profit_per_unit = profit / units if units > 0 else 0
    margin = (profit / revenue * 100) if revenue > 0 else 0
    
    existing = await db.monthly_menu_profit_summary.find_one({
        "restaurant_id": restaurant_id,
        "year": year,
        "month": month,
        "menu_item_id": item_id
    })
    
    if existing:
        new_units = existing.get("units_sold", 0) + units
        new_revenue = existing.get("revenue_total", 0) + revenue
        new_cost = existing.get("cost_total", 0) + cost
        new_profit = new_revenue - new_cost
        new_profit_per_unit = new_profit / new_units if new_units > 0 else 0
        new_margin = (new_profit / new_revenue * 100) if new_revenue > 0 else 0
        
        await db.monthly_menu_profit_summary.update_one(
            {"_id": existing["_id"]},
            {"$set": {
                "units_sold": new_units,
                "revenue_total": new_revenue,
                "cost_total": new_cost,
                "profit_total": new_profit,
                "profit_per_unit": new_profit_per_unit,
                "average_margin": new_margin,
                "updated_at": datetime.now(timezone.utc)
            }}
        )
    else:
        summary = MonthlyMenuProfitSummary(
            restaurant_id=restaurant_id,
            year=year,
            month=month,
            menu_item_id=item_id,
            item_name=item_name,
            item_type=item_type,
            category=category,
            units_sold=units,
            revenue_total=revenue,
            cost_total=cost,
            profit_total=profit,
            profit_per_unit=profit_per_unit,
            average_margin=margin
        )
        await db.monthly_menu_profit_summary.insert_one(summary.model_dump())

async def update_dashboard_metrics_cache(restaurant_id: str, date_str: str, revenue_delta: float = 0, profit_delta: float = 0, units_delta: float = 0, production_cost_delta: float = 0):
    """Update dashboard metrics cache with incremental changes"""
    existing = await db.dashboard_metrics_cache.find_one({
        "restaurant_id": restaurant_id,
        "date": date_str
    })
    
    if existing:
        await db.dashboard_metrics_cache.update_one(
            {"_id": existing["_id"]},
            {"$inc": {
                "total_revenue": revenue_delta,
                "total_profit": profit_delta,
                "total_units_sold": units_delta,
                "total_production_cost": production_cost_delta
            },
            "$set": {"updated_at": datetime.now(timezone.utc)}}
        )
    else:
        # Calculate inventory metrics
        inventory_pipeline = [
            {"$match": {"restaurant_id": restaurant_id}},
            {"$group": {
                "_id": None,
                "inventory_value": {"$sum": {"$multiply": ["$current_stock", "$cost_per_unit"]}},
                "low_stock_count": {"$sum": {"$cond": [{"$lte": ["$current_stock", "$min_stock"]}, 1, 0]}}
            }}
        ]
        inv_result = await db.ingredients.aggregate(inventory_pipeline).to_list(1)
        inv_data = inv_result[0] if inv_result else {"inventory_value": 0, "low_stock_count": 0}
        
        cache = DashboardMetricsCache(
            restaurant_id=restaurant_id,
            date=date_str,
            total_revenue=max(0, revenue_delta),
            total_profit=profit_delta,
            total_units_sold=max(0, units_delta),
            total_production_cost=max(0, production_cost_delta),
            inventory_value=inv_data.get("inventory_value", 0),
            low_stock_count=inv_data.get("low_stock_count", 0)
        )
        await db.dashboard_metrics_cache.insert_one(cache.model_dump())

async def update_inventory_snapshot(restaurant_id: str):
    """Update inventory value snapshot for today"""
    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    
    pipeline = [
        {"$match": {"restaurant_id": restaurant_id}},
        {"$group": {
            "_id": None,
            "inventory_value": {"$sum": {"$multiply": ["$current_stock", "$cost_per_unit"]}},
            "ingredients_count": {"$sum": 1},
            "low_stock_count": {"$sum": {"$cond": [{"$lte": ["$current_stock", "$min_stock"]}, 1, 0]}}
        }}
    ]
    result = await db.ingredients.aggregate(pipeline).to_list(1)
    data = result[0] if result else {"inventory_value": 0, "ingredients_count": 0, "low_stock_count": 0}
    
    await db.inventory_value_snapshots.update_one(
        {"restaurant_id": restaurant_id, "date": date_str},
        {"$set": {
            "inventory_value": data.get("inventory_value", 0),
            "ingredients_count": data.get("ingredients_count", 0),
            "low_stock_count": data.get("low_stock_count", 0),
            "updated_at": datetime.now(timezone.utc)
        }},
        upsert=True
    )

async def recalculate_monthly_classifications(restaurant_id: str, year: int, month: int):
    """Recalculate menu engineering classifications for a month"""
    items = await db.monthly_menu_profit_summary.find({
        "restaurant_id": restaurant_id,
        "year": year,
        "month": month
    }).to_list(1000)
    
    if not items:
        return
    
    # Calculate averages
    total_units = sum(i.get("units_sold", 0) for i in items)
    total_profit_per_unit = sum(i.get("profit_per_unit", 0) for i in items)
    count = len(items)
    
    avg_units = total_units / count if count > 0 else 0
    avg_profit = total_profit_per_unit / count if count > 0 else 0
    
    # Update classifications
    for item in items:
        units = item.get("units_sold", 0)
        profit = item.get("profit_per_unit", 0)
        
        if units >= avg_units and profit >= avg_profit:
            classification = "STAR"
        elif units >= avg_units and profit < avg_profit:
            classification = "PLOWHORSE"
        elif units < avg_units and profit >= avg_profit:
            classification = "PUZZLE"
        else:
            classification = "DOG"
        
        await db.monthly_menu_profit_summary.update_one(
            {"_id": item["_id"]},
            {"$set": {"classification": classification, "updated_at": datetime.now(timezone.utc)}}
        )

# ============= INGREDIENT ROUTES =============

@api_router.get("/ingredients", response_model=List[dict])
async def list_ingredients(
    search: Optional[str] = None,
    category: Optional[str] = None,
    low_stock: bool = False,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """List all ingredients with optional filters"""
    query = {"restaurant_id": restaurant.restaurant_id}
    
    if search:
        query["name"] = {"$regex": search, "$options": "i"}
    if category:
        query["category"] = category
    if low_stock:
        query["$expr"] = {"$lte": ["$current_stock", "$min_stock"]}
    
    ingredients = await db.ingredients.find(query, {"_id": 0}).sort("name", 1).to_list(1000)
    
    # Add supplier name to each ingredient
    for ing in ingredients:
        if ing.get("supplier_id"):
            supplier = await db.suppliers.find_one(
                {"supplier_id": ing["supplier_id"]},
                {"_id": 0, "name": 1}
            )
            ing["supplier_name"] = supplier["name"] if supplier else None
    
    return ingredients

@api_router.post("/ingredients", response_model=dict)
async def create_ingredient(data: IngredientCreate, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Create a new ingredient"""
    ingredient = Ingredient(
        restaurant_id=restaurant.restaurant_id,
        **data.model_dump()
    )
    doc = ingredient.model_dump()
    doc["created_at"] = doc["created_at"].isoformat()
    doc["updated_at"] = doc["updated_at"].isoformat()
    await db.ingredients.insert_one(doc)
    
    # Record initial price in history
    await record_price_history(
        ingredient.ingredient_id,
        restaurant.restaurant_id,
        data.cost_per_unit,
        data.supplier_id
    )
    
    return {"ingredient_id": ingredient.ingredient_id, "name": ingredient.name}

@api_router.get("/ingredients/{ingredient_id}")
async def get_ingredient(ingredient_id: str, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Get a specific ingredient"""
    ingredient = await db.ingredients.find_one(
        {"ingredient_id": ingredient_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not ingredient:
        raise HTTPException(status_code=404, detail="Ingredient not found")
    return ingredient

@api_router.put("/ingredients/{ingredient_id}")
async def update_ingredient(ingredient_id: str, data: IngredientUpdate, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Update an ingredient"""
    # Get existing ingredient to check price change
    existing = await db.ingredients.find_one(
        {"ingredient_id": ingredient_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Ingredient not found")
    
    update_data = {k: v for k, v in data.model_dump().items() if v is not None}
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    # Record price history if price changed
    if data.cost_per_unit is not None and data.cost_per_unit != existing.get("cost_per_unit"):
        await record_price_history(
            ingredient_id,
            restaurant.restaurant_id,
            data.cost_per_unit,
            data.supplier_id or existing.get("supplier_id")
        )
    
    result = await db.ingredients.update_one(
        {"ingredient_id": ingredient_id, "restaurant_id": restaurant.restaurant_id},
        {"$set": update_data}
    )
    return {"message": "Ingredient updated"}

@api_router.delete("/ingredients/{ingredient_id}")
async def delete_ingredient(ingredient_id: str, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Delete an ingredient"""
    result = await db.ingredients.delete_one(
        {"ingredient_id": ingredient_id, "restaurant_id": restaurant.restaurant_id}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Ingredient not found")
    return {"message": "Ingredient deleted"}

@api_router.get("/ingredients/categories/list")
async def list_ingredient_categories(restaurant: Restaurant = Depends(get_current_restaurant)):
    """List all unique ingredient categories"""
    categories = await db.ingredients.distinct(
        "category",
        {"restaurant_id": restaurant.restaurant_id, "category": {"$ne": None}}
    )
    return categories

# ============= RECIPE ROUTES =============

async def calculate_recipe_costs(recipe_data: dict, restaurant_id: str) -> dict:
    """Calculate all costs for a recipe including fixed and variable costs"""
    ingredients_with_costs = []
    ingredients_cost = 0.0
    
    for ing_input in recipe_data.get("ingredients", []):
        ingredient = await db.ingredients.find_one(
            {"ingredient_id": ing_input["ingredient_id"], "restaurant_id": restaurant_id},
            {"_id": 0}
        )
        if not ingredient:
            continue
        
        cost = ing_input["quantity"] * ingredient["cost_per_unit"]
        ingredients_cost += cost
        
        ingredients_with_costs.append(RecipeIngredient(
            ingredient_id=ingredient["ingredient_id"],
            ingredient_name=ingredient["name"],
            quantity=ing_input["quantity"],
            unit=ingredient["unit"],
            cost=round(cost, 2)
        ))
    
    # Calculate variable costs total
    variable_costs = recipe_data.get("variable_costs", [])
    variable_costs_total = sum(vc.get("value", 0) for vc in variable_costs)
    
    # Get fixed cost per dish
    fixed_cost_per_dish = await get_fixed_cost_per_dish(restaurant_id)
    
    # Total cost = ingredients + variable + fixed
    yield_qty = recipe_data.get("yield_quantity", 1.0)
    ingredients_cost_per_portion = ingredients_cost / yield_qty if yield_qty > 0 else 0
    total_cost = ingredients_cost_per_portion + variable_costs_total + fixed_cost_per_dish
    cost_per_portion = total_cost
    
    # Pricing calculations
    desired_margin = recipe_data.get("desired_profit_margin", 0.0)
    selling_price = recipe_data.get("selling_price", 0.0)
    
    # Calculate suggested price from desired margin
    suggested_price = 0.0
    if desired_margin > 0 and desired_margin < 1:
        suggested_price = cost_per_portion / (1 - desired_margin)
    
    # Calculate actual margin and profit
    if selling_price > 0:
        profit = selling_price - cost_per_portion
        margin_percentage = (profit / selling_price * 100)
    else:
        profit = 0.0
        margin_percentage = 0.0
    
    # Get margin recommendation for category
    category = recipe_data.get("category", "Outros")
    recommended_margin = MARGIN_RECOMMENDATIONS.get(category, MARGIN_RECOMMENDATIONS["Outros"])
    
    # Determine margin status
    actual_margin_decimal = margin_percentage / 100
    margin_status = "within"
    if actual_margin_decimal < recommended_margin["min"]:
        margin_status = "below"
    elif actual_margin_decimal > recommended_margin["max"]:
        margin_status = "above"
    
    return {
        "ingredients": [ing.model_dump() for ing in ingredients_with_costs],
        "variable_costs": variable_costs,
        "ingredients_cost": round(ingredients_cost_per_portion, 2),
        "variable_costs_total": round(variable_costs_total, 2),
        "fixed_cost_per_dish": round(fixed_cost_per_dish, 2),
        "total_cost": round(total_cost, 2),
        "cost_per_portion": round(cost_per_portion, 2),
        "suggested_price": round(suggested_price, 2),
        "profit": round(profit, 2),
        "margin_percentage": round(margin_percentage, 2),
        "margin_status": margin_status,
        "recommended_margin": recommended_margin
    }

@api_router.get("/recipes", response_model=List[dict])
async def list_recipes(
    search: Optional[str] = None,
    category: Optional[str] = None,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """List all recipes with optional search"""
    query = {"restaurant_id": restaurant.restaurant_id}
    
    if search:
        query["name"] = {"$regex": search, "$options": "i"}
    if category:
        query["category"] = category
    
    recipes = await db.recipes.find(query, {"_id": 0}).sort("name", 1).to_list(1000)
    return recipes

@api_router.post("/recipes", response_model=dict)
async def create_recipe(data: RecipeCreate, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Create a new recipe with automatic cost calculation"""
    recipe_data = data.model_dump()
    recipe_data["ingredients"] = [{"ingredient_id": i.ingredient_id, "quantity": i.quantity} for i in data.ingredients]
    recipe_data["variable_costs"] = [{"name": vc.name, "value": vc.value} for vc in data.variable_costs]
    
    # Calculate costs
    cost_data = await calculate_recipe_costs(recipe_data, restaurant.restaurant_id)
    
    recipe = Recipe(
        restaurant_id=restaurant.restaurant_id,
        name=data.name,
        description=data.description,
        category=data.category,
        yield_quantity=data.yield_quantity,
        yield_unit=data.yield_unit,
        ingredients=cost_data["ingredients"],
        variable_costs=cost_data["variable_costs"],
        ingredients_cost=cost_data["ingredients_cost"],
        variable_costs_total=cost_data["variable_costs_total"],
        fixed_cost_per_dish=cost_data["fixed_cost_per_dish"],
        total_cost=cost_data["total_cost"],
        cost_per_portion=cost_data["cost_per_portion"],
        desired_profit_margin=data.desired_profit_margin,
        suggested_price=cost_data["suggested_price"],
        selling_price=data.selling_price,
        margin_percentage=cost_data["margin_percentage"],
        profit=cost_data["profit"],
        margin_status=cost_data["margin_status"],
        recommended_margin=cost_data["recommended_margin"],
        preparation_time=data.preparation_time,
        instructions=data.instructions
    )
    
    doc = recipe.model_dump()
    doc["created_at"] = doc["created_at"].isoformat()
    doc["updated_at"] = doc["updated_at"].isoformat()
    await db.recipes.insert_one(doc)
    
    return {"recipe_id": recipe.recipe_id, "name": recipe.name, "total_cost": recipe.total_cost}

@api_router.get("/recipes/{recipe_id}")
async def get_recipe(recipe_id: str, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Get a specific recipe"""
    recipe = await db.recipes.find_one(
        {"recipe_id": recipe_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not recipe:
        raise HTTPException(status_code=404, detail="Recipe not found")
    return recipe

@api_router.put("/recipes/{recipe_id}")
async def update_recipe(recipe_id: str, data: RecipeUpdate, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Update a recipe and recalculate costs"""
    existing = await db.recipes.find_one(
        {"recipe_id": recipe_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Recipe not found")
    
    update_data = {k: v for k, v in data.model_dump().items() if v is not None}
    
    # Check if recalculation is needed
    needs_recalc = any([
        data.ingredients is not None,
        data.variable_costs is not None,
        data.selling_price is not None,
        data.yield_quantity is not None,
        data.desired_profit_margin is not None,
        data.category is not None
    ])
    
    if needs_recalc:
        recipe_data = {**existing, **update_data}
        if data.ingredients:
            recipe_data["ingredients"] = [{"ingredient_id": i.ingredient_id, "quantity": i.quantity} for i in data.ingredients]
        if data.variable_costs:
            recipe_data["variable_costs"] = [{"name": vc.name, "value": vc.value} for vc in data.variable_costs]
        cost_data = await calculate_recipe_costs(recipe_data, restaurant.restaurant_id)
        update_data.update(cost_data)
    
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    await db.recipes.update_one(
        {"recipe_id": recipe_id, "restaurant_id": restaurant.restaurant_id},
        {"$set": update_data}
    )
    return {"message": "Recipe updated"}

@api_router.post("/recipes/recalculate-all")
async def recalculate_all_recipes(restaurant: Restaurant = Depends(get_current_restaurant)):
    """Recalculate costs for all recipes (useful after changing operational costs)"""
    recipes = await db.recipes.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).to_list(1000)
    
    updated_count = 0
    for recipe in recipes:
        recipe_data = {
            "ingredients": [{"ingredient_id": i["ingredient_id"], "quantity": i["quantity"]} for i in recipe.get("ingredients", [])],
            "variable_costs": recipe.get("variable_costs", []),
            "yield_quantity": recipe.get("yield_quantity", 1),
            "selling_price": recipe.get("selling_price", 0),
            "desired_profit_margin": recipe.get("desired_profit_margin", 0),
            "category": recipe.get("category", "Outros")
        }
        
        cost_data = await calculate_recipe_costs(recipe_data, restaurant.restaurant_id)
        cost_data["updated_at"] = datetime.now(timezone.utc).isoformat()
        
        await db.recipes.update_one(
            {"recipe_id": recipe["recipe_id"]},
            {"$set": cost_data}
        )
        updated_count += 1
    
    return {"message": f"Recalculated {updated_count} recipes"}

@api_router.delete("/recipes/{recipe_id}")
async def delete_recipe(recipe_id: str, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Delete a recipe"""
    result = await db.recipes.delete_one(
        {"recipe_id": recipe_id, "restaurant_id": restaurant.restaurant_id}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Recipe not found")
    return {"message": "Recipe deleted"}

@api_router.get("/recipes/categories/list")
async def list_recipe_categories(restaurant: Restaurant = Depends(get_current_restaurant)):
    """List all unique recipe categories"""
    categories = await db.recipes.distinct(
        "category",
        {"restaurant_id": restaurant.restaurant_id, "category": {"$ne": None}}
    )
    return categories

# ============= STOCK ROUTES =============

@api_router.post("/stock/entry")
async def create_stock_entry(data: StockEntryCreate, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Register stock entry (purchase)"""
    ingredient = await db.ingredients.find_one(
        {"ingredient_id": data.ingredient_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not ingredient:
        raise HTTPException(status_code=404, detail="Ingredient not found")
    
    unit_cost = data.unit_cost if data.unit_cost else ingredient["cost_per_unit"]
    total_cost = data.quantity * unit_cost
    
    movement = StockMovement(
        restaurant_id=restaurant.restaurant_id,
        ingredient_id=data.ingredient_id,
        ingredient_name=ingredient["name"],
        movement_type="entrada",
        quantity=data.quantity,
        unit_cost=unit_cost,
        total_cost=total_cost,
        reason=data.reason
    )
    
    doc = movement.model_dump()
    doc["created_at"] = doc["created_at"].isoformat()
    await db.stock_movements.insert_one(doc)
    
    # Update ingredient stock and cost if new cost provided
    update_data = {"current_stock": ingredient["current_stock"] + data.quantity}
    if data.unit_cost:
        update_data["cost_per_unit"] = data.unit_cost
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    await db.ingredients.update_one(
        {"ingredient_id": data.ingredient_id},
        {"$set": update_data}
    )
    
    return {"movement_id": movement.movement_id, "new_stock": update_data["current_stock"]}

@api_router.post("/stock/exit")
async def create_stock_exit(data: StockExitCreate, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Register stock exit (manual)"""
    ingredient = await db.ingredients.find_one(
        {"ingredient_id": data.ingredient_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not ingredient:
        raise HTTPException(status_code=404, detail="Ingredient not found")
    
    if ingredient["current_stock"] < data.quantity:
        raise HTTPException(status_code=400, detail="Insufficient stock")
    
    movement = StockMovement(
        restaurant_id=restaurant.restaurant_id,
        ingredient_id=data.ingredient_id,
        ingredient_name=ingredient["name"],
        movement_type="saida",
        quantity=data.quantity,
        total_cost=data.quantity * ingredient["cost_per_unit"],
        reason=data.reason,
        recipe_id=data.recipe_id
    )
    
    doc = movement.model_dump()
    doc["created_at"] = doc["created_at"].isoformat()
    await db.stock_movements.insert_one(doc)
    
    # Update ingredient stock
    new_stock = ingredient["current_stock"] - data.quantity
    await db.ingredients.update_one(
        {"ingredient_id": data.ingredient_id},
        {"$set": {
            "current_stock": new_stock,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    return {"movement_id": movement.movement_id, "new_stock": new_stock}

@api_router.get("/stock/movements")
async def list_stock_movements(
    ingredient_id: Optional[str] = None,
    movement_type: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """List stock movements with filters"""
    query = {"restaurant_id": restaurant.restaurant_id}
    
    if ingredient_id:
        query["ingredient_id"] = ingredient_id
    if movement_type:
        query["movement_type"] = movement_type
    if start_date:
        query["created_at"] = {"$gte": start_date}
    if end_date:
        if "created_at" in query:
            query["created_at"]["$lte"] = end_date
        else:
            query["created_at"] = {"$lte": end_date}
    
    movements = await db.stock_movements.find(query, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return movements

@api_router.get("/stock/inventory-value")
async def get_inventory_value(restaurant: Restaurant = Depends(get_current_restaurant)):
    """Calculate total inventory value"""
    ingredients = await db.ingredients.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).to_list(1000)
    
    total_value = sum(ing["current_stock"] * ing["cost_per_unit"] for ing in ingredients)
    items_count = len(ingredients)
    low_stock_count = sum(1 for ing in ingredients if ing["current_stock"] <= ing.get("min_stock", 0))
    
    return {
        "total_value": round(total_value, 2),
        "items_count": items_count,
        "low_stock_count": low_stock_count
    }

# ============= DASHBOARD/REPORTS ROUTES =============

@api_router.get("/dashboard/summary")
async def get_dashboard_summary(restaurant: Restaurant = Depends(get_current_restaurant)):
    """Get dashboard summary data"""
    # Count totals
    ingredients_count = await db.ingredients.count_documents({"restaurant_id": restaurant.restaurant_id})
    recipes_count = await db.recipes.count_documents({"restaurant_id": restaurant.restaurant_id})
    suppliers_count = await db.suppliers.count_documents({"restaurant_id": restaurant.restaurant_id})
    
    # Low stock alerts
    low_stock = await db.ingredients.count_documents({
        "restaurant_id": restaurant.restaurant_id,
        "$expr": {"$lte": ["$current_stock", "$min_stock"]}
    })
    
    # Inventory value
    ingredients = await db.ingredients.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0, "current_stock": 1, "cost_per_unit": 1}
    ).to_list(1000)
    inventory_value = sum(ing["current_stock"] * ing["cost_per_unit"] for ing in ingredients)
    
    # Today's production cost
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    today_productions = await db.productions.find({
        "restaurant_id": restaurant.restaurant_id,
        "created_at": {"$gte": today_start.isoformat()}
    }, {"_id": 0}).to_list(1000)
    today_cost = sum(p.get("total_cost", 0) for p in today_productions)
    
    # Top 5 most expensive recipes
    top_recipes = await db.recipes.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0, "name": 1, "total_cost": 1, "margin_percentage": 1}
    ).sort("total_cost", -1).limit(5).to_list(5)
    
    # Average margin
    all_recipes = await db.recipes.find(
        {"restaurant_id": restaurant.restaurant_id, "margin_percentage": {"$gt": 0}},
        {"_id": 0, "margin_percentage": 1}
    ).to_list(1000)
    avg_margin = sum(r["margin_percentage"] for r in all_recipes) / len(all_recipes) if all_recipes else 0
    
    return {
        "ingredients_count": ingredients_count,
        "recipes_count": recipes_count,
        "suppliers_count": suppliers_count,
        "low_stock_alerts": low_stock,
        "inventory_value": round(inventory_value, 2),
        "today_production_cost": round(today_cost, 2),
        "top_recipes": top_recipes,
        "average_margin": round(avg_margin, 2)
    }

@api_router.get("/reports/costs")
async def get_cost_report(
    period: str = "month",  # today, week, month, year, custom
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get cost report by period"""
    now = datetime.now(timezone.utc)
    
    if period == "today":
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = now
    elif period == "week":
        start = now - timedelta(days=7)
        end = now
    elif period == "month":
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        end = now
    elif period == "year":
        start = now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
        end = now
    elif period == "custom" and start_date and end_date:
        start = datetime.fromisoformat(start_date)
        end = datetime.fromisoformat(end_date)
    else:
        start = now - timedelta(days=30)
        end = now
    
    # Stock entries (purchases)
    entries = await db.stock_movements.find({
        "restaurant_id": restaurant.restaurant_id,
        "movement_type": "entrada",
        "created_at": {"$gte": start.isoformat(), "$lte": end.isoformat()}
    }, {"_id": 0}).to_list(1000)
    
    total_purchases = sum(e.get("total_cost", 0) for e in entries)
    
    # Productions
    productions = await db.productions.find({
        "restaurant_id": restaurant.restaurant_id,
        "created_at": {"$gte": start.isoformat(), "$lte": end.isoformat()}
    }, {"_id": 0}).to_list(1000)
    
    total_production_cost = sum(p.get("total_cost", 0) for p in productions)
    
    # Daily breakdown
    daily_costs = {}
    for prod in productions:
        date = prod["created_at"][:10]
        if date not in daily_costs:
            daily_costs[date] = 0
        daily_costs[date] += prod.get("total_cost", 0)
    
    return {
        "period": period,
        "start_date": start.isoformat(),
        "end_date": end.isoformat(),
        "total_purchases": round(total_purchases, 2),
        "total_production_cost": round(total_production_cost, 2),
        "productions_count": len(productions),
        "daily_breakdown": [{"date": k, "cost": round(v, 2)} for k, v in sorted(daily_costs.items())]
    }

@api_router.get("/reports/margins")
async def get_margin_report(restaurant: Restaurant = Depends(get_current_restaurant)):
    """Get margin analysis report"""
    recipes = await db.recipes.find(
        {"restaurant_id": restaurant.restaurant_id, "selling_price": {"$gt": 0}},
        {"_id": 0}
    ).to_list(1000)
    
    # Group by margin ranges
    margin_ranges = {
        "negative": [],  # < 0%
        "low": [],       # 0-20%
        "medium": [],    # 20-40%
        "good": [],      # 40-60%
        "excellent": []  # > 60%
    }
    
    for recipe in recipes:
        margin = recipe.get("margin_percentage", 0)
        recipe_info = {
            "name": recipe["name"],
            "margin_percentage": margin,
            "selling_price": recipe["selling_price"],
            "cost_per_portion": recipe["cost_per_portion"]
        }
        
        if margin < 0:
            margin_ranges["negative"].append(recipe_info)
        elif margin < 20:
            margin_ranges["low"].append(recipe_info)
        elif margin < 40:
            margin_ranges["medium"].append(recipe_info)
        elif margin < 60:
            margin_ranges["good"].append(recipe_info)
        else:
            margin_ranges["excellent"].append(recipe_info)
    
    avg_margin = sum(r.get("margin_percentage", 0) for r in recipes) / len(recipes) if recipes else 0
    
    return {
        "total_recipes": len(recipes),
        "average_margin": round(avg_margin, 2),
        "margin_distribution": {
            "negative": len(margin_ranges["negative"]),
            "low": len(margin_ranges["low"]),
            "medium": len(margin_ranges["medium"]),
            "good": len(margin_ranges["good"]),
            "excellent": len(margin_ranges["excellent"])
        },
        "recipes_by_margin": margin_ranges
    }

@api_router.get("/alerts/low-stock")
async def get_low_stock_alerts(restaurant: Restaurant = Depends(get_current_restaurant)):
    """Get ingredients with low stock"""
    ingredients = await db.ingredients.find({
        "restaurant_id": restaurant.restaurant_id,
        "$expr": {"$lte": ["$current_stock", "$min_stock"]}
    }, {"_id": 0}).to_list(1000)
    
    return ingredients

# ============= IMPORT/EXPORT ROUTES =============

@api_router.post("/import/ingredients/preview")
async def preview_import_ingredients(
    file: UploadFile = File(...),
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Preview ingredient import from Excel file"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only Excel files (.xlsx, .xls) are accepted")
    
    try:
        contents = await file.read()
        wb = load_workbook(filename=io.BytesIO(contents), read_only=True)
        ws = wb.active
        
        # Get headers from first row
        headers = []
        for cell in ws[1]:
            headers.append(cell.value.lower() if cell.value else "")
        
        # Expected columns
        expected = ["name", "category", "price", "unit", "supplier", "min_stock"]
        missing = [col for col in ["name", "price", "unit"] if col not in headers]
        if missing:
            raise HTTPException(status_code=400, detail=f"Missing required columns: {missing}")
        
        # Parse rows
        preview_data = []
        errors = []
        existing_names = set()
        
        # Get existing ingredient names for duplicate check
        existing = await db.ingredients.find(
            {"restaurant_id": restaurant.restaurant_id},
            {"_id": 0, "name": 1}
        ).to_list(10000)
        existing_names = {ing["name"].lower() for ing in existing}
        
        # Get suppliers for name matching
        suppliers = await db.suppliers.find(
            {"restaurant_id": restaurant.restaurant_id},
            {"_id": 0, "supplier_id": 1, "name": 1}
        ).to_list(1000)
        supplier_map = {s["name"].lower(): s["supplier_id"] for s in suppliers}
        
        for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            row_data = dict(zip(headers, row))
            
            if not row_data.get("name"):
                continue
            
            item = {
                "row": row_idx,
                "name": str(row_data.get("name", "")).strip(),
                "category": str(row_data.get("category", "")).strip() or None,
                "cost_per_unit": 0.0,
                "unit": str(row_data.get("unit", "g")).strip().lower(),
                "supplier_id": None,
                "supplier_name": str(row_data.get("supplier", "")).strip() or None,
                "min_stock": 0.0,
                "status": "ok",
                "error": None
            }
            
            # Parse price
            try:
                price = row_data.get("price")
                if price is not None:
                    item["cost_per_unit"] = float(str(price).replace(",", ".").replace("€", "").replace("$", "").replace("R$", "").strip())
            except:
                item["status"] = "error"
                item["error"] = "Invalid price format"
            
            # Parse min_stock
            try:
                min_stock = row_data.get("min_stock")
                if min_stock is not None:
                    item["min_stock"] = float(str(min_stock).replace(",", ".").strip())
            except:
                pass
            
            # Match supplier
            if item["supplier_name"]:
                supplier_id = supplier_map.get(item["supplier_name"].lower())
                if supplier_id:
                    item["supplier_id"] = supplier_id
            
            # Check duplicate
            if item["name"].lower() in existing_names:
                item["status"] = "duplicate"
                item["error"] = "Ingredient already exists"
            
            preview_data.append(item)
        
        wb.close()
        
        return {
            "total_rows": len(preview_data),
            "valid": len([d for d in preview_data if d["status"] == "ok"]),
            "duplicates": len([d for d in preview_data if d["status"] == "duplicate"]),
            "errors": len([d for d in preview_data if d["status"] == "error"]),
            "data": preview_data
        }
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error reading file: {str(e)}")

@api_router.post("/import/ingredients/confirm")
async def confirm_import_ingredients(
    data: List[dict],
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Confirm and import ingredients from previewed data"""
    imported = 0
    skipped = 0
    
    for item in data:
        if item.get("status") != "ok":
            skipped += 1
            continue
        
        # Check duplicate again
        existing = await db.ingredients.find_one({
            "restaurant_id": restaurant.restaurant_id,
            "name": {"$regex": f"^{item['name']}$", "$options": "i"}
        })
        
        if existing:
            skipped += 1
            continue
        
        ingredient = Ingredient(
            restaurant_id=restaurant.restaurant_id,
            name=item["name"],
            category=item.get("category"),
            cost_per_unit=item.get("cost_per_unit", 0),
            unit=item.get("unit", "g"),
            supplier_id=item.get("supplier_id"),
            min_stock=item.get("min_stock", 0),
            current_stock=0
        )
        
        doc = ingredient.model_dump()
        doc["created_at"] = doc["created_at"].isoformat()
        doc["updated_at"] = doc["updated_at"].isoformat()
        await db.ingredients.insert_one(doc)
        imported += 1
    
    return {"imported": imported, "skipped": skipped}

@api_router.get("/export/ingredients/excel")
async def export_ingredients_excel(restaurant: Restaurant = Depends(get_current_restaurant)):
    """Export ingredients to Excel"""
    ingredients = await db.ingredients.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).sort("name", 1).to_list(10000)
    
    # Get suppliers for name mapping
    suppliers = await db.suppliers.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0, "supplier_id": 1, "name": 1}
    ).to_list(1000)
    supplier_map = {s["supplier_id"]: s["name"] for s in suppliers}
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Ingredientes"
    
    # Headers
    headers = ["Nome", "Categoria", "Unidade", "Custo/Unidade", "Estoque Atual", "Estoque Mínimo", "Fornecedor"]
    ws.append(headers)
    
    # Data
    for ing in ingredients:
        ws.append([
            ing.get("name", ""),
            ing.get("category", ""),
            ing.get("unit", ""),
            ing.get("cost_per_unit", 0),
            ing.get("current_stock", 0),
            ing.get("min_stock", 0),
            supplier_map.get(ing.get("supplier_id"), "")
        ])
    
    # Save to bytes
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=ingredientes.xlsx"}
    )

@api_router.get("/export/recipes/excel")
async def export_recipes_excel(restaurant: Restaurant = Depends(get_current_restaurant)):
    """Export recipes to Excel"""
    recipes = await db.recipes.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).sort("name", 1).to_list(10000)
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Fichas Técnicas"
    
    headers = ["Nome", "Categoria", "Rendimento", "Custo Ingredientes", "Custos Variáveis", "Custo Fixo", "Custo Total", "Preço Venda", "Margem %", "Lucro"]
    ws.append(headers)
    
    for rec in recipes:
        ws.append([
            rec.get("name", ""),
            rec.get("category", ""),
            f"{rec.get('yield_quantity', 1)} {rec.get('yield_unit', 'porção')}",
            rec.get("ingredients_cost", 0),
            rec.get("variable_costs_total", 0),
            rec.get("fixed_cost_per_dish", 0),
            rec.get("cost_per_portion", 0),
            rec.get("selling_price", 0),
            rec.get("margin_percentage", 0),
            rec.get("profit", 0)
        ])
    
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=fichas_tecnicas.xlsx"}
    )

@api_router.get("/export/suppliers/excel")
async def export_suppliers_excel(restaurant: Restaurant = Depends(get_current_restaurant)):
    """Export suppliers to Excel"""
    suppliers = await db.suppliers.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).sort("name", 1).to_list(10000)
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Fornecedores"
    
    headers = ["Nome", "Contato", "Telefone", "Email", "Endereço", "Notas"]
    ws.append(headers)
    
    for sup in suppliers:
        ws.append([
            sup.get("name", ""),
            sup.get("contact_name", ""),
            sup.get("phone", ""),
            sup.get("email", ""),
            sup.get("address", ""),
            sup.get("notes", "")
        ])
    
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=fornecedores.xlsx"}
    )

@api_router.get("/export/stock/excel")
async def export_stock_excel(restaurant: Restaurant = Depends(get_current_restaurant)):
    """Export stock movements to Excel"""
    movements = await db.stock_movements.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).sort("created_at", -1).to_list(10000)
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Movimentações"
    
    headers = ["Data", "Ingrediente", "Tipo", "Quantidade", "Custo Unit.", "Total", "Motivo"]
    ws.append(headers)
    
    for mov in movements:
        ws.append([
            mov.get("created_at", "")[:19] if mov.get("created_at") else "",
            mov.get("ingredient_name", ""),
            "Entrada" if mov.get("movement_type") == "entrada" else "Saída",
            mov.get("quantity", 0),
            mov.get("unit_cost", 0) or "",
            mov.get("total_cost", 0) or "",
            mov.get("reason", "")
        ])
    
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=movimentacoes_estoque.xlsx"}
    )

@api_router.get("/export/recipe/{recipe_id}/pdf")
async def export_recipe_pdf(recipe_id: str, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Export recipe as PDF"""
    recipe = await db.recipes.find_one(
        {"recipe_id": recipe_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not recipe:
        raise HTTPException(status_code=404, detail="Recipe not found")
    
    # Get currency symbol
    currency_symbols = {"EUR": "€", "USD": "$", "BRL": "R$", "GBP": "£"}
    symbol = currency_symbols.get(restaurant.currency, "€")
    
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)
    
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle('Title', parent=styles['Heading1'], fontSize=18, spaceAfter=20, alignment=TA_CENTER)
    subtitle_style = ParagraphStyle('Subtitle', parent=styles['Heading2'], fontSize=14, spaceAfter=10)
    normal_style = styles['Normal']
    
    elements = []
    
    # Title
    elements.append(Paragraph(f"Ficha Técnica: {recipe['name']}", title_style))
    
    if recipe.get('category'):
        elements.append(Paragraph(f"Categoria: {recipe['category']}", normal_style))
    
    elements.append(Paragraph(f"Rendimento: {recipe.get('yield_quantity', 1)} {recipe.get('yield_unit', 'porção')}", normal_style))
    elements.append(Spacer(1, 20))
    
    # Ingredients table
    elements.append(Paragraph("Ingredientes", subtitle_style))
    
    ing_data = [["Ingrediente", "Quantidade", "Unidade", "Custo"]]
    for ing in recipe.get('ingredients', []):
        ing_data.append([
            ing.get('ingredient_name', ''),
            f"{ing.get('quantity', 0):.2f}",
            ing.get('unit', ''),
            f"{symbol} {ing.get('cost', 0):.2f}"
        ])
    
    ing_table = Table(ing_data, colWidths=[7*cm, 3*cm, 2*cm, 3*cm])
    ing_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    elements.append(ing_table)
    elements.append(Spacer(1, 20))
    
    # Cost summary
    elements.append(Paragraph("Resumo de Custos", subtitle_style))
    
    cost_data = [
        ["Custo dos Ingredientes", f"{symbol} {recipe.get('ingredients_cost', 0):.2f}"],
        ["Custos Variáveis", f"{symbol} {recipe.get('variable_costs_total', 0):.2f}"],
        ["Custo Fixo por Prato", f"{symbol} {recipe.get('fixed_cost_per_dish', 0):.2f}"],
        ["Custo Total", f"{symbol} {recipe.get('cost_per_portion', 0):.2f}"],
        ["Preço de Venda", f"{symbol} {recipe.get('selling_price', 0):.2f}"],
        ["Margem", f"{recipe.get('margin_percentage', 0):.1f}%"],
        ["Lucro por Porção", f"{symbol} {recipe.get('profit', 0):.2f}"]
    ]
    
    cost_table = Table(cost_data, colWidths=[8*cm, 5*cm])
    cost_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('FONTNAME', (0, 3), (0, 3), 'Helvetica-Bold'),
        ('FONTNAME', (0, -1), (0, -1), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey)
    ]))
    elements.append(cost_table)
    
    # Instructions if present
    if recipe.get('instructions'):
        elements.append(Spacer(1, 20))
        elements.append(Paragraph("Modo de Preparo", subtitle_style))
        elements.append(Paragraph(recipe['instructions'], normal_style))
    
    doc.build(elements)
    buffer.seek(0)
    
    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=ficha_{recipe['name'].replace(' ', '_')}.pdf"}
    )

@api_router.get("/export/reports/costs/pdf")
async def export_cost_report_pdf(
    period: str = "month",
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Export cost report as PDF"""
    # Get report data
    now = datetime.now(timezone.utc)
    if period == "today":
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "week":
        start = now - timedelta(days=7)
    elif period == "month":
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    elif period == "year":
        start = now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
    else:
        start = now - timedelta(days=30)
    
    entries = await db.stock_movements.find({
        "restaurant_id": restaurant.restaurant_id,
        "movement_type": "entrada",
        "created_at": {"$gte": start.isoformat()}
    }, {"_id": 0}).to_list(10000)
    
    productions = await db.productions.find({
        "restaurant_id": restaurant.restaurant_id,
        "created_at": {"$gte": start.isoformat()}
    }, {"_id": 0}).to_list(10000)
    
    total_purchases = sum(e.get("total_cost", 0) for e in entries)
    total_production = sum(p.get("total_cost", 0) for p in productions)
    
    # Get currency symbol
    currency_symbols = {"EUR": "€", "USD": "$", "BRL": "R$", "GBP": "£"}
    symbol = currency_symbols.get(restaurant.currency, "€")
    
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)
    
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle('Title', parent=styles['Heading1'], fontSize=18, spaceAfter=20, alignment=TA_CENTER)
    subtitle_style = ParagraphStyle('Subtitle', parent=styles['Heading2'], fontSize=14, spaceAfter=10)
    
    elements = []
    
    # Title
    period_labels = {"today": "Hoje", "week": "Última Semana", "month": "Este Mês", "year": "Este Ano"}
    elements.append(Paragraph(f"Relatório de Custos - {period_labels.get(period, period)}", title_style))
    elements.append(Paragraph(f"Restaurante: {restaurant.name}", styles['Normal']))
    elements.append(Paragraph(f"Período: {start.strftime('%d/%m/%Y')} a {now.strftime('%d/%m/%Y')}", styles['Normal']))
    elements.append(Spacer(1, 20))
    
    # Summary
    elements.append(Paragraph("Resumo", subtitle_style))
    summary_data = [
        ["Total em Compras", f"{symbol} {total_purchases:.2f}"],
        ["Custo de Produção", f"{symbol} {total_production:.2f}"],
        ["Produções Realizadas", str(len(productions))]
    ]
    
    summary_table = Table(summary_data, colWidths=[8*cm, 5*cm])
    summary_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BACKGROUND', (0, 0), (-1, -1), colors.lightgrey)
    ]))
    elements.append(summary_table)
    
    doc.build(elements)
    buffer.seek(0)
    
    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=relatorio_custos_{period}.pdf"}
    )

# ============= INGREDIENT PRICE HISTORY =============

@api_router.get("/ingredients/{ingredient_id}/price-history")
async def get_ingredient_price_history(
    ingredient_id: str,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get price history for an ingredient"""
    history = await db.ingredient_price_history.find(
        {"ingredient_id": ingredient_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    
    return history

async def record_price_history(ingredient_id: str, restaurant_id: str, price: float, supplier_id: str = None):
    """Record a price change in history"""
    history_entry = IngredientPriceHistory(
        restaurant_id=restaurant_id,
        ingredient_id=ingredient_id,
        price=price,
        supplier_id=supplier_id
    )
    doc = history_entry.model_dump()
    doc["created_at"] = doc["created_at"].isoformat()
    await db.ingredient_price_history.insert_one(doc)

# ============= GLOBAL SEARCH =============

@api_router.get("/search")
async def global_search(
    q: str = Query(..., min_length=2),
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Global search across ingredients, recipes, and suppliers"""
    query_regex = {"$regex": q, "$options": "i"}
    
    # Search ingredients
    ingredients = await db.ingredients.find(
        {"restaurant_id": restaurant.restaurant_id, "name": query_regex},
        {"_id": 0, "ingredient_id": 1, "name": 1, "category": 1}
    ).limit(10).to_list(10)
    
    # Search recipes
    recipes = await db.recipes.find(
        {"restaurant_id": restaurant.restaurant_id, "name": query_regex},
        {"_id": 0, "recipe_id": 1, "name": 1, "category": 1}
    ).limit(10).to_list(10)
    
    # Search suppliers
    suppliers = await db.suppliers.find(
        {"restaurant_id": restaurant.restaurant_id, "name": query_regex},
        {"_id": 0, "supplier_id": 1, "name": 1}
    ).limit(10).to_list(10)
    
    return {
        "ingredients": [{"type": "ingredient", **i} for i in ingredients],
        "recipes": [{"type": "recipe", **r} for r in recipes],
        "suppliers": [{"type": "supplier", **s} for s in suppliers]
    }

# ============= DUPLICATE RECIPE =============

@api_router.post("/recipes/{recipe_id}/duplicate")
async def duplicate_recipe(recipe_id: str, restaurant: Restaurant = Depends(get_current_restaurant)):
    """Duplicate a recipe with all its ingredients and settings"""
    original = await db.recipes.find_one(
        {"recipe_id": recipe_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not original:
        raise HTTPException(status_code=404, detail="Recipe not found")
    
    # Create new recipe with copied data
    new_recipe_id = f"rec_{uuid.uuid4().hex[:12]}"
    new_recipe = {
        **original,
        "recipe_id": new_recipe_id,
        "name": f"{original['name']} (Cópia)",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.recipes.insert_one(new_recipe)
    
    return {"recipe_id": new_recipe_id, "name": new_recipe["name"]}

# ============= TEAM/ROLES MANAGEMENT =============

@api_router.get("/team")
async def list_team_members(restaurant: Restaurant = Depends(get_current_restaurant)):
    """List all team members for the restaurant"""
    members = await db.team_members.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).to_list(100)
    return members

@api_router.post("/team")
async def add_team_member(
    data: TeamMemberCreate,
    user: User = Depends(get_current_user),
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Add a new team member"""
    # Check if user is admin
    is_owner = restaurant.user_id == user.user_id
    if not is_owner:
        existing_member = await db.team_members.find_one({
            "restaurant_id": restaurant.restaurant_id,
            "user_id": user.user_id
        })
        if not existing_member or existing_member.get("role") != "admin":
            raise HTTPException(status_code=403, detail="Only admins can add team members")
    
    # Check if member already exists
    existing = await db.team_members.find_one({
        "restaurant_id": restaurant.restaurant_id,
        "email": data.email.lower()
    })
    if existing:
        raise HTTPException(status_code=400, detail="Member already exists")
    
    member = TeamMember(
        restaurant_id=restaurant.restaurant_id,
        user_id=f"pending_{uuid.uuid4().hex[:8]}",  # Will be updated when user accepts
        email=data.email.lower(),
        name=data.name,
        role=data.role if data.role in USER_ROLES else "staff"
    )
    
    doc = member.model_dump()
    doc["created_at"] = doc["created_at"].isoformat()
    await db.team_members.insert_one(doc)
    
    return {"member_id": member.member_id, "email": member.email, "role": member.role}

@api_router.put("/team/{member_id}")
async def update_team_member(
    member_id: str,
    data: TeamMemberUpdate,
    user: User = Depends(get_current_user),
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Update a team member's role"""
    # Check if user is admin
    is_owner = restaurant.user_id == user.user_id
    if not is_owner:
        existing_member = await db.team_members.find_one({
            "restaurant_id": restaurant.restaurant_id,
            "user_id": user.user_id
        })
        if not existing_member or existing_member.get("role") != "admin":
            raise HTTPException(status_code=403, detail="Only admins can update team members")
    
    update_data = {k: v for k, v in data.model_dump().items() if v is not None}
    if "role" in update_data and update_data["role"] not in USER_ROLES:
        update_data["role"] = "staff"
    
    result = await db.team_members.update_one(
        {"member_id": member_id, "restaurant_id": restaurant.restaurant_id},
        {"$set": update_data}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Member not found")
    
    return {"message": "Member updated"}

@api_router.delete("/team/{member_id}")
async def remove_team_member(
    member_id: str,
    user: User = Depends(get_current_user),
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Remove a team member"""
    # Check if user is admin
    is_owner = restaurant.user_id == user.user_id
    if not is_owner:
        existing_member = await db.team_members.find_one({
            "restaurant_id": restaurant.restaurant_id,
            "user_id": user.user_id
        })
        if not existing_member or existing_member.get("role") != "admin":
            raise HTTPException(status_code=403, detail="Only admins can remove team members")
    
    result = await db.team_members.delete_one({
        "member_id": member_id,
        "restaurant_id": restaurant.restaurant_id
    })
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Member not found")
    
    return {"message": "Member removed"}

@api_router.get("/roles")
async def get_available_roles():
    """Get available user roles and permissions"""
    return USER_ROLES

# ============= UNIT SYSTEM =============

@api_router.get("/units")
async def get_available_units():
    """Get available measurement units"""
    return {
        "units": list(UNIT_CONVERSIONS.keys()),
        "groups": UNIT_GROUPS,
        "conversions": UNIT_CONVERSIONS
    }

# ============= PAGINATION HELPER =============

@api_router.get("/ingredients/paginated")
async def list_ingredients_paginated(
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=100),
    search: Optional[str] = None,
    category: Optional[str] = None,
    low_stock: bool = False,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """List ingredients with pagination"""
    query = {"restaurant_id": restaurant.restaurant_id}
    
    if search:
        query["name"] = {"$regex": search, "$options": "i"}
    if category:
        query["category"] = category
    if low_stock:
        query["$expr"] = {"$lte": ["$current_stock", "$min_stock"]}
    
    total = await db.ingredients.count_documents(query)
    skip = (page - 1) * limit
    
    ingredients = await db.ingredients.find(query, {"_id": 0}).sort("name", 1).skip(skip).limit(limit).to_list(limit)
    
    # Add supplier name
    for ing in ingredients:
        if ing.get("supplier_id"):
            supplier = await db.suppliers.find_one(
                {"supplier_id": ing["supplier_id"]},
                {"_id": 0, "name": 1}
            )
            ing["supplier_name"] = supplier["name"] if supplier else None
    
    return {
        "data": ingredients,
        "total": total,
        "page": page,
        "limit": limit,
        "total_pages": (total + limit - 1) // limit
    }

@api_router.get("/recipes/paginated")
async def list_recipes_paginated(
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=100),
    search: Optional[str] = None,
    category: Optional[str] = None,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """List recipes with pagination"""
    query = {"restaurant_id": restaurant.restaurant_id}
    
    if search:
        query["name"] = {"$regex": search, "$options": "i"}
    if category:
        query["category"] = category
    
    total = await db.recipes.count_documents(query)
    skip = (page - 1) * limit
    
    recipes = await db.recipes.find(query, {"_id": 0}).sort("name", 1).skip(skip).limit(limit).to_list(limit)
    
    return {
        "data": recipes,
        "total": total,
        "page": page,
        "limit": limit,
        "total_pages": (total + limit - 1) // limit
    }

# ============= RESALE PRODUCTS ROUTES =============

@api_router.get("/resale-products")
async def list_resale_products(
    search: Optional[str] = None,
    category: Optional[str] = None,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """List all resale products"""
    query = {"restaurant_id": restaurant.restaurant_id}
    if search:
        query["name"] = {"$regex": search, "$options": "i"}
    if category:
        query["category"] = category
    
    products = await db.resale_products.find(query, {"_id": 0}).sort("name", 1).to_list(500)
    
    # Add supplier name
    for product in products:
        if product.get("supplier_id"):
            supplier = await db.suppliers.find_one(
                {"supplier_id": product["supplier_id"]},
                {"_id": 0, "name": 1}
            )
            product["supplier_name"] = supplier["name"] if supplier else None
    
    return products

@api_router.post("/resale-products")
async def create_resale_product(
    data: ResaleProductCreate,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Create a new resale product"""
    # Calculate margin
    margin = 0.0
    if data.sale_price > 0:
        margin = ((data.sale_price - data.purchase_cost) / data.sale_price) * 100
    
    product = ResaleProduct(
        restaurant_id=restaurant.restaurant_id,
        name=data.name,
        category=data.category,
        purchase_cost=data.purchase_cost,
        sale_price=data.sale_price,
        margin=margin,
        supplier_id=data.supplier_id,
        stock_quantity=data.stock_quantity,
        unit=data.unit
    )
    
    await db.resale_products.insert_one(product.model_dump())
    return {"product_id": product.product_id, "message": "Product created"}

@api_router.get("/resale-products/{product_id}")
async def get_resale_product(
    product_id: str,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get a single resale product"""
    product = await db.resale_products.find_one(
        {"product_id": product_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product

@api_router.put("/resale-products/{product_id}")
async def update_resale_product(
    product_id: str,
    data: ResaleProductUpdate,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Update a resale product"""
    product = await db.resale_products.find_one(
        {"product_id": product_id, "restaurant_id": restaurant.restaurant_id}
    )
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    update_data = {k: v for k, v in data.model_dump().items() if v is not None}
    update_data["updated_at"] = datetime.now(timezone.utc)
    
    # Recalculate margin if prices changed
    purchase_cost = update_data.get("purchase_cost", product.get("purchase_cost", 0))
    sale_price = update_data.get("sale_price", product.get("sale_price", 0))
    if sale_price > 0:
        update_data["margin"] = ((sale_price - purchase_cost) / sale_price) * 100
    
    await db.resale_products.update_one(
        {"product_id": product_id},
        {"$set": update_data}
    )
    return {"message": "Product updated"}

@api_router.delete("/resale-products/{product_id}")
async def delete_resale_product(
    product_id: str,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Delete a resale product"""
    result = await db.resale_products.delete_one(
        {"product_id": product_id, "restaurant_id": restaurant.restaurant_id}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")
    return {"message": "Product deleted"}

@api_router.get("/resale-products/categories/list")
async def get_resale_categories():
    """Get list of resale product categories"""
    return RESALE_CATEGORIES

# ============= MENU (CARDÁPIO) ROUTES =============

async def calculate_menu_item_cost(item: dict, restaurant_id: str) -> dict:
    """Calculate cost, margin, and profit for a menu item"""
    cost = 0.0
    sale_price = item.get("sale_price", 0)
    
    if item["item_type"] == "recipe":
        if item.get("recipe_id"):
            recipe = await db.recipes.find_one(
                {"recipe_id": item["recipe_id"], "restaurant_id": restaurant_id},
                {"_id": 0}
            )
            if recipe:
                cost = recipe.get("cost_per_portion", 0)
                if sale_price == 0:
                    sale_price = recipe.get("selling_price", 0)
    
    elif item["item_type"] == "resale_product":
        if item.get("product_id"):
            product = await db.resale_products.find_one(
                {"product_id": item["product_id"], "restaurant_id": restaurant_id},
                {"_id": 0}
            )
            if product:
                cost = product.get("purchase_cost", 0)
                if sale_price == 0:
                    sale_price = product.get("sale_price", 0)
    
    elif item["item_type"] == "composite_dish":
        for comp in item.get("components", []):
            comp_cost = 0
            if comp["component_type"] == "recipe":
                recipe = await db.recipes.find_one(
                    {"recipe_id": comp["component_id"], "restaurant_id": restaurant_id},
                    {"_id": 0}
                )
                if recipe:
                    comp_cost = recipe.get("cost_per_portion", 0)
            elif comp["component_type"] == "resale_product":
                product = await db.resale_products.find_one(
                    {"product_id": comp["component_id"], "restaurant_id": restaurant_id},
                    {"_id": 0}
                )
                if product:
                    comp_cost = product.get("purchase_cost", 0)
            cost += comp_cost * comp.get("quantity", 1)
    
    # Calculate margin and profit
    margin = 0.0
    profit_per_unit = 0.0
    if sale_price > 0:
        margin = ((sale_price - cost) / sale_price) * 100
        profit_per_unit = sale_price - cost
    
    # Calculate suggested price from desired margin
    desired_margin = item.get("desired_margin", 0)
    suggested_price = 0.0
    if desired_margin > 0 and desired_margin < 1:
        suggested_price = cost / (1 - desired_margin)
    
    return {
        "cost": round(cost, 2),
        "sale_price": round(sale_price, 2),
        "margin": round(margin, 1),
        "profit_per_unit": round(profit_per_unit, 2),
        "suggested_price": round(suggested_price, 2)
    }

@api_router.get("/menu")
async def get_menu(
    search: Optional[str] = None,
    category: Optional[str] = None,
    item_type: Optional[str] = None,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get all menu items including custom menu_items, recipes, and resale products"""
    menu_items = []
    
    # First, get custom menu_items from the new collection
    menu_query = {"restaurant_id": restaurant.restaurant_id}
    if search:
        menu_query["name"] = {"$regex": search, "$options": "i"}
    if category:
        menu_query["category"] = category
    if item_type and item_type in ["recipe", "resale_product", "composite_dish"]:
        menu_query["item_type"] = item_type
    
    custom_items = await db.menu_items.find(menu_query, {"_id": 0}).to_list(500)
    for item in custom_items:
        calcs = await calculate_menu_item_cost(item, restaurant.restaurant_id)
        menu_items.append({
            "menu_item_id": item["menu_item_id"],
            "item_id": item["menu_item_id"],
            "item_type": item["item_type"],
            "name": item["name"],
            "category": item.get("category"),
            "cost": calcs["cost"],
            "sale_price": item.get("sale_price") or calcs["sale_price"],
            "margin": calcs["margin"],
            "profit_per_unit": calcs["profit_per_unit"],
            "suggested_price": calcs["suggested_price"],
            "desired_margin": item.get("desired_margin", 0),
            "recipe_id": item.get("recipe_id"),
            "product_id": item.get("product_id"),
            "components": item.get("components", []),
            "is_custom": True
        })
    
    # Add recipes not in custom menu_items (legacy view)
    if item_type is None or item_type == "recipe_item":
        recipe_query = {"restaurant_id": restaurant.restaurant_id}
        if search:
            recipe_query["name"] = {"$regex": search, "$options": "i"}
        if category:
            recipe_query["category"] = category
        
        recipes = await db.recipes.find(recipe_query, {"_id": 0}).to_list(500)
        custom_recipe_ids = [i.get("recipe_id") for i in custom_items if i.get("recipe_id")]
        
        for recipe in recipes:
            if recipe["recipe_id"] not in custom_recipe_ids:
                cost = recipe.get("cost_per_portion", 0)
                sale_price = recipe.get("selling_price", 0)
                profit = sale_price - cost if sale_price > 0 else 0
                menu_items.append({
                    "item_id": recipe["recipe_id"],
                    "item_type": "recipe_item",
                    "name": recipe["name"],
                    "category": recipe.get("category"),
                    "cost": cost,
                    "sale_price": sale_price,
                    "margin": recipe.get("margin_percentage", 0),
                    "profit_per_unit": profit,
                    "description": recipe.get("description"),
                    "margin_status": recipe.get("margin_status"),
                    "is_custom": False
                })
    
    # Add resale products not in custom menu_items (legacy view)
    if item_type is None or item_type == "resale_product":
        product_query = {"restaurant_id": restaurant.restaurant_id}
        if search:
            product_query["name"] = {"$regex": search, "$options": "i"}
        if category:
            product_query["category"] = category
        
        products = await db.resale_products.find(product_query, {"_id": 0}).to_list(500)
        custom_product_ids = [i.get("product_id") for i in custom_items if i.get("product_id")]
        
        for product in products:
            if product["product_id"] not in custom_product_ids:
                cost = product.get("purchase_cost", 0)
                sale_price = product.get("sale_price", 0)
                profit = sale_price - cost if sale_price > 0 else 0
                menu_items.append({
                    "item_id": product["product_id"],
                    "item_type": "resale_product",
                    "name": product["name"],
                    "category": product.get("category"),
                    "cost": cost,
                    "sale_price": sale_price,
                    "margin": product.get("margin", 0),
                    "profit_per_unit": profit,
                    "stock_quantity": product.get("stock_quantity", 0),
                    "unit": product.get("unit", "unidade"),
                    "is_custom": False
                })
    
    # Sort by name
    menu_items.sort(key=lambda x: x["name"])
    
    return menu_items

# ============= MENU CATEGORIES ROUTES =============

async def ensure_default_categories(restaurant_id: str):
    """Create default categories for a tenant if none exist"""
    count = await db.menu_categories.count_documents({"restaurant_id": restaurant_id})
    if count == 0:
        for i, name in enumerate(DEFAULT_MENU_CATEGORIES):
            slug = name.lower().replace(" ", "_").replace("á", "a").replace("ã", "a").replace("ç", "c")
            cat = MenuCategory(
                restaurant_id=restaurant_id,
                name=name,
                slug=slug,
                display_order=i,
                is_active=True
            )
            await db.menu_categories.insert_one(cat.model_dump())

@api_router.get("/menu/categories")
async def get_menu_categories(
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get tenant-specific menu categories"""
    await ensure_default_categories(restaurant.restaurant_id)
    
    categories = await db.menu_categories.find(
        {"restaurant_id": restaurant.restaurant_id, "is_active": True},
        {"_id": 0}
    ).sort("display_order", 1).to_list(100)
    
    return [c["name"] for c in categories]

@api_router.get("/menu/categories/all")
async def get_all_menu_categories(
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get all menu categories including inactive"""
    await ensure_default_categories(restaurant.restaurant_id)
    
    categories = await db.menu_categories.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).sort("display_order", 1).to_list(100)
    
    return categories

@api_router.post("/menu/categories")
async def create_menu_category(
    data: MenuCategoryCreate,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Create a new menu category"""
    # Check for duplicates
    existing = await db.menu_categories.find_one({
        "restaurant_id": restaurant.restaurant_id,
        "name": data.name
    })
    if existing:
        raise HTTPException(status_code=400, detail="Categoria já existe")
    
    # Get max order
    max_order = 0
    if data.display_order is None:
        last = await db.menu_categories.find_one(
            {"restaurant_id": restaurant.restaurant_id},
            sort=[("display_order", -1)]
        )
        if last:
            max_order = last.get("display_order", 0) + 1
    
    slug = data.name.lower().replace(" ", "_").replace("á", "a").replace("ã", "a").replace("ç", "c")
    
    cat = MenuCategory(
        restaurant_id=restaurant.restaurant_id,
        name=data.name,
        slug=slug,
        display_order=data.display_order if data.display_order is not None else max_order,
        is_active=True
    )
    await db.menu_categories.insert_one(cat.model_dump())
    
    return {"category_id": cat.category_id, "message": "Categoria criada"}

@api_router.put("/menu/categories/{category_id}")
async def update_menu_category(
    category_id: str,
    data: MenuCategoryUpdate,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Update a menu category"""
    cat = await db.menu_categories.find_one({
        "category_id": category_id,
        "restaurant_id": restaurant.restaurant_id
    })
    if not cat:
        raise HTTPException(status_code=404, detail="Categoria não encontrada")
    
    update_data = {k: v for k, v in data.model_dump().items() if v is not None}
    if "name" in update_data:
        update_data["slug"] = update_data["name"].lower().replace(" ", "_").replace("á", "a").replace("ã", "a").replace("ç", "c")
    update_data["updated_at"] = datetime.now(timezone.utc)
    
    await db.menu_categories.update_one(
        {"category_id": category_id},
        {"$set": update_data}
    )
    return {"message": "Categoria atualizada"}

@api_router.delete("/menu/categories/{category_id}")
async def delete_menu_category(
    category_id: str,
    force: bool = False,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Delete a menu category (only if not in use)"""
    cat = await db.menu_categories.find_one({
        "category_id": category_id,
        "restaurant_id": restaurant.restaurant_id
    })
    if not cat:
        raise HTTPException(status_code=404, detail="Categoria não encontrada")
    
    # Check if category is in use
    items_using = await db.menu_items.count_documents({
        "restaurant_id": restaurant.restaurant_id,
        "category": cat["name"]
    })
    recipes_using = await db.recipes.count_documents({
        "restaurant_id": restaurant.restaurant_id,
        "category": cat["name"]
    })
    
    total_using = items_using + recipes_using
    
    if total_using > 0 and not force:
        raise HTTPException(
            status_code=400, 
            detail=f"Categoria em uso por {total_using} item(s). Use force=true para desativar."
        )
    
    if total_using > 0 and force:
        # Deactivate instead of delete
        await db.menu_categories.update_one(
            {"category_id": category_id},
            {"$set": {"is_active": False, "updated_at": datetime.now(timezone.utc)}}
        )
        return {"message": "Categoria desativada (estava em uso)"}
    
    await db.menu_categories.delete_one({"category_id": category_id})
    return {"message": "Categoria excluída"}

@api_router.put("/menu/categories/reorder")
async def reorder_menu_categories(
    order: List[str],
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Reorder menu categories"""
    for i, category_id in enumerate(order):
        await db.menu_categories.update_one(
            {"category_id": category_id, "restaurant_id": restaurant.restaurant_id},
            {"$set": {"display_order": i, "updated_at": datetime.now(timezone.utc)}}
        )
    return {"message": "Ordem atualizada"}

@api_router.get("/menu/profitability")
async def get_menu_profitability(
    period: str = "month",
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get menu profitability analysis with Menu Engineering classification"""
    now = datetime.now(timezone.utc)
    
    # Calculate period start date
    if period == "today":
        start_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "week":
        start_date = now - timedelta(days=7)
    elif period == "month":
        start_date = now - timedelta(days=30)
    else:  # year
        start_date = now - timedelta(days=365)
    
    # Get all menu items with costs
    menu_items = []
    
    # Get custom menu_items
    custom_items = await db.menu_items.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).to_list(500)
    
    for item in custom_items:
        calcs = await calculate_menu_item_cost(item, restaurant.restaurant_id)
        menu_items.append({
            "item_id": item["menu_item_id"],
            "item_type": item["item_type"],
            "name": item["name"],
            "category": item.get("category"),
            "cost": calcs["cost"],
            "sale_price": item.get("sale_price") or calcs["sale_price"],
            "profit_per_unit": calcs["profit_per_unit"],
            "margin": calcs["margin"],
            "is_custom": True
        })
    
    # Get recipes
    recipes = await db.recipes.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).to_list(500)
    
    custom_recipe_ids = [i.get("recipe_id") for i in custom_items if i.get("recipe_id")]
    for recipe in recipes:
        if recipe["recipe_id"] not in custom_recipe_ids:
            cost = recipe.get("cost_per_portion", 0)
            sale_price = recipe.get("selling_price", 0)
            profit = sale_price - cost
            margin = ((sale_price - cost) / sale_price * 100) if sale_price > 0 else 0
            menu_items.append({
                "item_id": recipe["recipe_id"],
                "item_type": "recipe_item",
                "name": recipe["name"],
                "category": recipe.get("category"),
                "cost": cost,
                "sale_price": sale_price,
                "profit_per_unit": profit,
                "margin": margin,
                "is_custom": False
            })
    
    # Get resale products
    products = await db.resale_products.find(
        {"restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    ).to_list(500)
    
    custom_product_ids = [i.get("product_id") for i in custom_items if i.get("product_id")]
    for product in products:
        if product["product_id"] not in custom_product_ids:
            cost = product.get("purchase_cost", 0)
            sale_price = product.get("sale_price", 0)
            profit = sale_price - cost
            margin = product.get("margin", 0)
            menu_items.append({
                "item_id": product["product_id"],
                "item_type": "resale_product",
                "name": product["name"],
                "category": product.get("category"),
                "cost": cost,
                "sale_price": sale_price,
                "profit_per_unit": profit,
                "margin": margin,
                "is_custom": False
            })
    
    # Get sales data for the period
    sales_pipeline = [
        {
            "$match": {
                "restaurant_id": restaurant.restaurant_id,
                "date": {"$gte": start_date}
            }
        },
        {
            "$group": {
                "_id": "$item_id",
                "units_sold": {"$sum": "$quantity_sold"},
                "total_revenue": {"$sum": "$total_revenue"},
                "total_cost": {"$sum": "$total_cost"}
            }
        }
    ]
    
    sales_data = await db.sales.aggregate(sales_pipeline).to_list(1000)
    sales_by_item = {s["_id"]: s for s in sales_data}
    
    # Enrich menu items with sales data
    items_with_data = []
    for item in menu_items:
        sale_info = sales_by_item.get(item["item_id"], {"units_sold": 0, "total_revenue": 0, "total_cost": 0})
        units_sold = sale_info.get("units_sold", 0)
        total_profit = item["profit_per_unit"] * units_sold
        
        items_with_data.append({
            **item,
            "units_sold_period": units_sold,
            "total_profit_period": round(total_profit, 2),
            "total_revenue_period": round(sale_info.get("total_revenue", 0), 2)
        })
    
    # Calculate averages for classification
    items_with_sales = [i for i in items_with_data if i["units_sold_period"] > 0 or i["profit_per_unit"] > 0]
    
    if items_with_sales:
        avg_units_sold = sum(i["units_sold_period"] for i in items_with_sales) / len(items_with_sales)
        avg_profit_per_unit = sum(i["profit_per_unit"] for i in items_with_sales) / len(items_with_sales)
    else:
        avg_units_sold = 0
        avg_profit_per_unit = 0
    
    # Classify items (Menu Engineering)
    classification_counts = {"STAR": 0, "PLOWHORSE": 0, "PUZZLE": 0, "DOG": 0, "UNCLASSIFIED": 0}
    
    for item in items_with_data:
        if item["sale_price"] <= 0:
            item["classification"] = "UNCLASSIFIED"
        elif item["units_sold_period"] >= avg_units_sold and item["profit_per_unit"] >= avg_profit_per_unit:
            item["classification"] = "STAR"
        elif item["units_sold_period"] >= avg_units_sold and item["profit_per_unit"] < avg_profit_per_unit:
            item["classification"] = "PLOWHORSE"
        elif item["units_sold_period"] < avg_units_sold and item["profit_per_unit"] >= avg_profit_per_unit:
            item["classification"] = "PUZZLE"
        else:
            item["classification"] = "DOG"
        
        classification_counts[item["classification"]] += 1
    
    # Sort by total profit for ranking
    items_with_data.sort(key=lambda x: x["total_profit_period"], reverse=True)
    
    # Calculate totals
    total_profit = sum(i["total_profit_period"] for i in items_with_data)
    total_revenue = sum(i["total_revenue_period"] for i in items_with_data)
    total_items_sold = sum(i["units_sold_period"] for i in items_with_data)
    
    return {
        "period": period,
        "items": items_with_data,
        "summary": {
            "total_items": len(items_with_data),
            "total_profit_period": round(total_profit, 2),
            "total_revenue_period": round(total_revenue, 2),
            "total_items_sold": total_items_sold,
            "avg_units_sold": round(avg_units_sold, 1),
            "avg_profit_per_unit": round(avg_profit_per_unit, 2)
        },
        "classification_counts": classification_counts,
        "top_profitable": items_with_data[:5]
    }

@api_router.post("/menu-items")
async def create_menu_item(
    data: MenuItemCreate,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Create a custom menu item"""
    # Validate item type
    if data.item_type not in ["recipe", "resale_product", "composite_dish"]:
        raise HTTPException(status_code=400, detail="Invalid item_type")
    
    # Validate references
    if data.item_type == "recipe" and data.recipe_id:
        recipe = await db.recipes.find_one(
            {"recipe_id": data.recipe_id, "restaurant_id": restaurant.restaurant_id}
        )
        if not recipe:
            raise HTTPException(status_code=404, detail="Recipe not found")
    
    if data.item_type == "resale_product" and data.product_id:
        product = await db.resale_products.find_one(
            {"product_id": data.product_id, "restaurant_id": restaurant.restaurant_id}
        )
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")
    
    if data.item_type == "composite_dish":
        for comp in data.components:
            if comp.component_type == "recipe":
                recipe = await db.recipes.find_one(
                    {"recipe_id": comp.component_id, "restaurant_id": restaurant.restaurant_id}
                )
                if not recipe:
                    raise HTTPException(status_code=404, detail=f"Recipe component {comp.component_id} not found")
            elif comp.component_type == "resale_product":
                product = await db.resale_products.find_one(
                    {"product_id": comp.component_id, "restaurant_id": restaurant.restaurant_id}
                )
                if not product:
                    raise HTTPException(status_code=404, detail=f"Product component {comp.component_id} not found")
    
    menu_item = MenuItem(
        restaurant_id=restaurant.restaurant_id,
        name=data.name,
        category=data.category,
        item_type=data.item_type,
        recipe_id=data.recipe_id,
        product_id=data.product_id,
        components=[MenuItemComponent(**c.model_dump()) for c in data.components],
        desired_margin=data.desired_margin,
        sale_price=data.sale_price
    )
    
    await db.menu_items.insert_one(menu_item.model_dump())
    
    # Calculate and return full item data
    calcs = await calculate_menu_item_cost(menu_item.model_dump(), restaurant.restaurant_id)
    
    return {
        "menu_item_id": menu_item.menu_item_id,
        "message": "Menu item created",
        **calcs
    }

@api_router.get("/menu-items/{menu_item_id}")
async def get_menu_item(
    menu_item_id: str,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get a single menu item"""
    item = await db.menu_items.find_one(
        {"menu_item_id": menu_item_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not item:
        raise HTTPException(status_code=404, detail="Menu item not found")
    
    calcs = await calculate_menu_item_cost(item, restaurant.restaurant_id)
    return {**item, **calcs}

@api_router.put("/menu-items/{menu_item_id}")
async def update_menu_item(
    menu_item_id: str,
    data: MenuItemUpdate,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Update a menu item"""
    item = await db.menu_items.find_one(
        {"menu_item_id": menu_item_id, "restaurant_id": restaurant.restaurant_id}
    )
    if not item:
        raise HTTPException(status_code=404, detail="Menu item not found")
    
    update_data = {k: v for k, v in data.model_dump().items() if v is not None}
    if "components" in update_data:
        update_data["components"] = [c.model_dump() if hasattr(c, 'model_dump') else c for c in update_data["components"]]
    update_data["updated_at"] = datetime.now(timezone.utc)
    
    await db.menu_items.update_one(
        {"menu_item_id": menu_item_id},
        {"$set": update_data}
    )
    return {"message": "Menu item updated"}

@api_router.delete("/menu-items/{menu_item_id}")
async def delete_menu_item(
    menu_item_id: str,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Delete a menu item"""
    result = await db.menu_items.delete_one(
        {"menu_item_id": menu_item_id, "restaurant_id": restaurant.restaurant_id}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Menu item not found")
    return {"message": "Menu item deleted"}

# ============= SALES ROUTES =============

@api_router.get("/sales")
async def list_sales(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    item_type: Optional[str] = None,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """List all sales"""
    query = {"restaurant_id": restaurant.restaurant_id}
    
    if start_date:
        query["date"] = {"$gte": datetime.fromisoformat(start_date)}
    if end_date:
        if "date" in query:
            query["date"]["$lte"] = datetime.fromisoformat(end_date)
        else:
            query["date"] = {"$lte": datetime.fromisoformat(end_date)}
    if item_type:
        query["item_type"] = item_type
    
    sales = await db.sales.find(query, {"_id": 0}).sort("date", -1).to_list(500)
    return sales

@api_router.post("/sales")
async def create_sale(
    data: SaleCreate,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Register a sale"""
    item_name = ""
    unit_cost = 0.0
    sale_price = data.sale_price or 0.0
    
    if data.item_type == "recipe_item":
        # Get recipe
        recipe = await db.recipes.find_one(
            {"recipe_id": data.item_id, "restaurant_id": restaurant.restaurant_id},
            {"_id": 0}
        )
        if not recipe:
            raise HTTPException(status_code=404, detail="Recipe not found")
        
        item_name = recipe["name"]
        unit_cost = recipe.get("cost_per_portion", 0)
        if not data.sale_price:
            sale_price = recipe.get("selling_price", 0)
        
        # Deduct ingredients from stock
        for ing in recipe.get("ingredients", []):
            ingredient = await db.ingredients.find_one(
                {"ingredient_id": ing["ingredient_id"]},
                {"_id": 0}
            )
            if ingredient:
                qty_to_deduct = ing["quantity"] * data.quantity_sold
                await db.ingredients.update_one(
                    {"ingredient_id": ing["ingredient_id"]},
                    {"$inc": {"current_stock": -qty_to_deduct}}
                )
                # Record stock movement
                movement = StockMovement(
                    restaurant_id=restaurant.restaurant_id,
                    ingredient_id=ing["ingredient_id"],
                    ingredient_name=ingredient["name"],
                    movement_type="saida",
                    quantity=qty_to_deduct,
                    reason="venda",
                    recipe_id=data.item_id
                )
                await db.stock_movements.insert_one(movement.model_dump())
    
    elif data.item_type == "resale_product":
        # Get resale product
        product = await db.resale_products.find_one(
            {"product_id": data.item_id, "restaurant_id": restaurant.restaurant_id},
            {"_id": 0}
        )
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")
        
        item_name = product["name"]
        unit_cost = product.get("purchase_cost", 0)
        if not data.sale_price:
            sale_price = product.get("sale_price", 0)
        
        # Deduct from product stock
        await db.resale_products.update_one(
            {"product_id": data.item_id},
            {"$inc": {"stock_quantity": -data.quantity_sold}}
        )
    else:
        raise HTTPException(status_code=400, detail="Invalid item_type")
    
    # Calculate totals
    total_revenue = sale_price * data.quantity_sold
    total_cost = unit_cost * data.quantity_sold
    profit = total_revenue - total_cost
    
    sale = Sale(
        restaurant_id=restaurant.restaurant_id,
        item_type=data.item_type,
        item_id=data.item_id,
        item_name=item_name,
        quantity_sold=data.quantity_sold,
        unit_cost=unit_cost,
        sale_price=sale_price,
        total_revenue=total_revenue,
        total_cost=total_cost,
        profit=profit,
        sales_channel=data.sales_channel,
        notes=data.notes,
        date=data.date or datetime.now(timezone.utc)
    )
    
    await db.sales.insert_one(sale.model_dump())
    
    # Update analytics summaries
    sale_date = (data.date or datetime.now(timezone.utc))
    date_str = sale_date.strftime("%Y-%m-%d")
    year = sale_date.year
    month = sale_date.month
    
    # Update daily sales summary
    await update_daily_sales_summary(
        restaurant.restaurant_id, date_str, data.item_id, item_name, 
        data.item_type, data.quantity_sold, total_revenue, total_cost
    )
    
    # Update monthly menu profit summary
    category = ""
    if data.item_type == "recipe_item":
        recipe = await db.recipes.find_one({"recipe_id": data.item_id}, {"_id": 0, "category": 1})
        category = recipe.get("category", "") if recipe else ""
    await update_monthly_menu_profit_summary(
        restaurant.restaurant_id, year, month, data.item_id, item_name,
        data.item_type, category, data.quantity_sold, total_revenue, total_cost
    )
    
    # Update dashboard metrics cache
    await update_dashboard_metrics_cache(
        restaurant.restaurant_id, date_str, 
        revenue_delta=total_revenue, profit_delta=profit, units_delta=data.quantity_sold
    )
    
    # Update inventory snapshot after stock changes
    await update_inventory_snapshot(restaurant.restaurant_id)
    
    return {"sale_id": sale.sale_id, "message": "Sale registered", "profit": profit}

@api_router.get("/sales/summary")
async def get_sales_summary(
    period: str = "today",
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get sales summary for a period"""
    now = datetime.now(timezone.utc)
    
    if period == "today":
        start_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "week":
        start_date = now - timedelta(days=7)
    elif period == "month":
        start_date = now - timedelta(days=30)
    else:
        start_date = now - timedelta(days=365)
    
    pipeline = [
        {
            "$match": {
                "restaurant_id": restaurant.restaurant_id,
                "date": {"$gte": start_date}
            }
        },
        {
            "$group": {
                "_id": None,
                "total_revenue": {"$sum": "$total_revenue"},
                "total_cost": {"$sum": "$total_cost"},
                "total_profit": {"$sum": "$profit"},
                "total_sales": {"$sum": 1},
                "items_sold": {"$sum": "$quantity_sold"}
            }
        }
    ]
    
    result = await db.sales.aggregate(pipeline).to_list(1)
    
    if result:
        return {
            "total_revenue": result[0]["total_revenue"],
            "total_cost": result[0]["total_cost"],
            "total_profit": result[0]["total_profit"],
            "total_sales": result[0]["total_sales"],
            "items_sold": result[0]["items_sold"],
            "period": period
        }
    
    return {
        "total_revenue": 0,
        "total_cost": 0,
        "total_profit": 0,
        "total_sales": 0,
        "items_sold": 0,
        "period": period
    }

@api_router.delete("/sales/{sale_id}")
async def delete_sale(
    sale_id: str,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Delete a sale (for corrections)"""
    result = await db.sales.delete_one(
        {"sale_id": sale_id, "restaurant_id": restaurant.restaurant_id}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Sale not found")
    return {"message": "Sale deleted"}

# ============= PRODUCTION ROUTES (Enhanced) =============

@api_router.get("/productions")
async def list_productions(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """List all productions"""
    query = {"restaurant_id": restaurant.restaurant_id}
    
    if start_date:
        query["created_at"] = {"$gte": datetime.fromisoformat(start_date)}
    if end_date:
        if "created_at" in query:
            query["created_at"]["$lte"] = datetime.fromisoformat(end_date)
        else:
            query["created_at"] = {"$lte": datetime.fromisoformat(end_date)}
    
    productions = await db.productions.find(query, {"_id": 0}).sort("created_at", -1).to_list(500)
    return productions

@api_router.post("/productions")
async def create_production(
    data: ProductionCreate,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Register a production and deduct stock"""
    # Get recipe
    recipe = await db.recipes.find_one(
        {"recipe_id": data.recipe_id, "restaurant_id": restaurant.restaurant_id},
        {"_id": 0}
    )
    if not recipe:
        raise HTTPException(status_code=404, detail="Recipe not found")
    
    # Calculate total production cost
    total_cost = (recipe.get("cost_per_portion", 0) * recipe.get("yield_quantity", 1)) * data.quantity
    
    # Deduct ingredients from stock
    for ing in recipe.get("ingredients", []):
        ingredient = await db.ingredients.find_one(
            {"ingredient_id": ing["ingredient_id"]},
            {"_id": 0}
        )
        if ingredient:
            qty_to_deduct = ing["quantity"] * data.quantity
            await db.ingredients.update_one(
                {"ingredient_id": ing["ingredient_id"]},
                {"$inc": {"current_stock": -qty_to_deduct}}
            )
            # Record stock movement
            movement = StockMovement(
                restaurant_id=restaurant.restaurant_id,
                ingredient_id=ing["ingredient_id"],
                ingredient_name=ingredient["name"],
                movement_type="saida",
                quantity=qty_to_deduct,
                reason="producao",
                recipe_id=data.recipe_id
            )
            await db.stock_movements.insert_one(movement.model_dump())
    
    # Create production record
    production = Production(
        restaurant_id=restaurant.restaurant_id,
        recipe_id=data.recipe_id,
        recipe_name=recipe["name"],
        quantity=data.quantity,
        total_cost=total_cost,
        created_at=data.date or datetime.now(timezone.utc)
    )
    
    await db.productions.insert_one(production.model_dump())
    
    # Update analytics summaries
    prod_date = data.date or datetime.now(timezone.utc)
    date_str = prod_date.strftime("%Y-%m-%d")
    
    # Update dashboard metrics cache with production cost
    await update_dashboard_metrics_cache(
        restaurant.restaurant_id, date_str, 
        production_cost_delta=total_cost
    )
    
    # Update inventory snapshot after stock changes
    await update_inventory_snapshot(restaurant.restaurant_id)
    
    return {
        "production_id": production.production_id,
        "message": "Production registered",
        "total_cost": total_cost,
        "recipe_name": recipe["name"]
    }

@api_router.get("/productions/summary")
async def get_production_summary(
    period: str = "today",
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get production summary for a period"""
    now = datetime.now(timezone.utc)
    
    if period == "today":
        start_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "week":
        start_date = now - timedelta(days=7)
    elif period == "month":
        start_date = now - timedelta(days=30)
    else:
        start_date = now - timedelta(days=365)
    
    pipeline = [
        {
            "$match": {
                "restaurant_id": restaurant.restaurant_id,
                "created_at": {"$gte": start_date}
            }
        },
        {
            "$group": {
                "_id": None,
                "total_cost": {"$sum": "$total_cost"},
                "total_productions": {"$sum": 1},
                "total_quantity": {"$sum": "$quantity"}
            }
        }
    ]
    
    result = await db.productions.aggregate(pipeline).to_list(1)
    
    if result:
        return {
            "total_cost": result[0]["total_cost"],
            "total_productions": result[0]["total_productions"],
            "total_quantity": result[0]["total_quantity"],
            "period": period
        }
    
    return {
        "total_cost": 0,
        "total_productions": 0,
        "total_quantity": 0,
        "period": period
    }

@api_router.delete("/productions/{production_id}")
async def delete_production(
    production_id: str,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Delete a production (for corrections)"""
    result = await db.productions.delete_one(
        {"production_id": production_id, "restaurant_id": restaurant.restaurant_id}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Production not found")
    return {"message": "Production deleted"}

# ============= ANALYTICS SUMMARY ROUTES =============

@api_router.get("/analytics/dashboard")
async def get_analytics_dashboard(
    date: Optional[str] = None,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get cached dashboard metrics for a specific date"""
    if not date:
        date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    
    cache = await db.dashboard_metrics_cache.find_one(
        {"restaurant_id": restaurant.restaurant_id, "date": date},
        {"_id": 0}
    )
    
    if not cache:
        # Return empty metrics if no cache exists
        return {
            "date": date,
            "total_revenue": 0,
            "total_profit": 0,
            "total_units_sold": 0,
            "total_production_cost": 0,
            "inventory_value": 0,
            "low_stock_count": 0,
            "cached": False
        }
    
    return {**cache, "cached": True}

@api_router.get("/analytics/daily-sales")
async def get_analytics_daily_sales(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get daily sales summaries"""
    query = {"restaurant_id": restaurant.restaurant_id}
    
    if start_date:
        query["date"] = {"$gte": start_date}
    if end_date:
        if "date" in query:
            query["date"]["$lte"] = end_date
        else:
            query["date"] = {"$lte": end_date}
    
    summaries = await db.daily_sales_summary.find(query, {"_id": 0}).sort("date", -1).to_list(500)
    return summaries

@api_router.get("/analytics/monthly-profit")
async def get_analytics_monthly_profit(
    year: Optional[int] = None,
    month: Optional[int] = None,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get monthly menu profit summaries with classifications"""
    now = datetime.now(timezone.utc)
    target_year = year or now.year
    target_month = month or now.month
    
    # First, recalculate classifications for this period
    await recalculate_monthly_classifications(restaurant.restaurant_id, target_year, target_month)
    
    summaries = await db.monthly_menu_profit_summary.find(
        {
            "restaurant_id": restaurant.restaurant_id,
            "year": target_year,
            "month": target_month
        },
        {"_id": 0}
    ).sort("profit_total", -1).to_list(500)
    
    # Calculate summary totals
    total_revenue = sum(s.get("revenue_total", 0) for s in summaries)
    total_profit = sum(s.get("profit_total", 0) for s in summaries)
    total_units = sum(s.get("units_sold", 0) for s in summaries)
    
    # Count classifications
    classification_counts = {"STAR": 0, "PLOWHORSE": 0, "PUZZLE": 0, "DOG": 0, "UNCLASSIFIED": 0}
    for s in summaries:
        cls = s.get("classification", "UNCLASSIFIED")
        if cls in classification_counts:
            classification_counts[cls] += 1
    
    return {
        "year": target_year,
        "month": target_month,
        "items": summaries,
        "summary": {
            "total_items": len(summaries),
            "total_revenue": round(total_revenue, 2),
            "total_profit": round(total_profit, 2),
            "total_units_sold": total_units
        },
        "classification_counts": classification_counts,
        "top_profitable": summaries[:5] if summaries else []
    }

@api_router.get("/analytics/inventory-snapshots")
async def get_analytics_inventory_snapshots(
    days: int = 30,
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Get inventory value snapshots for the last N days"""
    start_date = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d")
    
    snapshots = await db.inventory_value_snapshots.find(
        {"restaurant_id": restaurant.restaurant_id, "date": {"$gte": start_date}},
        {"_id": 0}
    ).sort("date", 1).to_list(days + 1)
    
    return snapshots

@api_router.post("/analytics/backfill")
async def backfill_analytics_summaries(
    restaurant: Restaurant = Depends(get_current_restaurant)
):
    """Backfill analytics summaries from existing operational data (admin utility)"""
    try:
        # Clear existing summaries for this restaurant
        await db.daily_sales_summary.delete_many({"restaurant_id": restaurant.restaurant_id})
        await db.monthly_menu_profit_summary.delete_many({"restaurant_id": restaurant.restaurant_id})
        await db.dashboard_metrics_cache.delete_many({"restaurant_id": restaurant.restaurant_id})
        await db.inventory_value_snapshots.delete_many({"restaurant_id": restaurant.restaurant_id})
        
        # Process all sales records
        sales = await db.sales.find(
            {"restaurant_id": restaurant.restaurant_id},
            {"_id": 0}
        ).to_list(10000)
        
        daily_totals = {}  # {date_str: {item_id: {data}}}
        monthly_totals = {}  # {(year, month, item_id): {data}}
        dashboard_daily = {}  # {date_str: {metrics}}
        
        for sale in sales:
            sale_date = sale.get("date") or sale.get("created_at")
            if isinstance(sale_date, str):
                sale_date = datetime.fromisoformat(sale_date.replace("Z", "+00:00"))
            
            date_str = sale_date.strftime("%Y-%m-%d")
            year = sale_date.year
            month = sale_date.month
            item_id = sale.get("item_id")
            
            revenue = sale.get("total_revenue", 0)
            cost = sale.get("total_cost", 0)
            profit = sale.get("profit", 0)
            units = sale.get("quantity_sold", 0)
            
            # Daily sales summary
            if date_str not in daily_totals:
                daily_totals[date_str] = {}
            if item_id not in daily_totals[date_str]:
                daily_totals[date_str][item_id] = {
                    "item_name": sale.get("item_name", ""),
                    "item_type": sale.get("item_type", ""),
                    "units_sold": 0,
                    "revenue_total": 0,
                    "cost_total": 0
                }
            daily_totals[date_str][item_id]["units_sold"] += units
            daily_totals[date_str][item_id]["revenue_total"] += revenue
            daily_totals[date_str][item_id]["cost_total"] += cost
            
            # Monthly profit summary
            key = (year, month, item_id)
            if key not in monthly_totals:
                monthly_totals[key] = {
                    "item_name": sale.get("item_name", ""),
                    "item_type": sale.get("item_type", ""),
                    "category": "",
                    "units_sold": 0,
                    "revenue_total": 0,
                    "cost_total": 0
                }
            monthly_totals[key]["units_sold"] += units
            monthly_totals[key]["revenue_total"] += revenue
            monthly_totals[key]["cost_total"] += cost
            
            # Dashboard daily metrics
            if date_str not in dashboard_daily:
                dashboard_daily[date_str] = {
                    "total_revenue": 0,
                    "total_profit": 0,
                    "total_units_sold": 0,
                    "total_production_cost": 0
                }
            dashboard_daily[date_str]["total_revenue"] += revenue
            dashboard_daily[date_str]["total_profit"] += profit
            dashboard_daily[date_str]["total_units_sold"] += units
        
        # Insert daily sales summaries
        for date_str, items in daily_totals.items():
            for item_id, data in items.items():
                profit = data["revenue_total"] - data["cost_total"]
                margin = (profit / data["revenue_total"] * 100) if data["revenue_total"] > 0 else 0
                summary = DailySalesSummary(
                    restaurant_id=restaurant.restaurant_id,
                    date=date_str,
                    menu_item_id=item_id,
                    item_name=data["item_name"],
                    item_type=data["item_type"],
                    units_sold=data["units_sold"],
                    revenue_total=data["revenue_total"],
                    cost_total=data["cost_total"],
                    profit_total=profit,
                    average_margin=margin
                )
                await db.daily_sales_summary.insert_one(summary.model_dump())
        
        # Insert monthly profit summaries
        for (year, month, item_id), data in monthly_totals.items():
            profit = data["revenue_total"] - data["cost_total"]
            profit_per_unit = profit / data["units_sold"] if data["units_sold"] > 0 else 0
            margin = (profit / data["revenue_total"] * 100) if data["revenue_total"] > 0 else 0
            summary = MonthlyMenuProfitSummary(
                restaurant_id=restaurant.restaurant_id,
                year=year,
                month=month,
                menu_item_id=item_id,
                item_name=data["item_name"],
                item_type=data["item_type"],
                category=data["category"],
                units_sold=data["units_sold"],
                revenue_total=data["revenue_total"],
                cost_total=data["cost_total"],
                profit_total=profit,
                profit_per_unit=profit_per_unit,
                average_margin=margin
            )
            await db.monthly_menu_profit_summary.insert_one(summary.model_dump())
        
        # Recalculate classifications for each month
        months_processed = set()
        for (year, month, _) in monthly_totals.keys():
            if (year, month) not in months_processed:
                await recalculate_monthly_classifications(restaurant.restaurant_id, year, month)
                months_processed.add((year, month))
        
        # Insert dashboard metrics cache
        for date_str, metrics in dashboard_daily.items():
            cache = DashboardMetricsCache(
                restaurant_id=restaurant.restaurant_id,
                date=date_str,
                total_revenue=metrics["total_revenue"],
                total_profit=metrics["total_profit"],
                total_units_sold=metrics["total_units_sold"],
                total_production_cost=metrics["total_production_cost"]
            )
            await db.dashboard_metrics_cache.insert_one(cache.model_dump())
        
        # Process production records for dashboard cache
        productions = await db.productions.find(
            {"restaurant_id": restaurant.restaurant_id},
            {"_id": 0}
        ).to_list(10000)
        
        for prod in productions:
            prod_date = prod.get("created_at")
            if isinstance(prod_date, str):
                prod_date = datetime.fromisoformat(prod_date.replace("Z", "+00:00"))
            date_str = prod_date.strftime("%Y-%m-%d")
            cost = prod.get("total_cost", 0)
            
            await db.dashboard_metrics_cache.update_one(
                {"restaurant_id": restaurant.restaurant_id, "date": date_str},
                {"$inc": {"total_production_cost": cost}},
                upsert=True
            )
        
        # Create current inventory snapshot
        await update_inventory_snapshot(restaurant.restaurant_id)
        
        return {
            "message": "Analytics backfill completed",
            "daily_sales_records": sum(len(items) for items in daily_totals.values()),
            "monthly_profit_records": len(monthly_totals),
            "dashboard_cache_records": len(dashboard_daily),
            "months_classified": len(months_processed)
        }
        
    except Exception as e:
        logger.error(f"Backfill error: {e}")
        raise HTTPException(status_code=500, detail=f"Backfill failed: {str(e)}")

# ============= HEALTH CHECK =============

@api_router.get("/")
async def root():
    return {"message": "KitchenCost API", "status": "running"}

@api_router.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now(timezone.utc).isoformat()}

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_db_client():
    """Create MongoDB indexes for performance"""
    try:
        # Restaurant indexes
        await db.restaurants.create_index("user_id")
        await db.restaurants.create_index("restaurant_id", unique=True)
        
        # Ingredient indexes
        await db.ingredients.create_index("restaurant_id")
        await db.ingredients.create_index("ingredient_id", unique=True)
        await db.ingredients.create_index([("restaurant_id", 1), ("name", 1)])
        await db.ingredients.create_index([("restaurant_id", 1), ("category", 1)])
        await db.ingredients.create_index("created_at")
        
        # Recipe indexes
        await db.recipes.create_index("restaurant_id")
        await db.recipes.create_index("recipe_id", unique=True)
        await db.recipes.create_index([("restaurant_id", 1), ("name", 1)])
        await db.recipes.create_index([("restaurant_id", 1), ("category", 1)])
        await db.recipes.create_index("created_at")
        
        # Supplier indexes
        await db.suppliers.create_index("restaurant_id")
        await db.suppliers.create_index("supplier_id", unique=True)
        await db.suppliers.create_index([("restaurant_id", 1), ("name", 1)])
        
        # Stock movement indexes
        await db.stock_movements.create_index("restaurant_id")
        await db.stock_movements.create_index("ingredient_id")
        await db.stock_movements.create_index("created_at")
        await db.stock_movements.create_index([("restaurant_id", 1), ("created_at", -1)])
        
        # Production indexes
        await db.productions.create_index("restaurant_id")
        await db.productions.create_index("recipe_id")
        await db.productions.create_index("created_at")
        
        # Price history indexes
        await db.ingredient_price_history.create_index("ingredient_id")
        await db.ingredient_price_history.create_index([("ingredient_id", 1), ("created_at", -1)])
        
        # Team member indexes
        await db.team_members.create_index("restaurant_id")
        await db.team_members.create_index([("restaurant_id", 1), ("email", 1)], unique=True)
        
        # Session indexes
        await db.user_sessions.create_index("session_token")
        await db.user_sessions.create_index("user_id")
        await db.user_sessions.create_index("expires_at")
        
        # Resale products indexes
        await db.resale_products.create_index("restaurant_id")
        await db.resale_products.create_index("product_id", unique=True)
        await db.resale_products.create_index([("restaurant_id", 1), ("name", 1)])
        await db.resale_products.create_index([("restaurant_id", 1), ("category", 1)])
        
        # Sales indexes
        await db.sales.create_index("restaurant_id")
        await db.sales.create_index("sale_id", unique=True)
        await db.sales.create_index([("restaurant_id", 1), ("date", -1)])
        await db.sales.create_index([("restaurant_id", 1), ("item_type", 1)])
        
        # Menu items indexes
        await db.menu_items.create_index("restaurant_id")
        await db.menu_items.create_index("menu_item_id", unique=True)
        await db.menu_items.create_index([("restaurant_id", 1), ("name", 1)])
        await db.menu_items.create_index([("restaurant_id", 1), ("category", 1)])
        await db.menu_items.create_index([("restaurant_id", 1), ("item_type", 1)])
        
        # Menu categories indexes
        await db.menu_categories.create_index("restaurant_id")
        await db.menu_categories.create_index("category_id", unique=True)
        await db.menu_categories.create_index([("restaurant_id", 1), ("name", 1)], unique=True)
        await db.menu_categories.create_index([("restaurant_id", 1), ("display_order", 1)])
        
        # Analytics summary indexes
        await db.daily_sales_summary.create_index("restaurant_id")
        await db.daily_sales_summary.create_index([("restaurant_id", 1), ("date", -1)])
        await db.daily_sales_summary.create_index([("restaurant_id", 1), ("date", 1), ("menu_item_id", 1)], unique=True)
        
        await db.monthly_menu_profit_summary.create_index("restaurant_id")
        await db.monthly_menu_profit_summary.create_index([("restaurant_id", 1), ("year", 1), ("month", 1)])
        await db.monthly_menu_profit_summary.create_index([("restaurant_id", 1), ("year", 1), ("month", 1), ("menu_item_id", 1)], unique=True)
        
        await db.dashboard_metrics_cache.create_index("restaurant_id")
        await db.dashboard_metrics_cache.create_index([("restaurant_id", 1), ("date", 1)], unique=True)
        
        await db.inventory_value_snapshots.create_index("restaurant_id")
        await db.inventory_value_snapshots.create_index([("restaurant_id", 1), ("date", 1)], unique=True)
        
        logger.info("MongoDB indexes created successfully")
    except Exception as e:
        logger.error(f"Error creating indexes: {e}")

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
